GAUSS recognizes a default dynamic library directory, a directory where it
will look for your dynamic-linked libraries when you call DLIBRARY. You can
specify the default directory in gauss.cfg by setting dlib_path. As it is
shipped, gauss.cfg specifies this directory as the default directory.
