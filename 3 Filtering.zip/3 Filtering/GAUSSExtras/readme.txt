In order to run the filtering procedures, you need to 
install the files that you find in the subdirectories.
It is important that the usersrc files and the dll file 
are properly linked to your installation of GAUSS. These
programs were written for GAUSS14
