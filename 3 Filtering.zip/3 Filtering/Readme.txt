The filtering is done in GAUSS14. Please make sure to install the GAUSSExtras before
running the code.

1. To conduct the filtering, select the subdirectory with the
   desired model specification.

2. Use dsge_spec.g to select JP vs US and set some of the global
   constants for the filter
   For test purposes the number of particles is set to 100 only.

3. Run dsge_filter_gs_linearinitial4.g for filtering
   You can use _forcetilde to set the sunspot states to pre-determined values.
   We used this option when generating the solution grid.
   For the 4v models we also provide a procedure 
   dsge_filter_gs_linearinitial5.g, which generates the predictive
   likelihood scores for output, inflation, and interest rates that are used
   to weight the models.

4. Run dsge_statemom.g to compute means of filtered states. These means
   are used for the subsequent analysis.
   We used "cut and paste" to paste the filtered states into the states_*.* 
   spreadsheets that you see in the /results/ directory

5. Run dsge_stateextract.g to extract specific particle values. This was
   used to iteratively generate grid points for the model solution. Note that
   this program requires you to run the filter with either _forcetilde = 10 
   or _forcetilde = 11. We used "cut and paste" to paste the extracted particles
   in the particles_*.* spreadsheets that you see in the /results/ directory
    
6. For the 3v specifications, run dsge_extract_loglh.g to extract the log likelihoods that are used
   to compute the model weights.

7. The program plot_predlh_v2 in /common/ generates the model weights and creates 
   a model-average-based estimate of the sunspot state.

