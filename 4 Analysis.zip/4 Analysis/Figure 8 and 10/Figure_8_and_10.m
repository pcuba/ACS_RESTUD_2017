%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Figures 8 and 10: Cumulative Predictive Log Likelihood Scores and
% average sunspot probability across models using the quasimodel probabilities.
% as weights.
%
% The data in Figures_PredLogL.xlsx is re-arranged from the files
% PredLogLHandWeightsJP.xlsx and PredLogLHandWeightsUS.xlsx which are
% produced running plot_predlh_v2 in /Filtering/common/.
%
% See /Filtering/Readme.txt for details.
%
%--------------------------------------------------------------------------

clear; clc; close all;

addpath ../ExternalTools/       % Directory with external tools for plotting


% JP start of first ZLB observation
zlb_jp = 1999;

% US start of first ZLB observation
zlb_us = 2009;

% Load data
[ndata, text, ~] = xlsread('Figures_PredLogL.xlsx','Fig_8_and_10');

[nobs,nseries] = size(ndata);

for jj=1:nseries
    eval([text{1,jj} ' = ndata(:,jj);']);
end

% Color scheme
cuse = [
255 127 14;         % Gap 3v
214 39 40;          % Gap 4v C
44  160 44;         % Growth 3v
31  119 180;        % Growth 4v C
148,103,189;        % Gap 4v G
219 161 58]./256;   % Growth 4v G



%==========================================================================
% Figure 8
%==========================================================================

%--------------------------------------
% US - POST ZLB CUMULATIVE PRED LOGL
%--------------------------------------

figure(11); clf;
set(figure(11),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
line_fewer_markers(Period, USGap3, 15, '*--','LineWidth',5,'color',cuse(1,:),'MarkerSize',9);  hold on;
line_fewer_markers(Period, USGap4, 15, '*-','LineWidth',5,'color',cuse(2,:),'MarkerSize',9); 
line_fewer_markers(Period, USGap4new, 15, '*-.','LineWidth',5,'color',cuse(5,:),'MarkerSize',9,'MarkerFaceColor',cuse(5,:)); 
plot(Period,USGrowth3,'--','LineWidth',5,'color',cuse(3,:));
plot(Period,USGrowth4,'-','LineWidth',5,'color',cuse(4,:));
plot(Period,USGrowth4new,'-.','LineWidth',5,'color',cuse(6,:)); hold off
xlim([2009,2015]); ylim([-30 35]);
title('U.S.','FontSize',38,'Interpreter','Latex');
ylabel('Pred LogLH','FontSize',32)
set(gca,'FontSize',32)
[l1,icons,~,~]=legend('3vGap', '4vGap-C', '4vGap-G','3vGrowth','4vGrowth-C','4vGrowth-G','Location','SE');
set(l1,'FontSize',30); 
legend boxoff


%//========================
%// Change the legend here
%//========================

%// Get the handles for legends
h3vGap  = icons(7);
h4vGapC = icons(9);
h4vGapG = icons(11);
h3vGrowth  = icons(13);
h4vGrowthC = icons(15);
h4vGrowthG = icons(17);


%// Fetch its XData property
LineData = get(h3vGap,'XData');
NewData = [LineData(1)+0.1 LineData(2)-0.35];
set(h3vGap,'XData',NewData,'LineWidth',5)

%// Fetch its XData property
LineData = get(h4vGapC,'XData');
NewData = [LineData(1)+0.07 LineData(2)-0.33];
set(h4vGapC,'XData',NewData,'LineWidth',5)

%// Fetch its XData property
LineData = get(h4vGapG,'XData');
NewData = [LineData(1)+0.1 LineData(2)-0.35];
set(h4vGapG,'XData',NewData,'LineWidth',5)

%// Fetch its XData property
LineData = get(h3vGrowth,'XData');
NewData = [LineData(1)+0.1 LineData(2)-0.35];
set(h3vGrowth,'XData',NewData,'LineWidth',5)

%// Fetch its XData property
LineData = get(h4vGrowthC,'XData');
NewData = [LineData(1)+0.0975 LineData(2)-0.33];
set(h4vGrowthC,'XData',NewData,'LineWidth',5)

%// Fetch its XData property
LineData = get(h4vGrowthG,'XData');
NewData = [LineData(1)+0.1 LineData(2)-0.35];
set(h4vGrowthG,'XData',NewData,'LineWidth',5)

box on;

%%
%--------------------------------------
% JAPAN - POST ZLB CUMULATIVE PRED LOGL
%--------------------------------------

figure(12); clf;
set(figure(12),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
line_fewer_markers(Period, JPGap3, 10, '*--','LineWidth',5,'color',cuse(1,:),'MarkerSize',9);  hold on;
line_fewer_markers(Period, JPGap4, 10, '*-','LineWidth',5,'color',cuse(2,:),'MarkerSize',9);  hold on;
line_fewer_markers(Period, JPGap4new, 10, '*-.','LineWidth',5,'color',cuse(5,:),'MarkerSize',9);  hold on;
plot(Period,JPGrowth3,'--','LineWidth',5,'color',cuse(3,:));
plot(Period,JPGrowth4,'-','LineWidth',5,'color',cuse(4,:));
plot(Period,JPGrowth4new,'-.','LineWidth',5,'color',cuse(6,:)); hold off
xlim([1999,2015]); ylim([-125 25]);
title('Japan','FontSize',38,'Interpreter','Latex');
ylabel('Pred LogLH','FontSize',32)
set(gca,'FontSize',32)
[l1,icons,~,~]=legend('3vGap', '4vGap-C', '4vGap-G','3vGrowth','4vGrowth-C','4vGrowth-G','Location','SW');
set(l1,'FontSize',30); 
legend boxoff

%=========================
% Change the legend here
%=========================

%// Get the handles for legends
h3vGap  = icons(7);
h4vGapC = icons(9);
h4vGapG = icons(11);

h3vGrowth  = icons(13);
h4vGrowthC = icons(15);
h4vGrowthG = icons(17);

%// Fetch its XData property
LineData = get(h3vGap,'XData');
NewData = [LineData(1)+0.1 LineData(2)-0.35];
set(h3vGap,'XData',NewData,'LineWidth',5)

%// Fetch its XData property
LineData = get(h4vGapC,'XData');
NewData = [LineData(1)+0.09 LineData(2)-0.33];
set(h4vGapC,'XData',NewData,'LineWidth',5)

%// Fetch its XData property
LineData = get(h4vGapG,'XData');
NewData = [LineData(1)+0.1 LineData(2)-0.35];
set(h4vGapG,'XData',NewData,'LineWidth',5)

%// Fetch its XData property
LineData = get(h3vGrowth,'XData');
NewData = [LineData(1)+0.1 LineData(2)-0.35];
set(h3vGrowth,'XData',NewData,'LineWidth',5)

%// Fetch its XData property
LineData = get(h4vGrowthC,'XData');
NewData = [LineData(1)+0.0975 LineData(2)-0.33];
set(h4vGrowthC,'XData',NewData,'LineWidth',5)


%// Fetch its XData property
LineData = get(h4vGrowthG,'XData');
NewData = [LineData(1)+0.1 LineData(2)-0.35];
set(h4vGrowthG,'XData',NewData,'LineWidth',5)

set(l1,'Position',[0.195 0.10 0.33 0.37]);


box on;
%%
%==========================================================================
% Figure 10: Average P(s|Y^o) across model specifications
%==========================================================================

%------------------------------------------
% US Weighted Pred LogL - FULL AND POST ZLB
%------------------------------------------

% Color scheme
% cuse2 = [0,0,0
% 222,45,38]./255;

% Gray scale
cuse2 = [
0 0 0;        % Gap 3v
204 204 204;        % Growth 3v
]./256;             % Growth 4v G


figure(13); clf;
set(figure(13),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,USPredLogL,'k-','LineWidth',5,'color',cuse2(1,:)); hold on;
plot(Period,USPredLogLPostZLB,'r-','LineWidth',5,'color',cuse2(2,:)); hold on;
xlim([2009,2015]); ylim([0,1]);ylim_use = ylim;
plot(zlb_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
hline(0.83,'m--'); hline(0.5,'m-');
title('U.S.','FontSize',38,'Interpreter','Latex');
set(gca,'FontSize',32)


%------------------------------------------
% JP Weighted Pred LogL - FULL AND POST ZLB
%------------------------------------------
figure(14); clf;
set(figure(14),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,JPPredLogL,'k-','LineWidth',5,'color',cuse2(1,:)); hold on;
plot(Period,JPPredLogLPostZLB,'r-','LineWidth',5,'color',cuse2(2,:)); hold on;
xlim([1999,2015]); ylim([0,1]);
hline(0.9,'m--'); hline(0.5,'m-');ylim_use = ylim;
plot(zlb_jp*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('Japan','FontSize',38,'Interpreter','Latex');
set(gca,'FontSize',32)
%%

%--------------------------------------------------------------------------
% Print Figures
%--------------------------------------------------------------------------
% print(figure(11),'-dpdf','-r600','Fig_PredLogL_US_Cumulative_PostZLB.pdf')
% print(figure(12),'-dpdf','-r600','Fig_PredLogL_JP_Cumulative_PostZLB.pdf')
% print(figure(13),'-dpdf','-r600','Fig_SUN_PredLogL_US_Cumulative_PostZLB.pdf')
% print(figure(14),'-dpdf','-r600','Fig_SUN_PredLogL_JP_Cumulative_PostZLB.pdf')
