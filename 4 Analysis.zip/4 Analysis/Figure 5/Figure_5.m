%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Figure 5: Impulse response function sunspot model
%
% This code simulates the sunspot model and produces impulse responses
% conditional on the targeted-inflation regime and the deflation regime in the
% U.S. 4vGrowth-C specification.
%
%--------------------------------------------------------------------------
clear; clc;  close all; delete *.asc; delete *.m~;
set(0,'defaulttextinterpreter','latex')

% ADD IMPORTANT PATHS
addpath ../Common/                  % Directory with common functions
addpath ../ExternalTools/           % Directory with miscelaneous functions

% GLOBAL VARIABLES
global ind_scale ind_impose ind_period_one country bad_sim_flag
global size_shock
global low_prctile high_prctile
global ind_draw_sun SUN_IRF_PATH
global Rbar
global ncoefs O


%--------------------------------------------------------------------------
% SELECT MODEL
%--------------------------------------------------------------------------
model_number = 'US_4vGrowth_C';

%--------------------------------------------------------------------------
% OPTIONS FOR BASELINE PATH SIMULATION
%--------------------------------------------------------------------------
ind_impose  = 1;                % [1] ZLB  ACTIVE/ [0] SLACK
Rbar = 1;                       % Cutoff to enforce ZLB in simulations
sunspot_initial_sim = 1;        % s = 1 or s = 0
Tsim_sim  = 10000;              % Number of periods for simulation
Tdrop_sim = 150;                % Burin simulations
ind_shocks_sim = 1;             % [1] Stored shocks, [0] Fresh shocks

%--------------------------------------------------------------------------
% OPTIONS FOR NON-LINEAR IRF
%--------------------------------------------------------------------------

Tirf  = 20;                    % Length of Impulse Responses
Nrep  = 500;                   % Repetitions to construct IRFs
size_shock   = 1;              % Size of the shock in stdev
ind_scale    = 0;              % [1] scale by size of the shock [0] No scale
ind_draw_sun = 0;              % [1] Draw the Sunspot path when computing IRF. [0] Fix Sunspot at sunspot_initial_irf
SUN_IRF_PATH = [];             % Fixed Path for Sunspot

low_prctile  = 20;             % The percentiles for IRF plot
high_prctile = 80;
ind_period_one = 1;            % [0] all period one shocks are set equal to zero
                               % [1] all period one shocks are drawn.

%--------------------------------------------------------------------------
%                           HOUSEKEEPING
%--------------------------------------------------------------------------
% LOAD FILES
script_load_solution;
O.ind_params = par.ind_params;

% NUMBER OF COEFFICIENTS FOR BASIS FUNCTIONS
ncoefs = 210;

if isempty(findstr(model_number, 'US')) %#ok<FSTR>
    country = 'Japan';
else
    country = 'U.S.';
end

% Flag to keep track of bad simulations
bad_sim_flag = 0;

%--------------------------------------------------------------------------
%                  NON-LINEAR IMPULSE RESPONSES
%--------------------------------------------------------------------------

% GET ERGODIC INITIAL STATE
SUNSPOT =  get_sunspot(Tsim_sim,sunspot_initial_sim,Tdrop_sim,1);
SIM     =  simulate_sunspot(theta_use,shocks_sim,init_sim,Tsim_sim,Tdrop_sim,SUNSPOT);

% *** S = 0 *** %
Rlag_0= SIM.Rlag(SIM.SUN==0);
Ylag_0= SIM.ylag(SIM.SUN==0);
Clag_0= SIM.clag(SIM.SUN==0);
R_0   = SIM.R(SIM.SUN==0);
Y_0   = SIM.y(SIM.SUN==0);
Z_0   = SIM.z(SIM.SUN==0);
G_0   = SIM.g(SIM.SUN==0);
ER_0  = SIM.er(SIM.SUN==0);
D_0   = SIM.d(SIM.SUN==0);

% *** S = 1 *** %
Rlag_1= SIM.Rlag(SIM.SUN==1);
Ylag_1= SIM.ylag(SIM.SUN==1);
Clag_1= SIM.clag(SIM.SUN==1);
R_1   = SIM.R(SIM.SUN==1);
Y_1   = SIM.y(SIM.SUN==1);
Z_1   = SIM.z(SIM.SUN==1);
G_1   = SIM.g(SIM.SUN==1);
ER_1  = SIM.er(SIM.SUN==1);
D_1   = SIM.d(SIM.SUN==1);

SIM_0 = [Rlag_0 Ylag_0 Clag_0 ER_0 Z_0 G_0 D_0];
SIM_1 = [Rlag_1 Ylag_1 Clag_1 ER_1 Z_1 G_1 D_1];

% ERGODIC MEAN AS INITIAL STATE FOR IRF
[~, INIT_S0, ~] = tsga_grid(SIM_0,Nrep);
[~, INIT_S1, ~] = tsga_grid(SIM_1,Nrep);

% DRAW SHOCKS FOR BASELINE PATH
V_use = fn_get_shocks(Nrep,Tirf);

%---------------------------------------
% COMPUTE IRFS
%---------------------------------------

% *** IRF Initial Sunspot S = 0 *** %
fprintf('\n *** Computing IRF for s=0 \n');
sun_t0 = 0;
INIT_USE.Rlag = INIT_S0(:,1);
INIT_USE.ylag = INIT_S0(:,2);
INIT_USE.clag = INIT_S0(:,3);
INIT_USE.zlag = INIT_S0(:,5);
INIT_USE.glag = INIT_S0(:,6);
INIT_USE.dlag = INIT_S0(:,7);
INIT_USE.Alag = ones(length(INIT_S0),1);

[irf_s0, irf_s0_50, irf_s0_low, irf_s0_high] = irf_sunspot(theta_use,INIT_USE,Tirf,Nrep,V_use,sun_t0);

% *** IRF Initial Sunspot S = 1 *** %
fprintf('\n *** Computing IRF for s=1 \n');
sun_t0 = 1;
INIT_USE.Rlag = INIT_S1(:,1);
INIT_USE.ylag = INIT_S1(:,2);
INIT_USE.clag = INIT_S1(:,3);
INIT_USE.zlag = INIT_S1(:,5);
INIT_USE.glag = INIT_S1(:,6);
INIT_USE.dlag = INIT_S1(:,7);
INIT_USE.Alag = ones(length(INIT_S1),1);
[irf_s1, irf_s1_50, irf_s1_low, irf_s1_high] = irf_sunspot(theta_use,INIT_USE,Tirf,Nrep,V_use,sun_t0);

%--------------------------------------------------------------------------
% Plot figure 5
%--------------------------------------------------------------------------

xt = (1:Tirf);
NTicks = 4;

figure(5);clf;
set(figure(5),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[-0.2 -0.2 11.5 8]);
subplot(4,4,1)
h=plot(xt, irf_s1.logY_ez,'-',xt, irf_s0.logY_ez,'--');
y = ylabel('$\epsilon_z$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
lb=min([irf_s1.logY_ez; irf_s0.logY_ez; irf_s1.logC_ez; irf_s0.logC_ez]);
ylim([lb, 0.55]);
set(y, 'Units', 'Normalized', 'Position', [-0.37, 0.5, 0]);
beutifyplot('Output $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
set(gca,'YTick',[0.45 0.5 0.55]);
set(h,'LineWidth',3);

subplot(4,4,2)
h=plot(xt, irf_s1.logC_ez,'-',xt, irf_s0.logC_ez,'--');
ylim([lb, 0.55]);
beutifyplot('Consumption $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
set(gca,'YTick',[0.45 0.5 0.55]);
set(h,'LineWidth',3);

subplot(4,4,3)
h=plot(xt, irf_s1.pi_ez,'-',xt, irf_s0.pi_ez,'--');
beutifyplot('Inflation $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,4)
h=plot(xt, irf_s1.R_ez,'-',xt, irf_s0.R_ez,'--');
beutifyplot('Interest Rate $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
ub=max([irf_s1.logY_eg; irf_s0.logY_eg; irf_s1.logC_eg; irf_s0.logC_eg]);
lb=min([irf_s1.logY_eg; irf_s0.logY_eg; irf_s1.logC_eg; irf_s0.logC_eg]);
set(h,'LineWidth',3);

subplot(4,4,5)
h=plot(xt, irf_s1.logY_eg,'-',xt, irf_s0.logY_eg,'--');
ylim([lb, ub]);
y=ylabel('$\epsilon_g$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
set(y, 'Units', 'Normalized', 'Position', [-0.37, 0.5, 0]);
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,6)
ylim([lb, ub]);
h=plot(xt, irf_s1.logC_eg,'-',xt, irf_s0.logC_eg,'--');
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,7)
h=plot(xt, irf_s1.pi_eg,'-',xt, irf_s0.pi_eg,'--');
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,8)
h=plot(xt, irf_s1.R_eg,'-',xt, irf_s0.R_eg,'--');
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
ub=max([irf_s1.logY_ed; irf_s0.logY_ed; irf_s1.logC_ed; irf_s0.logC_ed]);
lb=min([irf_s1.logY_ed; irf_s0.logY_ed; irf_s1.logC_ed; irf_s0.logC_ed]);
set(h,'LineWidth',3);

subplot(4,4,9)
h=plot(xt, irf_s1.logY_ed,'-',xt, irf_s0.logY_ed,'--');
ylim([lb, ub]);
y=ylabel('$\epsilon_d$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
set(y, 'Units', 'Normalized', 'Position', [-0.37, 0.5, 0]);
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,10)
h=plot(xt, irf_s1.logC_ed,'-',xt, irf_s0.logC_ed,'--');
ylim([lb, ub]);
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,11)
h=plot(xt, irf_s1.pi_ed,'-',xt, irf_s0.pi_ed,'--');
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,12)
h=plot(xt, irf_s1.R_ed,'-',xt, irf_s0.R_ed,'--');
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
ub=max([irf_s1.logY_er; irf_s0.logY_er; irf_s1.logC_er; irf_s0.logC_er]);
lb=min([irf_s1.logY_er; irf_s0.logY_er; irf_s1.logC_er; irf_s0.logC_er]);
set(h,'LineWidth',3);

subplot(4,4,13)
h= plot(xt, irf_s1.logY_er,'-',xt, irf_s0.logY_er,'--');
ylim([lb, ub]);
y=ylabel('$\epsilon_R$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
set(y, 'Units', 'Normalized', 'Position', [-0.37, 0.5, 0]);
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,14)
h=plot(xt, irf_s1.logC_er,'-',xt, irf_s0.logC_er,'--'); ylim([-0.1 0.1]);
ylim([lb, ub]);
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,15)
h=plot(xt, irf_s1.pi_er,'-',xt, irf_s0.pi_er,'--');
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

subplot(4,4,16)
h=plot(xt, irf_s1.R_er,'-',xt, irf_s0.R_er,'--');
beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
set(h,'LineWidth',3);

suptitle(['Impulse Response Functions: ' strrep(model_number,'_','-')]);
