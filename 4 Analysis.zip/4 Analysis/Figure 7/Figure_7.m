%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Figure 7: This script produces the one dimensional probability of a sunspot.
%           This files reads:
%
%             - HM_US4vGrowthC.txt, which is constructed from a long simulation
%             of inflation and interest rates in the U.S. 4vGrowth-C specification.
%             - HM_JP4vGapC.txt, which is constructed from a long simulation
%             of inflation and interest rates in the Japan 4vGap-C specification.

%
%             For example code on how to produce simulations see /Figure 5/
%--------------------------------------------------------------------------

clear; close all; clc;

addpath ../ExternalTools/       % Directory with external tools for plotting

%----------------------------
% SELECT MODEL
%----------------------------

model_name = 'JP4vGapC';


%----------------------------
% HOUSEKEEPING
%----------------------------

% Bounds for pi
ub_x = 2;
lb_x = -1;

%--------------------------------------------------------------------------
% LOAD DATA
%--------------------------------------------------------------------------

% LOAD JP HeatMap DATA
data = dlmread('datajp.txt','\t',1,0);

% Allocate Actual Data
infl_obs = data(:,2);
R_obs    = data(:,3);

% Pick ZLB observations
zlb_pick = find(R_obs==0);


% Keep only ZLB observations
infl_keep_jp = infl_obs(zlb_pick);
R_keep_jp    = R_obs(zlb_pick);

clearvars infl_obs R_obs zlb_pick data;

%----------------------------
% Load US Data
%----------------------------

data = dlmread('dataus.txt','\t',1,0);

% Allocate Actual Data
infl_obs = data(:,2);
R_obs    = data(:,3);

% Pick ZLB observations
zlb_pick = find(R_obs==0);

% Keep only ZLB observations
infl_keep_us = infl_obs(zlb_pick);
R_keep_us    = R_obs(zlb_pick);

clearvars infl_obs R_obs zlb_pick data;

%--------------------------------------------------------------------------
% COMPUTE KERNEL DENSITY FOR OBSERVATIONS AT ZLB
%--------------------------------------------------------------------------

% Step for bin separation along each dimention
stepx = 0.1;
nbins_data = 30;

% Identify the country
ctry = model_name(1:2);

if strcmp(ctry,'US')
% Compute optimal Bandwidth and kernel density - US
nobs    = length(infl_keep_us); % number of samples
bwus    = std(infl_keep_us)*(4/3/nobs)^(1/5);
[kdinf_data,xkdinf,~] = ksdensity(infl_keep_us,linspace(lb_x,ub_x,nbins_data),'Bandwidth',bwus);                %phat(pi|R=0,s=0)
plotname = 'U.S. 4vGrowth-C';
else
% Compute optimal Bandwidth and kernel density - Japan
nobs    = length(infl_keep_jp); % number of samples
bwjp    = std(infl_keep_jp)*(4/3/nobs)^(1/5);
[kdinf_data,xkdinf,~] = ksdensity(infl_keep_jp,linspace(lb_x,ub_x,nbins_data),'Bandwidth',bwjp);                %phat(pi|R=0,s=0)
plotname = 'Japan 4vGap-C';
end


%--------------------------------------------------------------------------
% COMPUTE KERNEL DENSITY FOR MODEL SIMULATED DATA
%--------------------------------------------------------------------------

%--------------------------------------
% Load simulated data and housekeeping
%--------------------------------------

% Load Simulation
M = dlmread(['HM_' model_name,'.txt'],'\t',1,0);

% Allocate Raw Simulated Data
infl = M(:,1);
R    = M(:,2);
sun  = M(:,3);

% Condition on s=0 and s=1
R1 = R(sun==1);
R0 = R(sun==0);

infl1 = infl(sun==1);
infl0 = infl(sun==0);

%--------------------------
% Select data for plotting
%--------------------------

% All simulated data | R=0
Ruse = R(R>=0 & R<=0.25 & infl>=lb_x &infl<=ub_x);
influse = infl(R>=0 & R<=0.25 & infl>=lb_x &infl<=ub_x);
sunuse = sun(R>=0 & R<=0.25 & infl>=lb_x &infl<=ub_x);


% Only s=1 data | R=0
R1use = R1(R1>=0 & R1<=0.25 & infl1>=lb_x &infl1<=ub_x);
infl1use = infl1(R1>=0 & R1<=0.25 & infl1>=lb_x &infl1<=ub_x);


% Only s=0 data | R=0
R0use = R0(R0>=0 & R0<=0.25 & infl0>=lb_x &infl0<=ub_x);
infl0use = infl0(R0>=0 & R0<=0.25 & infl0>=lb_x &infl0<=ub_x);


%-------------------------------------------------------
% Count observations for infl|R=0  and infl|R=0 and s=1
%-------------------------------------------------------

% Compute frequencies for simulated data
nbins2 = 100;
[nv2, xnv2]=hist(influse,nbins2);
[n1v2, xn1v2]=hist(infl1use,xnv2);

% Compute frequencies
freqv2 = nan(1,nbins2);
for jj=1:nbins2
    if nv2(1,jj)>0
        freqv2(1,jj) = n1v2(1,jj)/nv2(1,jj);
    end
end


%phat(pi|R=0,s=0)
[f0v2,infl_bins] = ksdensity(infl0use,linspace(lb_x,ub_x,nbins2),'Bandwidth',0.08);

%phat(pi|R=0,s=1)
if ~isempty(infl1use)
    [f1v2,xi1v2] = ksdensity(infl1use,linspace(lb_x,ub_x,nbins2),'Bandwidth',0.08);
else
    fprintf('f1 has no observations \n');
    f1v2 = zeros(1,length(f0v2));
    xi1v2 = infl_bins;
end

%P(s=1|R=0)
pp = sum(sunuse)/numel(sunuse);

%P(s=1|R=0,pi)
pdensity =  (f1v2*pp) ./ ((f1v2*pp) + f0v2*(1-pp));

%--------------------------------------------------------------------------
%                           PLOT FIGURE
%--------------------------------------------------------------------------

% Set Color Scheme
cuse = [
255 127 14;         % 3vGap
214 39 40;          % 4vGapC
44  160 44;         % 3vGrowth
31  119 180;        % 4vGrowthC
148,103,189;        % 4vGapG
219 161 58]./256;   % 4vGrowthG

figure(7); clf;
set(figure(7),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
h2 = area(xkdinf,kdinf_data); hold on;
plot(infl_bins,pdensity,'-','LineWidth',5,'color',cuse(2,:));
hline(0.9,'m--');hline(0.50,'m-');
set(h2,'EdgeColor',[0.9 0.9 0.9]);
set(h2,'FaceColor',[0.9 0.9 0.9]);
xlim([-1,2]); ylim([0,1]); box on
title(plotname,'FontSize',38,'Interpreter','Latex');
set(gca,'FontSize',32)
xlabel('Inflation $(\%)$','Interpreter','Latex');
