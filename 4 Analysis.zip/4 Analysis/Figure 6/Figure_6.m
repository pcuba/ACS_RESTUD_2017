%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Figure 6: This script produces the heatmap analyisis. This file reads the
%           following:
%             - HM_US4vGrowthC.txt, which is constructed from a long simulation
%             of inflation and interest rates in the U.S. 4vGrowth-C specification.
%
%             For example code on how to produce simulations see /Figure 5/
%--------------------------------------------------------------------------


clear; close all;
addpath ../ExternalTools/       % Directory with external tools for plotting

%----------------------------
% User defined options
%----------------------------

model_number = 'US4vGrowthC';

% Bounds for pi
ub_x = 2;
lb_x = -1;

% Bounds for R
ub_y = 1;
lb_y = 0;

% Step for bin separation along each dimention
stepy = 0.05;
stepx = 0.1;

%--------------------------------------------------------------------------
% Load data and housekeeping
%--------------------------------------------------------------------------

% Load Simulation
M = dlmread(['HM_' model_number,'.txt'],'\t',1,0);


% Allocate Raw Simulated Data
infl = M(:,1);
R    = M(:,2);
sun  = M(:,3);

% Condition on s=0 and s=1
R1 = R(sun==1);
R0 = R(sun==0);

infl1 = infl(sun==1);
infl0 = infl(sun==0);

%--------------------------
% Select data for plotting
%--------------------------

% All simulated data
Ruse = R(R>=lb_y & R<=ub_y & infl>=lb_x &infl<=ub_x);
influse = infl(R>=lb_y & R<=ub_y & infl>=lb_x &infl<=ub_x);
sunuse = sun(R>=lb_y & R<=ub_y & infl>=lb_x &infl<=ub_x);

% Only s=1 data
R1use = R1(R1>=lb_y & R1<=ub_y & infl1>=lb_x &infl1<=ub_x);
infl1use = infl1(R1>=lb_y & R1<=ub_y & infl1>=lb_x &infl1<=ub_x);

% Set bin intervals
yb = lb_y:stepy:ub_y;
xb = lb_x:stepx:ub_x;

% Count number of bins in each dimention
nbins(1) = numel(xb)-1;
nbins(2) = numel(yb)-1;

%------------------------------
% Count frequencies in each bin
%------------------------------

nn=zeros(nbins(2),nbins(1));
for ii=1:nbins(1)
    for jj=1:nbins(2)
       nn(jj,ii) = numel(R(R>=yb(jj) & R<=yb(jj+1) & infl>=xb(ii) & infl<=xb(ii+1)));
    end
end

nn = nn';
nn(size(nn,1) + 1, size(nn,2) + 1) = 0;

nn1=zeros(nbins(2),nbins(1));
for ii=1:nbins(1)
    for jj=1:nbins(2)
       nn1(jj,ii) = numel(R1(R1>=yb(jj) & R1<=yb(jj+1) & infl1>=xb(ii) & infl1<=xb(ii+1)));
    end
end

nn1 = nn1';
nn1(size(nn1,1) + 1, size(nn1,2) + 1) = 0;

% Compute relative frequencies of S=1 observations in each bin.
freq = nan(nbins(1)+1,nbins(2)+1);
for ii=1:nbins(1)+1
    for jj=1:nbins(2)+1
        if nn(ii,jj)>0
            freq(ii,jj) = nn1(ii,jj)/nn(ii,jj);
        end
    end
end
%%
%--------------------------------------------------------------------------
% Figure 6: Prob(s=1| R, pi) overlaying data
%--------------------------------------------------------------------------
figure(6);clf;
set(figure(6),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
h1 = pcolor(xb(1:end-1),yb(1:end-1),freq(1:end-1,1:end-1)'); hold on;
grid off
colormap(jet)
shading(gca,'interp')
h = colorbar;
caxis([0 1])
set(h, 'ylim', [0 1])
xlabel('Inflation $(\%)$','Fontsize',16);ylabel('Interest Rate $(\%)$','Fontsize',16)
title('$P(s_t=1|\pi_t,R_t)$','Fontsize',16,'Interpreter','Latex')
