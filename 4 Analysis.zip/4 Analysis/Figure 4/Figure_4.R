'==========================================================================
'      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
'                  (Aruoba, Cuba-Borda, Schorfheide)
'
' Figure 4: Contour map for U.S. 4vGrowth-C model.
'
' This code reads the following data:
'       dataus.txt: is U.S. data used for filtering.
'       SIM_4vGrowthC.txt: simulation of inflation and interest rates from
'       Sunspot model. For example code on how to simulate the sunspot model
'       see /Figure 5/
'
'
' This code is written in R.
'==========================================================================

library(MASS)
library(RColorBrewer)
library(extrafont)
font_import()

model_name <- "SIM_4vGrowthC"
model_file = paste(model_name,".txt",sep='')

' GET DATA'
data_in <- read.delim("dataus.txt")
attach(data_in);

'GET SIMULATIONS'
simus <- read.delim(model_file)
attach(simus);

'Options for Contour Level Lines'
prob1 <- c(.99,0.95,0.90,0.80,0.70,0.60,0.5,0.4,0.3,0.2,0.1)
prob0 <- c(.99,0.95,0.90,0.80,0.70,0.60,0.5)

'Define Color Scheme'
k <- 11
my.cols <- rev(brewer.pal(k, "RdYlBu"))

'----------------------------'
' GET DENSITY FOR ALL US DATA'
'----------------------------'

xall <- sim_infl
yall <- sim_R

r <- quantile(xall, c(0.25, 0.75))
hx <- (r[2] - r[1])/1.34
4 * 1.06 * min(sqrt(var(xall)), hx) * length(xall)^(-1/5)

r <- quantile(yall, c(0.25, 0.75))
hy <- (r[2] - r[1])/1.34
4 * 1.06 * min(sqrt(var(yall)), hy) * length(yall)^(-1/5)
bandwithall_us = c(hx,hy)


'----------------------------'
' KDENSITY FOR US (S=1)'
'----------------------------'

x<-sim_infl[sun1==1]
y<-sim_R[sun1==1]

r <- quantile(x, c(0.05, 0.95))
hx <- (r[2] - r[1])/1.34
4 * 1.06 * min(sqrt(var(x)), hx) * length(x)^(-1/5)

r <- quantile(y, c(0.05, 0.95))
hy <- (r[2] - r[1])/1.34
4 * 1.06 * min(sqrt(var(y)), hy) * length(y)^(-1/5)
bandwith = c(hx,hy)

dens_S1 <- kde2d(x, y,bandwith, n=100); ## estimate the z counts'

dx <- diff(dens_S1$x[1:2])
dy <- diff(dens_S1$y[1:2])
sz <- sort(dens_S1$z)
c1 <- cumsum(sz) * dx * dy
levels_us1 <- sapply(prob1, function(x) {
  approx(c1, sz, xout = 1 - x)$y
})


'----------------------------'
' KDENSITY FOR US (S=0)'
'----------------------------'

x<-sim_infl[sun1==0]
y<-sim_R[sun1==0]

r <- quantile(x, c(0.05, 0.95))
hx <- (r[2] - r[1])/1.34
4 * 1.06 * min(sqrt(var(x)), hx) * length(x)^(-1/5)

r <- quantile(y, c(0.05, 0.95))
hy <- (r[2] - r[1])/1.34
4 * 1.06 * min(sqrt(var(y)), hy) * length(y)^(-1/5)
bandwith = c(hx,hy)

dens_S0 <- kde2d(x, y,bandwith, n=100,lims=c(-10,5,0,8)); ## estimate the z counts'


dx <- diff(dens_S0$x[1:2])
dy <- diff(dens_S0$y[1:2])
sz <- sort(dens_S0$z)
c1 <- cumsum(sz) * dx * dy
levels_us0 <- sapply(prob0, function(x) {
  approx(c1, sz, xout = 1 - x)$y
})


'----------------------------'
' PLOT FIGURE '
'----------------------------'
pdf_name = paste("Figure4_Contour_4vGrowthC.pdf",sep='')
eps_name = paste("Figure4_Contour_4vGrowthC.eps",sep='')
#pdf(file = pdf_name,family="Helvetica",width=8, height=6.5)
postscript(file = eps_name,family="Helvetica",width=8.5, height=11)

# Configure margins and fonts
par( mfrow = c( 1, 1 ) ,oma = c(0, 0, 0.5, 0))
par(ps = 12, cex = 1.15, cex.main = 1.15, family="Helvetica")
par(mar=c(4.0,4.0,1.5,1.5),oma=c(2.5,1.5,1.5,1.5))


'Plot contours: S1 + S0'
contour(dens_S1, levels=levels_us1, labels=prob1,col=my.cols, xlab='Inflation (%)',ylab="Nominal Rate (%)",xlim=c(-10,10),ylim=c(0,12),xaxs="i", yaxs="i",cex.axis=1,cex.lab=1.15,labcex=0.8)
par(new=T)
contour(dens_S0, levels=levels_us0, labels=prob0,col=my.cols, xlab='',ylab="",xlim=c(-10,10),ylim=c(0,12),xaxs="i", yaxs="i",cex.axis=1,cex.lab=1.15,labcex=0.8)
dev.off()
