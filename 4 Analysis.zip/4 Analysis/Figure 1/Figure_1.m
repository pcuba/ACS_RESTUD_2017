%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Figure 1: Inflation Dynamics in the Two-Equation Model
%
% This script solves the two-equation example of section 2 using the
% parameters detailed in the main text and produces simulated paths of
% inflation for the targeted-inflation, deflation and sunspot equilibrium
%
%--------------------------------------------------------------------------

close all; clear; clc;

addpath ../ExternalTools/       % Path with external tools for plotting
addpath ../Common/              % Path containing common functions

set(0,'defaulttextinterpreter','latex')

global pistar rstar rho sig psi rho1 rho0

%------------------------------------
% Parameters for two-equation example
%------------------------------------

rho    = 0.90;
sig    = 0.0007;
psi    = 1.5;
pistar = 1.005013;
rstar  = 1.005013;
rho1   = 0.99;
rho0   = 0.95;

%--------------------------------------
% Solve for decision rule coefficients
%--------------------------------------
options=optimset('MaxIter',100,'TolFun',1e-16,'TolX',1e-16,'Display','iter');
x0=ones(4,1);

[x1,Fval,flag]=fsolve(@system4x4,x0,options);

if flag < 1
    error('Solver did not converge nicely')
end

theta10 = x1(1); % s = 1, constant
theta11 = x1(2); % s = 1, slope
theta00 = x1(3); % s = 0, constant
theta01 = x1(4); % s = 0, slope

theta_star = rho/(psi-rho);
theta_D = -1;

% Check Condition

if psi*theta10 <= -log(pistar*rstar) || psi*theta00 >= -log(pistar*rstar)
    error('Conditions for thetas are not verified.')
end

%------------------------------------
%           Simulation
%------------------------------------
% Set seed
rng(092677)

% Number of periods
T = 2000;
Tdrop = 500;

% Sunspot Draws (Markov process)
sunspot_initial = 1;
Nrep = 1;
SUNSPOT = get_sunspot(T,sunspot_initial,Tdrop,Nrep);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SUNSPOT = SUNSPOT(Tdrop+1:end);
SUNSPOT = SUNSPOT(721:1220);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Innovation Draws for r
eps = normrnd(0,1,T+Tdrop,1);

r_hat = zeros(1,T+Tdrop);
for t = 2:T+Tdrop
    r_hat(t) = rho*r_hat(t-1) + sig*eps(t);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% r_hat = r_hat(:,Tdrop+1:end);
r_hat = r_hat(:,101:600);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

r = rstar*exp(r_hat);
r_net_a = 400*log(r);

%--------------------------------------------
% Targeted-inflation and Deflation Solutions
%--------------------------------------------
pi_star =  400*log(pistar) + 400*rho/(psi-rho)*r_hat;
pi_D    = -400*log(rstar) - 400*r_hat;

% Nominal Rate R Under Star Solution
pi_star_gross_q = 1+pi_star/400;
R_ZLB = max(1,rstar*pistar*(pi_star_gross_q/pistar).^psi);
R = rstar*pistar*(pi_star_gross_q/pistar).^psi;
R_ZLB_net_a = 400*log(R_ZLB);
R_net_a = 400*log(R);

%------------------------------------
% Sunspot Solution
%------------------------------------

TT = size(SUNSPOT,1);

pi_S = zeros(1,TT);
for t = 1:TT

    if SUNSPOT(t) == 1
        pi_S(t) = 400*log(pistar) + 400*theta10 + 400*theta11*r_hat(t);
    else
        pi_S(t) = 400*log(pistar) + 400*theta00 + 400*theta01*r_hat(t);
    end

end

% Sunspot switches

sun_init = [];
sun_end  = [];

for t = 2:TT-1
    if SUNSPOT(t) == 0 && SUNSPOT(t-1) == 1
        sun_init = [sun_init;t];
    end
    if SUNSPOT(t) == 0 && SUNSPOT(t+1) == 1
        sun_end = [sun_end;t];
    end
end

%------------------------------------
% Figures
%------------------------------------

figure(1)
set(figure(1),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.1 0.1 11 8.5])
hold on
plot(1:TT,pi_star,'b','LineWidth',2)
plot(1:TT,pi_D,   'r','LineWidth',2)
plot(1:TT,zeros(1,TT),'k','LineWidth',2)
hold off
title('Targeted-Inflation and Deflation Equilibria','FontSize',20)
box on
xticks = [100 200 300 400 500];
xticks_label = {'100';'200';'300';'400';'500'};
set(gca,'XTick',xticks);
set(gca,'XTickLabel',xticks_label);
ylim([-5 5])
yticks = [-5 -4 -3 -2 -1 0 1 2 3 4 5];
yticks_label = {'-5';'-4';'-3';'-2';'-1';'0';'1';'2';'3';'4';'5'};
set(gca,'YTick',yticks);
set(gca,'YTickLabel',yticks_label);
set(gca,'FontSize',30);
xlim([0 500])


figure(2)
set(figure(2),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.1 0.1 11 8.5])
hold on
plot(1:TT,pi_S,'g','LineWidth',2)
plot(1:TT,zeros(1,TT),'k','LineWidth',2)
shade(sun_init,sun_end)
hold off
title('Sunspot Equilibrium','FontSize',20)
box on
xticks = [100 200 300 400 500];
xticks_label = {'100';'200';'300';'400';'500'};
set(gca,'XTick',xticks);
set(gca,'XTickLabel',xticks_label);
yticks = [-5 -4 -3 -2 -1 0 1 2 3 4 5];
yticks_label = {'-5';'-4';'-3';'-2';'-1';'0';'1';'2';'3';'4';'5'};
set(gca,'YTick',yticks);
set(gca,'YTickLabel',yticks_label);
set(gca,'FontSize',30);
xlim([0,500]);


% Print Figures
% print(figure(1),'-dsvg','-r600','svg/simple_model_2eq_clip.svg');
% print(figure(2),'-dsvg','-r600','svg/simple_model_sun_clip.svg');
