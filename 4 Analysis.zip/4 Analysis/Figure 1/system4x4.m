% System of equilibrium conditions to solve the decision rules of simple
% two-equation example of section 2. 

function OUT=system4x4(x0)

global pistar rstar rho psi rho1 rho0

theta10 = x0(1); % s = 1, constant
theta11 = x0(2); % s = 1, slope
theta00 = x0(3); % s = 0, constant
theta01 = x0(4); % s = 0, slope

OUT(1) = rho1*theta10 + (1-rho1)*theta00 - psi*theta10;
OUT(2) = rho1*theta11 + (1-rho1)*theta01 - psi*theta11/rho + 1;
OUT(3) = rho0*theta00 + (1-rho0)*theta10 + log(rstar*pistar);
OUT(4) = rho0*theta01 + (1-rho0)*theta11 + 1;