%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
%
% Figure 11: Filtered Probability of Targeted-Inflation Regime with
% Inflation Expectations
%
% This script reads data from Figure_FilteredSunspotINFEXP.xlsx which
% collects the output from the particle filter for each of the models.
%
% The source files to produce the filtered states are stored in the
% following folders:
%
% /Filtereing/USJP3vGrowthInflExp.
%
% See /Filtering/Readme.txt for details.
%--------------------------------------------------------------------------

clear; clc; close all;
addpath ../ExternalTools/       % Path with external tools for plotting

[ndata, text, ~] = xlsread('Figure_FilteredSunspotINFEXP.xlsx','Fig11');

[nobs,nseries] = size(ndata);

for jj=1:nseries
    eval([text{1,jj} ' = ndata(:,jj);']);
end


% JP start of first ZLB observation
zlb_jp = 1999;

% US start of first ZLB observation
zlb_us = 2009;

%%
cuse = [
255 127 14;         % Gap 3v
214 39 40;          % Gap 4v
44  160 44;         % Growth 3v
31  119 180;        % Growth 4v
148,103,189;        % Gap 4v G
219 161 58          % Model Inf Exp
0 0 0               % Data Inf Exp
200 82 0]./256;     % Growth 4v G


%--------------------------------------------------------------------------
% PLOT INDIVIDUAL FIGURES
%--------------------------------------------------------------------------

figure(111); clf;
set(figure(111),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,USGrowth3,'-','LineWidth',5,'color',cuse(3,:)); hold on;
plot(Period,USGrowth3InfExp,'--','LineWidth',5,'color',cuse(2,:))
xlim([2004,2015.05]); ylim([0,1.025]);ylim_use = ylim;
plot(zlb_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
hline(0.83,'m--'); hline(0.5,'m-');
title('U.S.','FontSize',38,'Interpreter','Latex');
set(gca,'FontSize',32)
[l1,icons,~,~]=legend('3vGrowth', '3vGrowth+\pi^e','Location','SE'); legend boxoff
set(l1,'FontSize',32);
%//========================
%// Change the legend here
%//========================
%// Get the handles for legends
h3vGrowth  = icons(3);
h4vGrowthEpi = icons(5);
%// Fetch its XData property
LineData = get(h3vGrowth,'XData');
LinePos  = get(icons(1),'Position');
NewData = [LineData(1)-0.245 LineData(2)-0.155];
set(h3vGrowth,'XData',NewData,'LineWidth',5)
set(icons(1),'Position',[LinePos(1)-0.145 LinePos(2) LinePos(3)],'FontSize',32);
%// Fetch its XData property
LineData = get(h4vGrowthEpi,'XData');
LinePos  = get(icons(2),'Position');
NewData = [LineData(1)-0.25 LineData(2)-0.15];
set(h4vGrowthEpi,'XData',NewData,'LineWidth',5)
set(icons(2),'Position',[LinePos(1)-0.145 LinePos(2) LinePos(3)],'FontSize',32);


figure(112); clf;
set(figure(112),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,JPGrowth3,'-','LineWidth',5,'color',cuse(3,:)); hold on;
plot(Period,JPGrowth3InfExp,'--','LineWidth',5,'color',cuse(2,:))
hline(0.9,'m--'); hline(0.5,'m-');
xlim([1994,2015]); ylim([0,1.025]);ylim_use = ylim;
plot(zlb_jp*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('Japan','FontSize',38,'Interpreter', 'Latex');
set(gca,'FontSize',32)
[l2,icons,~,~]=legend('3vGrowth', '3vGrowth+\pi^e','Location','S'); legend boxoff


%//========================
%// Change the legend here
%//========================
%// Get the handles for legends
h3vGrowth  = icons(3);
h4vGrowthEpi = icons(5);
%// Fetch its XData property
LineData = get(h3vGrowth,'XData');
LinePos  = get(icons(1),'Position');
NewData = [LineData(1)-0.19 LineData(2)-0.06];
set(h3vGrowth,'XData',NewData,'LineWidth',5)
set(icons(1),'Position',[LinePos(1)-0.06 LinePos(2) LinePos(3)],'FontSize',32);
%// Fetch its XData property
LineData = get(h4vGrowthEpi,'XData');
LinePos  = get(icons(2),'Position');
NewData = [LineData(1)-0.2 LineData(2)];
set(h4vGrowthEpi,'XData',NewData,'LineWidth',5)
set(icons(2),'Position',[LinePos(1)-0.06 LinePos(2) LinePos(3)],'FontSize',32);


figure(113); clf;
set(figure(113),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,INFEXP_USData+0.9378,'-','LineWidth',5,'color',cuse(7,:)); hold on;
plot(Period,INFEXP_USGrowth3+0.9378,'--','LineWidth',5,'color',cuse(2,:))
xlim([2004,2015]); ylim([0 2.6]);ylim_use = ylim;
plot(zlb_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('U.S.','FontSize',38,'Interpreter','Latex');
set(gca,'FontSize',32);
[l1,icons,~,~]=legend('Data','Model','Location','SE'); legend boxoff
set(l1,'FontSize',32);

%//========================
%// Change the legend here
%//========================
%// Get the handles for legends
h3vGrowth  = icons(3);
h4vGrowthEpi = icons(5);
%// Fetch its XData property
LineData = get(h3vGrowth,'XData');
LinePos  = get(icons(1),'Position');
NewData = [LineData(1)-0.15 LineData(2)+0.025];
set(h3vGrowth,'XData',NewData,'LineWidth',5)
set(icons(1),'Position',[LinePos(1)+0.025 LinePos(2) LinePos(3)],'FontSize',32);
%// Fetch its XData property
LineData = get(h4vGrowthEpi,'XData');
LinePos  = get(icons(2),'Position');
NewData = [LineData(1)-0.175 LineData(2)+0.1];
set(h4vGrowthEpi,'XData',NewData,'LineWidth',5)
set(icons(2),'Position',[LinePos(1)+0.025 LinePos(2) LinePos(3)],'FontSize',32);

figure(114); clf;
set(figure(114),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,INFEXP_JPData+1.1325,'-','LineWidth',5,'color',cuse(7,:)); hold on;
plot(Period,INFEXP_JPGrowth3+1.1325,'--','LineWidth',5,'color',cuse(2,:))
xlim([1994,2015.1]); ylim([0 2.6]);ylim_use = ylim;
plot(zlb_jp*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('Japan','FontSize',38,'Interpreter', 'Latex');
set(gca,'FontSize',32);
[l1,icons,~,~]=legend('Data','Model','Location','SE'); legend boxoff
set(l1,'FontSize',32);

%//========================
%// Change the legend here
%//========================
%// Get the handles for legends
h3vGrowth  = icons(3);
h4vGrowthEpi = icons(5);
%// Fetch its XData property
LineData = get(h3vGrowth,'XData');
LinePos  = get(icons(1),'Position');
NewData = [LineData(1)-0.15 LineData(2)+0.025];
set(h3vGrowth,'XData',NewData,'LineWidth',5)
set(icons(1),'Position',[LinePos(1)+0.025 LinePos(2) LinePos(3)],'FontSize',32);
%// Fetch its XData property
LineData = get(h4vGrowthEpi,'XData');
LinePos  = get(icons(2),'Position');
NewData = [LineData(1)-0.175 LineData(2)+0.1];
set(h4vGrowthEpi,'XData',NewData,'LineWidth',5)
set(icons(2),'Position',[LinePos(1)+0.025 LinePos(2) LinePos(3)],'FontSize',32);


% print(figure(111),'-dsvg','-r600','svg/Fig_InfExp_1.svg')
% print(figure(112),'-dsvg','-r600','svg/Fig_InfExp_2.svg')
% print(figure(113),'-dsvg','-r600','svg/Fig_InfExp_3.svg')
% print(figure(114),'-dsvg','-r600','svg/Fig_InfExp_4.svg')
