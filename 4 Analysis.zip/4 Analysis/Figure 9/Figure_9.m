%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Figure 9: Filtered Probability of Targeted-Inflation Regime.
%
% This script reads data from Figure_FilteredSunspot.xlsx which collects
% the output from the particle filter for each of the models.
%
% The source files to produce the filtered states are stored in the
% following folders:
%
%   /Filtereing/USJP3vGap.
%   /Filtereing/USJP3vGrowth.
%   /Filtereing/USJP4vGapC.
%   /Filtereing/USJP4vGapG.
%   /Filtereing/USJP4vGrowthC.
%   /Filtereing/USJP4vGrowthG.
%
% See /Filtering/Readme.txt for details.
%--------------------------------------------------------------------------

clear; clc; close all;

addpath ../ExternalTools/       % Path with external tools for plotting

% JP start of first ZLB observation
zlb_jp = 1999;

% US start of first ZLB observation
zlb_us = 2009;

[ndata, text, ~] = xlsread('Figure_FilteredSunspot.xlsx','Fig9');

[nobs,nseries] = size(ndata);

for jj=1:nseries
    eval([text{1,jj} ' = ndata(:,jj);']);
end

cuse = [
255 127 14;         % Gap 3v
214 39 40;          % Gap 4v
44  160 44;         % Growth 3v
31  119 180;        % Growth 4v
148,103,189;        % Gap 4v G
219 161 58]./256;   % Growth 4v G


%==========================================================================
% 2x3 INDIVIDUAL PANELS - US
%==========================================================================

figure(81); clf;
set(figure(81),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,USGap3,'-','LineWidth',5,'color',cuse(4,:)); hold on;
xlim([2004,2015]); ylim([0,1.025]);
hline(0.83,'m--'); hline(0.5,'m-'); ylim_use = ylim;
plot(zlb_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('3vGap','FontSize',42,'Interpreter','Latex');
set(gca,'XTick',[2005 2007 2009 2011 2013 2015]);
set(gca,'FontSize',36)

figure(82); clf;
set(figure(82),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,USGap4C,'-','LineWidth',5,'color',cuse(4,:)); hold on;
xlim([2004,2015]); ylim([0,1.025]);
hline(0.83,'m--'); hline(0.5,'m-'); ylim_use = ylim;
plot(zlb_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('4vGap-C','FontSize',42,'Interpreter','Latex');
set(gca,'XTick',[2005 2007 2009 2011 2013 2015]);
set(gca,'FontSize',36)

figure(83); clf;
set(figure(83),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,USGap4G,'-','LineWidth',5,'color',cuse(4,:)); hold on;
xlim([2004,2015]); ylim([0,1.025]);
hline(0.83,'m--'); hline(0.5,'m-'); ylim_use = ylim;
plot(zlb_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('4vGap-G','FontSize',42,'Interpreter','Latex');
set(gca,'XTick',[2005 2007 2009 2011 2013 2015]);
set(gca,'FontSize',36)

figure(84); clf;
set(figure(84),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,USGrowth3,'-','LineWidth',5,'color',cuse(4,:)); hold on;
hline(0.83,'m--'); hline(0.5,'m-');
xlim([2004,2015]); ylim([0,1.01]); ylim_use = ylim;
plot(zlb_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('3vGrowth','FontSize',42,'Interpreter','Latex');
set(gca,'XTick',[2005 2007 2009 2011 2013 2015]);
set(gca,'FontSize',36);


figure(85); clf;
set(figure(85),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,USGrowth4C,'-','LineWidth',5,'color',cuse(4,:)); hold on
hline(0.83,'m--'); hline(0.5,'m-');
xlim([2004,2015]); ylim([0,1.01]); ylim_use = ylim;
plot(zlb_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('4vGrowth-C','FontSize',42,'Interpreter','Latex');
set(gca,'XTick',[2005 2007 2009 2011 2013 2015]);
set(gca,'FontSize',36);


figure(86); clf;
set(figure(86),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,USGrowth4G,'-','LineWidth',5,'color',cuse(4,:));hold on
hline(0.83,'m--'); hline(0.5,'m-');
xlim([2004,2015]); ylim([0,1.01]); ylim_use = ylim;
plot(zlb_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('4vGrowth-G','FontSize',42,'Interpreter','Latex');
set(gca,'XTick',[2005 2007 2009 2011 2013 2015]);
set(gca,'FontSize',36);



%==========================================================================
% 2x3 INDIVUAL PANELS - JP
%==========================================================================

figure(91); clf;
set(figure(91),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,JPGap3,'-','LineWidth',5,'color',cuse(4,:)); hold on;
hline(0.9,'m--'); hline(0.5,'m-');
xlim([1994,2015]); ylim([0,1.01]);ylim_use = ylim;
plot(zlb_jp*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('3vGap','FontSize',42,'Interpreter', 'Latex');
set(gca,'FontSize',36);

figure(92); clf;
set(figure(92),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,JPGap4C,'-','LineWidth',5,'color',cuse(4,:)); hold on;
hline(0.9,'m--'); hline(0.5,'m-');
xlim([1994,2015]); ylim([0,1.01]);ylim_use = ylim;
plot(zlb_jp*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('4vGap-C','FontSize',42,'Interpreter', 'Latex');
set(gca,'FontSize',36);

figure(93); clf;
set(figure(93),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,JPGap4G,'-','LineWidth',5,'color',cuse(4,:)); hold on;
hline(0.9,'m--'); hline(0.5,'m-');
xlim([1994,2015]); ylim([0,1.01]);ylim_use = ylim;
plot(zlb_jp*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('4vGap-G','FontSize',42,'Interpreter', 'Latex');
set(gca,'FontSize',36);

figure(94); clf;
set(figure(94),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,JPGrowth3,'-','LineWidth',5,'color',cuse(4,:)); hold on;
hline(0.9,'m--'); hline(0.5,'m-');
xlim([1994,2015]); ylim([0,1.01]);ylim_use = ylim;
plot(zlb_jp*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('3vGrowth','FontSize',42,'Interpreter', 'Latex');
set(gca,'FontSize',36);


figure(95); clf;
set(figure(95),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,JPGrowth4C,'-','LineWidth',5,'color',cuse(4,:)); hold on;
hline(0.9,'m--'); hline(0.5,'m-');
xlim([1994,2015]); ylim([0,1.01]);ylim_use = ylim;
plot(zlb_jp*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('4vGrowth-C','FontSize',42,'Interpreter', 'Latex');
set(gca,'FontSize',36);


figure(96); clf;
set(figure(96),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
plot(Period,JPGrowth4G,'-','LineWidth',5,'color',cuse(4,:)); hold on;
hline(0.9,'m--'); hline(0.5,'m-');
xlim([1994,2015]); ylim([0,1.01]);ylim_use = ylim;
plot(zlb_jp*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('4vGrowth-G','FontSize',42,'Interpreter', 'Latex');
set(gca,'FontSize',36);



%
% % Print US plots to svg
% print(figure(81),'-dsvg','-r600','svg/Fig_SUN_Filtered_US_3vGap.svg')
% print(figure(82),'-dsvg','-r600','svg/Fig_SUN_Filtered_US_4vGap-C.svg')
% print(figure(83),'-dsvg','-r600','svg/Fig_SUN_Filtered_US_4vGap-G.svg')
% print(figure(84),'-dsvg','-r600','svg/Fig_SUN_Filtered_US_3vGrowth.svg')
% print(figure(85),'-dsvg','-r600','svg/Fig_SUN_Filtered_US_4vGrowth-C.svg')
% print(figure(86),'-dsvg','-r600','svg/Fig_SUN_Filtered_US_4vGrowth-G.svg')
%
% % Print Japan plots to svg
% print(figure(91),'-dsvg','-r600','svg/Fig_SUN_Filtered_JP_3vGap.svg')
% print(figure(92),'-dsvg','-r600','svg/Fig_SUN_Filtered_JP_4vGap-C.svg')
% print(figure(93),'-dsvg','-r600','svg/Fig_SUN_Filtered_JP_4vGap-G.svg')
% print(figure(94),'-dsvg','-r600','svg/Fig_SUN_Filtered_JP_3vGrowth.svg')
% print(figure(95),'-dsvg','-r600','svg/Fig_SUN_Filtered_JP_4vGrowth-C.svg')
% print(figure(96),'-dsvg','-r600','svg/Fig_SUN_Filtered_JP_4vGrowth-G.svg')
