
%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Figure 12: Filtered Shock Innovations
%
% This script reads data from Figure_FilteredInnovations.xlsx which
% collects the average filtered states obtained with the particle filter.
%
% The source files to produce the filtered states are stored in the
% following folders.
%
% /Filtereing/USJP4vGrowthC/
% /Filtereing/USJP4vGapC/
%
% See /Filtering/Readme.txt for details.
%
%
%--------------------------------------------------------------------------

clear; clc; close all;

addpath ../ExternalTools/       % Path with external tools for plotting

model_name_us = 'US4vGrowthC';
par_us.sig_z  = 0.0046;
par_us.sig_d  = 0.0184;
par_us.sig_r  = 0.0016;
par_us.sig_g  = 0.0046;
par_us.enddate= 2007.75;
par_us.startzlb= 2009;

model_name_jp = 'JP4vGapC';
par_jp.sig_z  = 0.0109;
par_jp.sig_d  = 0.0137;
par_jp.sig_r  = 0.0019;
par_jp.sig_g  = 0.0077;
par_jp.enddate= 1994.75;
par_jp.startzlb= 1998;


%--------------------------------------------------------------------------
% US filtered innovations
%--------------------------------------------------------------------------

[ndata, text, ~] = xlsread('Figure_FilteredInnovations.xlsx',model_name_us);
[~,nseries] = size(ndata);
for jj=1:nseries
    eval([text{1,jj} ' = ndata(:,jj);']);
end

% Parameters for US plot
enddate  = par_us.enddate;
startzlb = par_us.startzlb;
sig_z    = par_us.sig_z;
sig_d    = par_us.sig_d;
sig_r    = par_us.sig_r;
sig_g    = par_us.sig_g;

%load Filtered_Shocks_Growth4US4.mat
figure(12); clf;
set(figure(12),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
subplot_tight(4,2,1,0.07)
plot(dates,epsz / sig_z,'b','linewidth',2);
plot(linspace(dates(1),dates(end),200),0*ones(200,1),'-','LineWidth',1,'color',[0.74 0.74 0.74]);hold on;
plot(dates,epsz / sig_z,'b','linewidth',2);hold;
axis tight; set(gca,'Ytick',[-4:2:4]); ylim([-4,3]);
vline(enddate,'r-')
vline(startzlb,'r--')
ylabel('Technology Growth $\epsilon_z$','fontweight','bold','fontsize',12,'Interpreter','latex')
title('U.S. 4vGrowth-C','FontSize',18,'Interpreter','Latex');
set(gca,'FontSize',14)

subplot_tight(4,2,3,0.07)
plot(linspace(dates(1),dates(end),200),0*ones(200,1),'-','LineWidth',1,'color',[0.74 0.74 0.74]);hold
plot(dates,epsg / sig_g,'b','linewidth',2);hold;
axis tight;
vline(enddate,'r-')
vline(startzlb,'r--')
ylabel('Government Spending $\epsilon_g$','fontweight','bold','fontsize',12,'Interpreter','latex')
set(gca,'FontSize',14)

subplot_tight(4,2,5,0.07)
plot(linspace(dates(1),dates(end),200),0*ones(200,1),'-','LineWidth',1,'color',[0.74 0.74 0.74]);hold
plot(dates,epsd / sig_d,'b','linewidth',2);hold;
axis tight; set(gca,'Ytick',[-3:1:3]); ylim([-3,3]);
vline(enddate,'r-')
vline(startzlb,'r--')
ylabel('Discount Factor $\epsilon_d$','fontweight','bold','fontsize',12,'Interpreter','latex')
set(gca,'FontSize',14)

subplot_tight(4,2,7,0.07)
plot(linspace(dates(1),dates(end),200),0*ones(200,1),'-','LineWidth',1,'color',[0.74 0.74 0.74]);hold
plot(dates,epsr / sig_r,'b','linewidth',2);hold;
axis tight; set(gca,'Ytick',[-3:1:3]); ylim([-2,2]);
vline(enddate,'r-')
vline(startzlb,'r--')
ylabel('Monetary Policy $\epsilon_R$','fontweight','bold','fontsize',12,'Interpreter','latex')
set(gca,'FontSize',14)


%--------------------------------------------------------------------------
% Japan filtered innovations
%--------------------------------------------------------------------------


clearvars -except model_name_jp par_jp

[ndata, text, ~] = xlsread('Figure_FilteredInnovations.xlsx',model_name_jp);
[nobs,nseries] = size(ndata);
for jj=1:nseries
    eval([text{1,jj} ' = ndata(:,jj);']);
end

% Parameters for JP plot
enddate  = par_jp.enddate;
startzlb = par_jp.startzlb;
sig_z    = par_jp.sig_z;
sig_d    = par_jp.sig_d;
sig_r    = par_jp.sig_r;
sig_g    = par_jp.sig_g;

subplot_tight(4,2,2,0.07)
plot(linspace(dates(1),dates(end),200),0*ones(200,1),'-','LineWidth',1,'color',[0.74 0.74 0.74]);hold
plot(dates,epsz / sig_z,'b','linewidth',2);hold;
axis tight; set(gca,'Ytick',[-4:2:4]); ylim([-4,3]);
vline(enddate,'r-')
vline(startzlb,'r--')
title('Japan 4vGap-C','FontSize',18,'Interpreter','Latex');
set(gca,'FontSize',14)

subplot_tight(4,2,4,0.07)
plot(linspace(dates(1),dates(end),200),0*ones(200,1),'-','LineWidth',1,'color',[0.74 0.74 0.74]);hold
plot(dates,epsg / sig_g,'b','linewidth',2);hold;
axis tight;set(gca,'Ytick',[-4:2:4]); ylim([-4,4]);
vline(enddate,'r-')
vline(startzlb,'r--')
set(gca,'FontSize',14)

subplot_tight(4,2,6,0.07)
plot(linspace(dates(1),dates(end),200),0*ones(200,1),'-','LineWidth',1,'color',[0.74 0.74 0.74]);hold
plot(dates,epsd / sig_d,'b','linewidth',2);hold;
axis tight; set(gca,'Ytick',[-4:2:4]); ylim([-4,5]);
vline(enddate,'r-')
vline(startzlb,'r--')
set(gca,'FontSize',14)

subplot_tight(4,2,8,0.07)
plot(linspace(dates(1),dates(end),200),0*ones(200,1),'-','LineWidth',1,'color',[0.74 0.74 0.74]);hold
plot(dates,epsr / sig_r,'b','linewidth',2);hold;
axis tight; set(gca,'Ytick',[-4:2:4]); ylim([-4,3]);
vline(enddate,'r-')
vline(startzlb,'r--')
set(gca,'FontSize',14)



% print(figure(12), '-dsvg','-r600','svg/Fig_Filtered_Shocks_4x2.svg');
