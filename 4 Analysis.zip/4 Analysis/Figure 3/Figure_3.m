%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Figure 3: Data
%
% This script reads data from Figures_Data.xlsx which contains the data
% used for estimation and filtering.
%
% LogCY = log(C/T) where C corresponds to our first definition of
% consumption in the main text: real personal consumption expenditures
% for the U.S. and real private consumption for Japan.
%
% LogCY2 = log(C/Y) where C corresponds to our second definition of
% consumption in the main text: consumption is all of output that is
% not government spending.
%
% See Online Appendix for data construction details and data sources.
%
%--------------------------------------------------------------------------
delete *.asv; delete *.m~; clear all; clc;
addpath ../ExternalTools/       % Path with external tools for plotting

set(0,'DefaultAxesColorOrder',[0.8 0 0; 0 0.4 0; 0 .2 1;0.8 0 1])
set(0,'defaulttextfontsize',12);

[ndata, text, ~] = xlsread('Figures_Data.xlsx','Fig3');

[nobs,nseries] = size(ndata);

for jj=1:nseries
    eval([text{1,jj} ' = ndata(:,jj);']);
end


% JP end of estimation sample
stop_jp = 1994.75;

% US end of estimation sample
stop_us = 2007.75;

% Define green color
cgreen = [44  160 44]/256;

%--------------------------------------------------------------------------
% PLOT US DATA
%--------------------------------------------------------------------------
figure(1); clf;
set(figure(1),'PaperType','usletter','PaperOrientation','Portrait','PaperPosition',[0.25 0.25 8 10.5])
subplot(4,1,1)
plot(YEAR_US,LOGY_US,'b-','LineWidth',3); hold on
axis tight; xlim([1984 2015]); ylim_use = ylim;
plot(stop_us*ones(50,1), linspace(ylim_use(1)*0.99,ylim_use(2)*1.01,50),'r-','LineWidth',2)
ylim([ylim_use(1)*0.999 ylim_use(2)*1.001]);
title('Output','FontSize',18,'fontweight','bold','Interpreter','latex')
legend('boxoff'); box on
set(gca,'FontSize',18)

subplot(4,1,2)
[AX,H1,H2] = plotyy(YEAR_US,LOGCY_US,YEAR_US,LOGCY2_US); hold on;
set(AX(2),'xlim',[1984 2015],'Ycolor',cgreen,'FontSize',18,'Ytick',[-30 -26 -22]);
set(AX(1),'xlim',[1984 2015],'Ycolor',[0 0 0],'FontSize',18,'Ytick',[-48 -44 -40],'YtickLabel',{'-48'; '-44'; '-40'});
set(H1,'Color',[0 0 1],'LineWidth',3);
set(H2,'Color',cgreen,'LineWidth',3,'LineStyle','--');
title('Consumption / Output','FontSize',18,'fontweight','bold','Interpreter','latex')
AX(3) = plot(stop_us*ones(50,1), linspace(-50,-40,50),'r-','LineWidth',2);


subplot(4,1,3)
plot(YEAR_US,INFL_US,'b-','LineWidth',3); hold on
plot(YEAR_US,zeros(length(YEAR_US),1),'m--','LineWidth',1);
axis tight; xlim([1984 2015]); ylim_use=ylim;
plot(stop_us*ones(50,1), linspace(-1,ylim_use(2)*1.15,50),'r-','LineWidth',2)
ylim([-1 ylim_use(2)*1.15]);
title('Inflation $(\%)$','FontSize',18,'fontweight','bold','Interpreter','latex')
legend('boxoff'); box on
set(gca,'FontSize',18)

subplot(4,1,4)
plot(YEAR_US,R_US,'b-','LineWidth',3); hold on
plot(YEAR_US,zeros(length(YEAR_US),1),'m--','LineWidth',1);
axis tight; xlim([1984 2015]); ylim_use=ylim;
plot(stop_us*ones(50,1), linspace(0,ylim_use(2)*1.05,50),'r-','LineWidth',2)
ylim([0 ylim_use(2)*1.05]);
title('Nominal Interest Rate $(\%)$','FontSize',18,'fontweight','bold','Interpreter','latex')
legend('boxoff'); box on
set(gca,'FontSize',18)


%%
%--------------------------------------------------------------------------
%  JAPAN DATA PLOT
%--------------------------------------------------------------------------
figure(2); clf;
set(figure(2),'PaperType','usletter','PaperOrientation','Portrait','PaperPosition',[0.25 0.25 8 10.5])
subplot(4,1,1)
plot(YEAR_JP,LOGY_JP,'b-','LineWidth',3); hold on;
axis tight; xlim([1981 2015]); ylim_use = ylim;
plot(stop_jp*ones(50,1), linspace(ylim_use(1)*0.998,ylim_use(2)*1.003,50),'r-','LineWidth',2)
ylim([ylim_use(1)*0.999 ylim_use(2)*1.001]);
title('Output','FontSize',18,'fontweight','bold','Interpreter','latex')
legend('boxoff'); box on
set(gca,'FontSize',18)

subplot(4,1,2)
plot(stop_jp*ones(50,1), linspace(-60,-50,50),'r-','LineWidth',2)
[AX,H1,H2] = plotyy(YEAR_JP,LOGCY_JP,YEAR_JP,LOGCY2_JP); hold on
set(AX(2),'xlim',[1981 2015],'Ycolor',cgreen,'FontSize',18);
set(AX(1),'xlim',[1981 2015],'Ycolor',[0 0 0],'FontSize',18);
set(H1,'Color',[0 0 1],'LineWidth',3);
set(H2,'Color',cgreen,'LineWidth',3,'LineStyle','--');
title('Consumption / Output','FontSize',18,'fontweight','bold','Interpreter','latex')
AX(3) = plot(stop_jp*ones(50,1), linspace(-60,-50,50),'r-','LineWidth',2);

subplot(4,1,3)
plot(YEAR_JP,zeros(length(YEAR_JP),1),'m--','LineWidth',1); hold on
plot(YEAR_JP,INFL_JP,'b-','LineWidth',3);
set(gca,'YTick',[-3 0 3 6],'YTickLabel',{'-3';'0';'3';'6'});
axis tight; xlim([1981 2015]); ylim_use=ylim;
plot(stop_jp*ones(50,1), linspace(ylim_use(1)*1.1,ylim_use(2)*1.03,50),'r-','LineWidth',2)
ylim([ylim_use(1)*1.1 ylim_use(2)*1.02])
title('Inflation $(\%)$','FontSize',18,'fontweight','bold','Interpreter','latex');
legend('boxoff'); box on
set(gca,'FontSize',18)

subplot(4,1,4)
plot(YEAR_JP,zeros(length(YEAR_JP),1),'m--','LineWidth',1); hold on
plot(YEAR_JP,R_JP,'b-','LineWidth',3); hold on
axis tight; xlim([1981 2015]); ylim_use=ylim;
plot(stop_jp*ones(50,1), linspace(0,ylim_use(2)*1.01,50),'r-','LineWidth',2)
title('Nominal Interest Rate $(\%)$','FontSize',18,'fontweight','bold','Interpreter','latex');
legend('boxoff'); box on
set(gca,'FontSize',18)

%--------------------------------------------------------------------------
%  PRINT FIGURES
%--------------------------------------------------------------------------

% For SVG
% print(figure(1),'-dsvg','-r600','svg/Fig_Data_US.svg');
% print(figure(2),'-dsvg','-r600','svg/Fig_Data_JP.svg');
