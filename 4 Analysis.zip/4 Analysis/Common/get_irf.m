% Function to produce IRFS based on simulations of linear or nonlinear
% model for the model in ACS(2014)
%
% First version: June 20, 2012
% Updated: November 25, 2015
% =========================================================================

function IRF = get_irf(theta_use,shocks_in,sunspot_in,init,size_shock,ind_period_one,which_shock)

global bad_sim_flag par
global ind_scale

% Map parameters
sig_r = par.sig_r;
sig_z = par.sig_z;
sig_g = par.sig_g;
sig_d = par.sig_d;

% Map shocks baseline path
eg_noshock = shocks_in.eg;
ez_noshock = shocks_in.ez;
er_noshock = shocks_in.er;
ed_noshock = shocks_in.ed;

% Initialize shocks for shocked path
eg_shocked = eg_noshock;
ez_shocked = ez_noshock;
er_shocked = er_noshock;
ed_shocked = ed_noshock;

Tdrop_irf = 0;

if which_shock == 'g'
    
    if ind_period_one == 0
        eg_noshock(1) =  0;
    end
    
    eg_shocked = eg_noshock;
    eg_shocked(1) = eg_noshock(1) + size_shock * sig_g;    
    
elseif which_shock == 'z'
    
    if ind_period_one == 0
        ez_noshock(1) =  0;
    end
    
    ez_shocked = ez_noshock;
    ez_shocked(1) = ez_noshock(1) + size_shock * sig_z;
        
elseif which_shock == 'r'
    
    if ind_period_one == 0
        er_noshock(1) =  0;
    end
    
    er_shocked = er_noshock;
    er_shocked(1) = er_noshock(1) + size_shock * sig_r;  
    

elseif which_shock == 'd'
    
    if ind_period_one==0
        ed_noshock(1) = 0;
    end
    
    ed_shocked = ed_noshock;
    ed_shocked(1) = ed_noshock(1) + size_shock*sig_d;
    
end

shocks_shocked.eg = eg_shocked;
shocks_shocked.ez = ez_shocked;
shocks_shocked.er = er_shocked;
shocks_shocked.ed = ed_shocked;

shocks_noshock.eg = eg_noshock;
shocks_noshock.ez = ez_noshock;
shocks_noshock.er = er_noshock;
shocks_noshock.ed = ed_noshock;

Tirf = length(ez_noshock);

sim_shocked = simulate_sunspot(theta_use,shocks_shocked,init,Tirf,Tdrop_irf,sunspot_in);
sim_noshock = simulate_sunspot(theta_use,shocks_noshock,init,Tirf,Tdrop_irf,sunspot_in);


if ind_scale==1
    irf_scale = abs(size_shock);
else
    irf_scale = 1;
end

if bad_sim_flag ==1
   IRF = [];
else

sim_shocked.logY = log(sim_shocked.BIGY);    
sim_noshock.logY = log(sim_noshock.BIGY);        
    
sim_shocked.logCY = log(sim_shocked.BIGC./sim_shocked.BIGY);    
sim_noshock.logCY = log(sim_noshock.BIGC./sim_noshock.BIGY);    
    
IRF.y    = (irf_scale^-1).*100.*(sim_shocked.y ./ sim_noshock.y - 1);
IRF.c    = (irf_scale^-1).*100.*(sim_shocked.c ./ sim_noshock.c - 1);
IRF.ee1  = (irf_scale^-1).*100.*(sim_shocked.ee1 ./ sim_noshock.ee1 - 1);
IRF.BIGY = (irf_scale^-1).*100.*(sim_shocked.BIGY ./ sim_noshock.BIGY - 1);
IRF.BIGC = (irf_scale^-1).*100.*(sim_shocked.BIGC ./ sim_noshock.BIGC - 1);
IRF.R    = (irf_scale^-1).*400.*(sim_shocked.R  - sim_noshock.R);
IRF.pi   = (irf_scale^-1).*400.*(sim_shocked.pi - sim_noshock.pi);

IRF.logY = (irf_scale^-1).*100.*(sim_shocked.logY - sim_noshock.logY);

IRF.logC = (irf_scale^-1).*100.*(sim_shocked.logCY + sim_shocked.logY - sim_noshock.logCY - sim_noshock.logY);

bad_sim_flag = 0;
end

