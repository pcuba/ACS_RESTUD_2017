% This function checks that path of shocks does not generate a boundary
% problem with the exogenous state variables.
%
% Draws vectors of [Tshocksx4] for simulations and a total Nrep repetitions
%
% Updated: November 25, 2015.
%==========================================================================

function V_out = fn_get_shocks(Nrep,Tshocks)
global seedname par

% Map parameters
gstar = par.gstar;
rho_z = par.rho_z;
rho_g = par.rho_g;
rho_d = par.rho_d;
e_max = par.e_max;
e_min = par.e_min;
g_max = par.g_max;
g_min = par.g_min;
z_max = par.z_max;
z_min = par.z_min;
d_max = par.d_max;
d_min = par.d_min;
sig_r = par.sig_r;
sig_z = par.sig_z;
sig_g = par.sig_g;
sig_d = par.sig_d;


% Set seed to reproduce same IRFs
[s_er, s_ez, s_eg, s_ed] = RandStream.create(seedname,'NumStreams',4);


count = 1;

while count<=Nrep
        
    init_use.z = 0;
    init_use.g = log(gstar);
    init_use.d = 0;
    
    er_use = sig_r*randn(s_er, Tshocks, 1);
    ez_use = sig_z*randn(s_ez, Tshocks, 1);
    eg_use = sig_g*randn(s_eg, Tshocks, 1);
    ed_use = sig_d*randn(s_ed, Tshocks, 1);
    
    er_keep = er_use;
    ez_keep = ez_use;
    eg_keep = eg_use;
    ed_keep = ed_use;
    
    zs = zeros(Tshocks,1);
    gs = zeros(Tshocks,1);
    ers= zeros(Tshocks,1);
    ds = zeros(Tshocks,1);
    
    for i=1:Tshocks
        
        if i == 1
            z_lag = init_use.z;
            g_lag = init_use.g;
            d_lag = init_use.d;
            
        else
            z_lag = zs(i-1);
            g_lag = gs(i-1);
            d_lag = ds(i-1);
            
        end
        
        zs(i) = rho_z*z_lag + ez_use(i);
        gs(i) = (1-rho_g)*log(gstar) + rho_g*g_lag + eg_use(i);
        ds(i) = rho_d*d_lag + ed_use(i);
        ers(i)= er_use(i);
    end
    
    % Now check that simulation of g is inside g_min g_max
    emax_temp = max(ers);
    emin_temp = min(ers);

    gmax_temp = max(gs);
    gmin_temp = min(gs);

    zmax_temp = max(zs);
    zmin_temp = min(zs);

    dmax_temp = max(ds);
    dmin_temp = min(ds);
    
    
    if gmax_temp<=g_max && gmin_temp > g_min ...
       && zmax_temp<=z_max && zmin_temp > z_min ...
       && emax_temp<=e_max && emin_temp > e_min ...
       && dmax_temp<=d_max && dmin_temp > d_min

        V_out.er(:,count) = er_keep; 
        V_out.ez(:,count) = ez_keep; 
        V_out.eg(:,count) = eg_keep; 
        V_out.ed(:,count) = ed_keep;
        
        count=count+1;    
    else
        fprintf('\n Discarding simulation at count = %i... \n',count);
    end
    
end