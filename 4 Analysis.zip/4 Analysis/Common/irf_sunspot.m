% This IRF functions uses the stacked vector of S=0 or S=1 objects to
% construct initial values across repetitions.

function [IRF, IRF_50, IRF_low, IRF_high] = irf_sunspot(theta_use,init_in,Tirf,Nrep,V_in,sun_t0)

global low_prctile high_prctile SUN_IRF_PATH
global ind_period_one ind_draw_sun size_shock
global bad_sim_flag

Tdrop_sun = 0;


if ind_draw_sun==1
    
    SUN = get_sunspot(Tirf,sun_t0,Tdrop_sun,Nrep);
    
else
    
    if isempty(SUN_IRF_PATH)
        SUN = repmat(sun_t0,Tirf,Nrep);
    else
        SUN = repmat(SUN_IRF_PATH,1,Nrep);
    end
    
end

%fprintf('\n Computing Impulse Responses. Wait... \n')
count = 1;


for rep_count=1:Nrep
    
    if count == 20;
        fprintf('%i \n', rep_count);
        count = 0;
    end
    
    % Get vector of initial period 0 objects;
    init_use.Rlag = init_in.Rlag(rep_count);
    init_use.ylag = init_in.ylag(rep_count);
    init_use.clag = init_in.clag(rep_count);
    init_use.zlag = init_in.zlag(rep_count);
    init_use.glag = init_in.glag(rep_count);
    init_use.dlag = init_in.dlag(rep_count);
    init_use.Alag = init_in.Alag(rep_count);
    
    % Get vector of baseline shocks for each repetition
    shocks_use.er = V_in.er(:,rep_count);
    shocks_use.ez = V_in.ez(:,rep_count);
    shocks_use.eg = V_in.eg(:,rep_count);
    shocks_use.ed = V_in.ed(:,rep_count);
    
    % Get the Sunspot %
    SUN_use = SUN(:,rep_count);
    
    IRF_R = get_irf(theta_use,shocks_use,SUN_use,init_use,size_shock,ind_period_one,'r');
    IRF_Z = get_irf(theta_use,shocks_use,SUN_use,init_use,size_shock,ind_period_one,'z');
    IRF_G = get_irf(theta_use,shocks_use,SUN_use,init_use,size_shock,ind_period_one,'g');
    IRF_D = get_irf(theta_use,shocks_use,SUN_use,init_use,size_shock,ind_period_one,'d');
    
    
    while bad_sim_flag == 1
        fprintf('\n Bad draw for IRF... drawing new shocks \n');
        
        bad_sim_flag = 0;
        V_TEMP = fn_get_shocks(1,Tirf,init_in);
        
        shocks_use.er = V_TEMP.ER(:,1);
        shocks_use.ez = V_TEMP.EZ(:,1);
        shocks_use.eg = V_TEMP.EG(:,1);
        shocks_use.ed = V_TEMP.ED(:,1);
        
        IRF_R = get_irf(theta_use,shocks_use,SUN_use,init_use,size_shock,ind_period_one,'r');
        IRF_Z = get_irf(theta_use,shocks_use,SUN_use,init_use,size_shock,ind_period_one,'z');
        IRF_G = get_irf(theta_use,shocks_use,SUN_use,init_use,size_shock,ind_period_one,'g');
        IRF_D = get_irf(theta_use,shocks_use,SUN_use,init_use,size_shock,ind_period_one,'d');
        
    end
    
    % Store Responses %
    
    MAT_IRF.y_er(:,rep_count)    = IRF_R.y;
    MAT_IRF.c_er(:,rep_count)    = IRF_R.c;
    MAT_IRF.ee1_er(:,rep_count)  = IRF_R.ee1;
    MAT_IRF.R_er(:,rep_count)    = IRF_R.R;
    MAT_IRF.pi_er(:,rep_count)   = IRF_R.pi;
    MAT_IRF.BIGY_er(:,rep_count) = IRF_R.BIGY;
    MAT_IRF.BIGC_er(:,rep_count) = IRF_R.BIGC;
    MAT_IRF.logC_er(:,rep_count) = IRF_R.logC;
    MAT_IRF.logY_er(:,rep_count) = IRF_R.logY;
    
    MAT_IRF.y_ez(:,rep_count)    = IRF_Z.y;
    MAT_IRF.c_ez(:,rep_count)    = IRF_Z.c;
    MAT_IRF.ee1_ez(:,rep_count)  = IRF_Z.ee1;
    MAT_IRF.R_ez(:,rep_count)    = IRF_Z.R;
    MAT_IRF.pi_ez(:,rep_count)   = IRF_Z.pi;
    MAT_IRF.BIGY_ez(:,rep_count) = IRF_Z.BIGY;
    MAT_IRF.BIGC_ez(:,rep_count) = IRF_Z.BIGC;
    MAT_IRF.logC_ez(:,rep_count) = IRF_Z.logC;
    MAT_IRF.logY_ez(:,rep_count) = IRF_Z.logY;
    
    MAT_IRF.y_eg(:,rep_count)    = IRF_G.y;
    MAT_IRF.c_eg(:,rep_count)    = IRF_G.c;
    MAT_IRF.ee1_eg(:,rep_count)  = IRF_G.ee1;
    MAT_IRF.R_eg(:,rep_count)    = IRF_G.R;
    MAT_IRF.pi_eg(:,rep_count)   = IRF_G.pi;
    MAT_IRF.BIGY_eg(:,rep_count) = IRF_G.BIGY;
    MAT_IRF.BIGC_eg(:,rep_count) = IRF_G.BIGC;
    MAT_IRF.logC_eg(:,rep_count)   = IRF_G.logC;
    MAT_IRF.logY_eg(:,rep_count) = IRF_G.logY;
    
    MAT_IRF.y_ed(:,rep_count)    = IRF_D.y;
    MAT_IRF.c_ed(:,rep_count)    = IRF_D.c;
    MAT_IRF.ee1_ed(:,rep_count)  = IRF_D.ee1;
    MAT_IRF.R_ed(:,rep_count)    = IRF_D.R;
    MAT_IRF.pi_ed(:,rep_count)   = IRF_D.pi;
    MAT_IRF.BIGY_ed(:,rep_count) = IRF_D.BIGY;
    MAT_IRF.BIGC_ed(:,rep_count) = IRF_D.BIGC;
    MAT_IRF.logC_ed(:,rep_count) = IRF_D.logC;
    MAT_IRF.logY_ed(:,rep_count) = IRF_D.logY;
       
    count = count + 1;
end

%--------------------------------------------------------------------------
%                       IRF MOMENTS
%--------------------------------------------------------------------------

% Get Mean Response
vnames = fieldnames(MAT_IRF);
for vcount=1:numel(vnames)
    IRF.(vnames{vcount}) = mean(MAT_IRF.(vnames{vcount}),2);
end

for vcount=1:numel(vnames)
    % Get Median Response %
    IRF_50.(vnames{vcount}) = prctile(MAT_IRF.(vnames{vcount}),50,2);
    % Get Lower Percentile Response %
    IRF_low.(vnames{vcount}) = prctile(MAT_IRF.(vnames{vcount}),low_prctile,2);
    % Get High Percentile Response %
    IRF_high.(vnames{vcount}) = prctile(MAT_IRF.(vnames{vcount}),high_prctile,2);
end

