% Function to generate a Time Separated Grid
% Take any NxM matrix as input and sample observations at equal lenghts to 
% produce a grid of M_inxM observations
% 
% Updated: July 25th, 2012
%==========================================================================

function [ES_out grid_out cindex_out] = tsga_grid(simulation_in,M_in)

   fprintf('\n Creating the Time Separeted Grid. Wait... \n')
   T             = length(simulation_in);         % Lenght of simulated series
   t             = round((1:1:M_in)*(T/M_in));    % Index of numbers to select the grid
   grid_out      = simulation_in(t,:);          
   ES_out        = simulation_in;
   cindex_out    = ones(T,1);                     % Color index for plots. For TSGA =1 for all points. 
   
end