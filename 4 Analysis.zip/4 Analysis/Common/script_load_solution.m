%==========================================================================
%
% This script loads the parameters and coefficients for the Sunspot Model
%
% Updated: February 14, 2015
%==========================================================================

global piannual par
global rho0 rho1
global seedname
global ind_pibar_equals_pistar fname id
global R_min R_max y_min y_max
global e_min e_max  d_min d_max z_min z_max g_min g_max

%==========================================================================
% Load stored solution 
%==========================================================================

fprintf('\n **** Loading Saved Results .... \n')

fname    = strcat('SUNSPOT_',model_number);

fprintf('\n **** Loading Model = %s \n', fname);

load(strcat('SOLUTION_',fname))

theta_names = fieldnames(THETA);
theta_use = THETA.(theta_names{end});

%==========================================================================
% Assign parameters
%==========================================================================

% SUNSPOT PARAMETERS %
rho0 = par.rho0;
rho1 = par.rho1;

% MODEL PARAMETERS %
beta  = par.beta;
phi   = par.phi;
nu    = par.nu;
tau   = par.tau;
eta   = par.eta;
chi_h = par.chi_h;
psi1  = par.psi1;
psi2  = par.psi2;
pistar= par.pistar;
gamma = par.gamma;
r     = par.r;
rho_R = par.rho_R;
b     = par.b;
rho_d = par.rho_d;
rho_z = par.rho_z;
rho_g = par.rho_g;
gstar = par.gstar;
sig_d = par.sig_d;
sig_z = par.sig_z;
sig_g = par.sig_g;
sig_r = par.sig_r;
pi_ss = par.pi_ss;
pibar = par.pibar;

%==========================================================================
% Map steady state values
%==========================================================================

% Targeted Inflation Regime %
R_ss   = par.R_ss;
c_ss   = par.c_ss;
y_ss   = par.y_ss;
ee1_ss = par.ee1_ss;

% Deflation Regime %
R_tilde   = 1;
pi_tilde  = par.pi_tilde;
c_tilde   = par.c_tilde;
y_tilde   = par.y_tilde;
ee1_tilde = par.ee1_tilde;

% MAP BOUNDARIES %
R_max = par.R_max;
R_min = par.R_min;
y_max = par.y_max;
y_min = par.y_min;
e_min = par.e_min;
e_max = par.e_max;
z_max = par.z_max;
z_min = par.z_min;
g_max = par.g_max;
g_min = par.g_min;
d_max = par.d_max;
d_min = par.d_min;

% ADDITIONAL INFORMATION %
piannual = 4*(par.pi_ss-1)*100;
id       = strcat(num2str(piannual));
ind_pibar_equals_pistar = par.ind_pibar_equals_pistar;
order    = par.order;
filtered_grid_file = par.filtered_grid;

%==========================================================================
% **** INITIAL CONDITIONS FOR SIMULATION ****%
%==========================================================================

% Initial conditions for simulation
if sunspot_initial_sim==1
    init_sim.Rlag = R_ss;
    init_sim.ylag = y_ss;
    init_sim.clag = c_ss;
else
    init_sim.Rlag = R_tilde;
    init_sim.ylag = y_tilde;
    init_sim.clag = c_tilde;
end
init_sim.er= 0;
init_sim.dlag = 0;
init_sim.zlag = 0;
init_sim.glag = log(gstar);
init_sim.Alag = 1;

%==========================================================================
% LOAD EXOGENOUS PROCESS FOR IRFs
%==========================================================================

% String to generate RandomNumber Streams
seedname  = 'mrg32k3a';           

if ind_shocks_sim==1

    fprintf('\n **** Loading stored shocks **** \n');
    
    % Loads stored shocks drawn from N(0,1) distribution
    load SHOCKSMAT.mat 
    
    shocks_sim.er = shocks.er*par.sig_r;
    shocks_sim.ez = shocks.ez*par.sig_z;
    shocks_sim.eg = shocks.eg*par.sig_g;
    shocks_sim.ed = shocks.ed*par.sig_d;

elseif ind_shocks_sim==0
    fprintf('\n **** Drawing fresh shocks for simulations **** \n');
    
    rng(72256,'twister');

    shocksmat = randn(Tsim_sim+Tdrop_sim,4);

    shocks_sim.er = sig_r*shocksmat(:,1);
    shocks_sim.ez = sig_z*shocksmat(:,2);
    shocks_sim.eg = sig_g*shocksmat(:,3);
    shocks_sim.ed = sig_d*shocksmat(:,4);

end
