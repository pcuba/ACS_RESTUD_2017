%--------------------------------------------------------------------------
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Figure 2: Sample Decision Rules
%
% This script reads DR_US3vGrowth which is obtained simulating the U.S. 3vGrowth
% specification over a fine grid of the g-shock process and fixing all other
% states at st = 1, Rt−1 = 1, while other states are fixed at their ergodic means.
%
% For example code on how to simulate the sunspot model see /Figure 5/
%--------------------------------------------------------------------------

clear all; clc; close all;

addpath ../ExternalTools/       % Path with external tools for plotting


% Load data
load DR_US3vGrowth.mat

% Adjust x-axis
grid_g  = (DECISION_g.g - log(par.gstar))*100;

figure(2);clf;
set(figure(2),'PaperType','usletter','PaperOrientation','landscape','PaperPosition',[0.25 0.25 10.5 8]);
subplot(2,2,1);
plot(grid_g,400*log(DECISION_g.R),'b-','linewidth',5);xlabel('$\hat{g}$','fontsize',14,'Interpreter','Latex');
title('Interest Rate','fontsize',16','fontweight','bold','Interpreter','Latex');
set(gca,'FontSize',14);grid on;xlim([eg_grid_min,eg_grid_max]);
set(gca,'Ytick',[0 1 2 3 4]);
xlim([-6,0]);

subplot(2,2,2);
plot(grid_g,400*log(DECISION_g.pi),'b-','linewidth',5);xlabel('$\hat{g}$','fontsize',14,'Interpreter','Latex');
title('Inflation','fontsize',16','fontweight','bold','Interpreter','Latex');
set(gca,'FontSize',14);grid on;xlim([eg_grid_min,eg_grid_max]);
set(gca,'Ytick',[-2 0 2 4 6]);
xlim([-6,0]);
subplot(2,2,3);
plot(grid_g,100*log(DECISION_g.y/par.y_ss),'b-','linewidth',5);xlabel('$\hat{g}$','fontsize',14,'Interpreter','Latex');
title('Output','fontsize',16','fontweight','bold','Interpreter','Latex');
set(gca,'FontSize',14);grid on;xlim([eg_grid_min,eg_grid_max]);
xlim([-6,0]);
subplot(2,2,4);
plot(grid_g,100*log(DECISION_g.c/par.c_ss),'b-','linewidth',5);xlabel('$\hat{g}$','fontsize',14,'Interpreter','Latex');
title('Consumption','fontsize',16','fontweight','bold','Interpreter','Latex');
set(gca,'FontSize',14);grid on;xlim([eg_grid_min,eg_grid_max]);
xlim([-6,0]);


% print(figure(2),'-dsvg','-r600','svg/COMPARE_DR_STAR_4_FINAL_FS.svg');
