% File with estimated parameters for different values of psi2

switch psi2
        
    case 0.1250
    
        tau = 2.0169;
        kappa = 0.0886;
        rho_R = 0.7989;
        rho_g = 0.9527;
        rho_z = 0.2090;
        rho_d = 0.9502;
        sig_r = 0.0015;
        sig_g = 0.0053;
        sig_z = 0.0050;
        sig_d = 0.0178;
        
    case 0.1
        tau   = 1.9932;
        kappa = 0.1013;
        rho_R = 0.7989;
        rho_g = 0.9551;
        rho_z = 0.1875;
        rho_d = 0.9536;
        sig_r = 0.0016;
        sig_g = 0.0053;
        sig_z = 0.0050;
        sig_d = 0.0188;
        
        
end
