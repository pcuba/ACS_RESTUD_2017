% Function to generate a clustered grid using Ward linkages
% grid_in is the simulated grid using a low accuracy method
% CN is the number of cluster to be generated
%
%   Transformation:  [0] = No Preprocessing 
%                    [1] = PC transformation
%
% This is the order of the simulated series
%
% Rlag   = simulation_in(:,1);                       % Interest Rate
% ylag   = simulation_in(:,2);                       % Output
% er     = simulation_in(:,3);                       % Monetary Shock
% z      = simulation_in(:,4);                       % Productivity
% g      = simulation_in(:,5);                       % Gov. expenditure
%
%--------------------------------------------------------------------------

function [ES_out grid_out cindex_out] = cga_grid(simulation_in,CN,transformation)

[obs vars]=size(simulation_in);                     % Get number of observations and variables

grid_CGA=zeros(CN,vars);                            % Preallocate matrix where Grid Points will be stored

if transformation==1;  % Preprocess data
    
    mu  = mean(simulation_in);     % compute averages
    sig = std(simulation_in);      % compute standard deviations
    MU  = kron(ones(obs,1),mu);    % Stack the vector of means (for every observation)
    SIG = kron(ones(obs,1),sig);   % Stack the vector of standard deviations
    % (for every observation)
    
    X   = (simulation_in - MU)./SIG;    % This is the standarized data
    
    [U,S,V] = svd(X);              % Perform the Singular Value Decomposition of standarized data
    
    Z  = X*V;                      % Principal components of standarized data
    
    sig_z = std(Z);                % Standard deviations of PC
    
    SIG_Z = kron(ones(obs,1),sig_z);
    
    ZZ = Z./SIG_Z;                 % Compute cluster over ZZ
    
    c = clusterdata(ZZ,'linkage','ward','maxclust',CN);  % Cluster possitions
    
    
    m_X = zeros(1,vars);            % This is the vector for storing the cluster mean of each variable
    
    for i = 1:CN
        I= c==i;                        % Get indeces of i-th cluster group
        for j=1:vars           
            m_X(1,j) = mean(Z(I,j));    % Compute i-th cluster mean. Each column j
        end                             % corresponds to the mean of a variable
        
        grid_CGA(i,:) = m_X;            % This are the cluster centers
    end    

    % Revert Back the PC transformation %
    
    grid_CGA = grid_CGA/V;              % This incorporates the PC
    
    MU_GRID  = kron(ones(CN,1),mu);    % Stack the vector of means (for every grid point)
    SIG_GRID = kron(ones(CN,1),sig);   % Stack the vector of standard deviations

    
    grid_CGA   = grid_CGA.*SIG_GRID + MU_GRID;
        
    ES_out  = simulation_in; 
    grid_out = grid_CGA;                  % Cluster Grid points (Over ZZ)
    
    
elseif transformation==0
    
    % No transformation clusters the data directly over the untransformed
    % data
    
    X = simulation_in;                                  % This is the ergodic set
    c = clusterdata(X,'linkage','ward','maxclust',CN);  % Cluster possitions
    
    % Create means of clusters %   
    
    m_X = zeros(1,vars);
    
    for i = 1:CN
        I= c==i;      % Get indeces of i-th cluster group
        for j=1:vars           
            m_X(1,j) = mean(X(I,j));     % Compute i-th cluster mean. Each column j 
        end                              % correspond to the mean for a variable
       
        grid_CGA(i,:) = m_X;             % This are the cluster centers
    end    

ES_out     = simulation_in;              % Ergodic Set
grid_out   = grid_CGA;                   % Cluster Grid points   
    
end


cindex_out = c;                          % Cluster index for color plotting





% Example of creating the cluster means for 5 Variables 
% 
%     for i = 1:CN
%         I = c==i;                                          % Get index of i-th cluster group
%         m_R = mean(X(I,1));                                 % Compute i-th cluster mean
%         m_y = mean(X(I,2));
%         m_e = mean(X(I,3));
%         m_z = mean(X(I,4));
%         m_g = mean(X(I,5));
%         
%         grid_CGA(i,:) = [m_R m_y m_e m_z m_g];             % This are the cluster centers
%     end