function moments_out = get_moments(SIM,FLAG_STATE)

    % CONDITION ON SUNSPOT OR USE ALL SAMPLE
    if FLAG_STATE == 0
        SIM_USE.pi = 400*log(SIM.pi(SIM.SUN==0));
        SIM_USE.R  = 400*log(SIM.R(SIM.SUN==0));
        SIM_USE.y  = (SIM.y(SIM.SUN==0));
        SIM_USE.c  = (SIM.c(SIM.SUN==0));
        SIM_USE.h  = (SIM.h(SIM.SUN==0));
        SIM_USE.w  = (SIM.w(SIM.SUN==0));
        SIM_USE.dely  = (SIM.dely(SIM.SUN==0));     % This is already annualized
        SIM_USE.delc  = (SIM.delc(SIM.SUN==0));     % This is already annualized

    elseif FLAG_STATE == 1
        SIM_USE.pi = 400*log(SIM.pi(SIM.SUN==1));
        SIM_USE.R  = 400*log(SIM.R(SIM.SUN==1));
        SIM_USE.y  = (SIM.y(SIM.SUN==1));
        SIM_USE.c  = (SIM.c(SIM.SUN==1));
        SIM_USE.h  = (SIM.h(SIM.SUN==1));
        SIM_USE.w  = (SIM.w(SIM.SUN==1));
        SIM_USE.dely  = (SIM.dely(SIM.SUN==1));
        SIM_USE.delc  = (SIM.dely(SIM.SUN==1));

    else 
        % UNCONDITIONAL
        SIM_USE.pi = 400*log(SIM.pi);
        SIM_USE.R  = 400*log(SIM.R);
        SIM_USE.y  = (SIM.y);
        SIM_USE.c  = (SIM.c);
        SIM_USE.h  = (SIM.h);
        SIM_USE.w  = (SIM.w);
        SIM_USE.dely  = (SIM.dely);
        SIM_USE.dely  = (SIM.dely);
    end   
    
    
    vars = fieldnames(SIM_USE);

    
    % COMPUTE MEAN, SD, Corr(x,output)
    for i=1:length(vars)
        moments_out.MEAN.(vars{i}) = eval(strcat('mean(SIM_USE.(vars{i}))'));
        moments_out.SD.(vars{i})   = eval(strcat('std(SIM_USE.(vars{i}))'));
        moments_out.CORR.(vars{i}) = eval(strcat('corr(SIM_USE.(vars{i}),SIM_USE.y)'));
    end

    % Pairwise correlations
    moments_out.CORR.R_pi = corr2(SIM_USE.R,SIM_USE.pi);
    
    moments_out.CORR.R_y = corr2(SIM_USE.R,SIM_USE.y);
    
    moments_out.CORR.y_pi = corr2(SIM_USE.y,SIM_USE.pi);

    
    % FRACTION OF PERIODS AT ZLB
    moments_out.zlb  = sum(SIM_USE.R==0)/length(SIM_USE.R)*100;

    % FRACION OF PERIODS WITH DEFLATION
    moments_out.defl = sum(SIM_USE.pi<0)/length(SIM_USE.pi)*100;
    
    moments_out.dely = mean(SIM_USE.dely);

    moments_out.sim_dely = SIM_USE.dely;
    
end 