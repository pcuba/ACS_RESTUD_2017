function SUNSPOT = get_sunspot(sim_length,sunspot_initial,Tdrop, Nrep)

global rho1 rho0

stream = RandStream.create('mrg32k3a','NumStreams',1);

sim_length = sim_length + Tdrop;

RAND_UN = rand(stream,sim_length,Nrep);

%fprintf('Rand number for sunspot: %4.4f \n',RAND_UN);

SUNSPOT = NaN(sim_length,Nrep);

for nCount = 1:Nrep
    
    for tCount = 1:sim_length
        
        if tCount == 1
            SUN_LAG = sunspot_initial;
        else
            SUN_LAG = SUNSPOT(tCount-1,nCount);
        end
        
        rho_use = SUN_LAG* rho1 + (1 - SUN_LAG) * rho0;
        
        if RAND_UN(tCount,nCount) < rho_use
            SUNSPOT(tCount,nCount) = SUN_LAG;
        else
            SUNSPOT(tCount,nCount) = abs(SUN_LAG - 1);
        end
    end
    
end
