% Function to compute Euler Errors of the SUNSPOT Model
% Arguments:
%           theta_in  = vector of coefficients of PEA solution
%           grid_in = Grid over which solution is evaluated
%           Q2        = Quadrature nodes used for integration
%           approximation
%
% Updated: December 1st, 2013
%==========================================================================

function [eemean1_out, eemean2_out, OUT] = euler_error(theta_in,grid_in, Q_in)

global ncoefs O par
global rho1 rho0

%===========================
% MAP PARAMETERS
%===========================
beta  = par.beta;  phi   = par.phi;   nu    = par.nu;    tau = par.tau; chi_h = par.chi_h;
eta   = par.eta;   psi1  = par.psi1;  psi2  = par.psi2;  gstar = par.gstar;
pi_ss = par.pi_ss; pibar = par.pibar; gamma = par.gamma; r = par.r;
rho_R = par.rho_R; rho_z = par.rho_z; rho_g = par.rho_g; rho_d = par.rho_d;
alp   = par.alp;

%===========================
% PARAMETER TRANSFORMATIONS
%===========================
b   = 1/(2*nu);

%===========================
% MAP GRID NODES
%===========================
Rgrid_in = grid_in(:,1);
tgrid_in = grid_in(:,2);
dgrid_in = grid_in(:,3);
egrid_in = grid_in(:,4);
zgrid_in = grid_in(:,5);
ggrid_in = grid_in(:,6);
sgrid_in = grid_in(:,7);

OUT.Rlag = Rgrid_in;
OUT.trendlag = tgrid_in;
OUT.d = dgrid_in;
OUT.er = egrid_in;
OUT.z = zgrid_in;
OUT.g = ggrid_in;
OUT.s = sgrid_in;

M = length(grid_in);        % Number of Gridpoints
Q = Q_in^4;                 % Number of Integration Nodes (Based on Product Rule)

%===========================
%       HOUSEKEEPING 
%===========================

% Integral 1 %
integrand1_1 = zeros(Q,1);  
integrand1_0 = zeros(Q,1);  

% Integral 2 %
integrand2_1 = zeros(Q,1);  
integrand2_0 = zeros(Q,1);  


res1_0_1 = zeros(M,1);    % 0 state / NON ZLB
res2_0_1 = zeros(M,1);

res1_0_2 = zeros(M,1);    % 0 state / ZLB
res2_0_2 = zeros(M,1);

res1_1_1 = zeros(M,1);    % 1 state / NON ZLB
res2_1_1 = zeros(M,1);

res1_1_2 = zeros(M,1);    % 1 state / ZLB
res2_1_2 = zeros(M,1);


%=============================
% MAP COEFFICIENTS
%=============================

theta_ee1_1_1 = theta_in(1:ncoefs,1);             %STAR EQUILIBRIUM THETA / NON ZLB
theta_pi_1_1  = theta_in(ncoefs+1:2*ncoefs,1);
theta_ee1_1_2 = theta_in(2*ncoefs+1:3*ncoefs,1);  %STAR EQUILIBRIUM THETA / ZLB
theta_pi_1_2  = theta_in(3*ncoefs+1:4*ncoefs,1);

theta_ee1_0_1 = theta_in(4*ncoefs+1:5*ncoefs,1);  %TILDE EQUILIBRIUM THETA / NON ZLB
theta_pi_0_1  = theta_in(5*ncoefs+1:6*ncoefs,1);
theta_ee1_0_2 = theta_in(6*ncoefs+1:7*ncoefs,1);  %TILDE EQUILIBRIUM THETA / NON ZLB
theta_pi_0_2  = theta_in(7*ncoefs+1:8*ncoefs,1);

%===========================
% BASIS FUNCTION
%===========================

PSI = basis_temp(Rgrid_in, tgrid_in, dgrid_in, egrid_in, zgrid_in, ggrid_in);

EE1_1_1 = PSI'*theta_ee1_1_1;
PI_1_1  = PSI'*theta_pi_1_1;

EE1_1_2 = PSI'*theta_ee1_1_2;
PI_1_2  = PSI'*theta_pi_1_2;

EE1_0_1 = PSI'*theta_ee1_0_1;
PI_0_1  = PSI'*theta_pi_0_1;

EE1_0_2 = PSI'*theta_ee1_0_2;
PI_0_2  = PSI'*theta_pi_0_2;


%===========================
% INTEGRATION NODES
%===========================

% QUADRATURE INTEGRATION %
[ER_prime, EZ_prime, EG_prime,ED_prime, WEIGHT] = get_GH_nodes(Q_in);

%===========================
% MAIN LOOP
%===========================

grid_size = size(grid_in,1);

OUT.ERROR1= ones(grid_size,1) * nan;        % Vectors that carry the EE
OUT.ERROR2= ones(grid_size,1) * nan;

for i = 1:grid_size
    
    R_lag  = Rgrid_in(i,1);             % R(-1) 
    trend_lag  = tgrid_in(i,1);         % trend(-1)
    d      = dgrid_in(i,1);             % Discount Factor Shock
    er     = egrid_in(i,1);             % Monetary Shock
    g      = ggrid_in(i,1);             % Fiscal Shock
    z      = zgrid_in(i,1);             % Productivity shock
    
    s      = sgrid_in(i,1);             % Sunspot variable

   if s == 1
        
        ee1 = EE1_1_1(i,1);
        ppi = PI_1_1(i,1);
       
        temp  = ((r*pi_ss*((ppi/pi_ss)^psi1)*((exp(z)/trend_lag)^(alp*psi2)))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        y     = ( (beta*ee1*temp) / (((1/exp(g)) - 0.5*phi*(ppi - pibar)^2)^(-tau)) )^(-1/(tau + alp*psi2*(1-rho_R)));
        trend = (trend_lag^alp)*(y^(1-alp))*exp(-alp*z);
        R     = ((r*pi_ss*((ppi/pi_ss)^psi1)*(((y/trend))^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        
        % Check ZLB %
        
        if R > 1
            c = (beta*R*ee1)^(-1/tau);
        elseif R<=1 && O.ind_impose==1;
            R = 1;
            ee1 = EE1_1_2(i,1);
            ppi = PI_1_2(i,1);
            c = (beta*R*ee1)^(-1/tau);
            y = c / ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);            
        trend = (trend_lag^alp)*(y^(1-alp))*exp(-alp*z);
            
        end
        
    elseif s == 0   
        
        % First non-ZLB decision rules
        
        ee1 = EE1_0_1(i,1);
        ppi = PI_0_1(i,1);        
        
        temp  = ((r*pi_ss*((ppi/pi_ss)^psi1)*((exp(z)/trend_lag)^(alp*psi2)))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        y     = ( (beta*ee1*temp) / (((1/exp(g)) - 0.5*phi*(ppi - pibar)^2)^(-tau)) )^(-1/(tau + alp*psi2*(1-rho_R)));
        trend = (trend_lag^alp)*(y^(1-alp))*exp(-alp*z);
        R     = ((r*pi_ss*((ppi/pi_ss)^psi1)*(((y/trend))^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        
        % Check ZLB %
        
        if R > 1
            c  = (beta*R*ee1)^(-1/tau);
        else
            R = 1;
            ee1 = EE1_0_2(i,1);
            ppi = PI_0_2(i,1);
            c  = (beta*R*ee1)^(-1/tau);
            y  = c / ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
         trend = (trend_lag^alp)*(y^(1-alp))*exp(-alp*z);
            
        end
        
    else
        error('What are you doing here?')
        
    end
    
    ff = c^(-tau) * y *((1/nu) * (1 - c^tau) + phi * (ppi - pibar) * ((1 - b)*ppi + pibar * b) - 1);   
    
    OUT.R(i) = R;
    
    %------------
    % Integrals
    %------------
    
    % Precompute objects that don't change inside integral: Z, R, PSI,
    % EE1_prime, PI_prime
    
    for q=1:Q
        
        er_prime = ER_prime(q,1);
        d_prime  = rho_d * d + ED_prime(q,1);
        z_prime  = rho_z * z + EZ_prime(q,1);
        g_prime  = (1-rho_g) * log(gstar) + rho_g * g + EG_prime(q,1);
        
        % Build PSI_prime
        
        PSI_prime = basis_temp(R,trend,d_prime, er_prime,z_prime,g_prime); % basis for prime objects

        % Approximate t+1 objects (start with unconstrained)
        
        % Switch to s = 1 in t+1 
        
        ee1_prime_1 = PSI_prime'*theta_ee1_1_1;
        pi_prime_1  = PSI_prime'*theta_pi_1_1;
        
        % Switch to s = 0 in t+1 
        
        ee1_prime_0 = PSI_prime'*theta_ee1_0_1;
        pi_prime_0  = PSI_prime'*theta_pi_0_1;
        
        temp_prime_1 = ((r*pi_ss*((pi_prime_1/pi_ss)^psi1)*((exp(z_prime)/y)^(alp*psi2)))^(1-rho_R))*((R)^rho_R)*exp(er_prime);
        temp_prime_0 = ((r*pi_ss*((pi_prime_0/pi_ss)^psi1)*((exp(z_prime)/y)^(alp*psi2)))^(1-rho_R))*((R)^rho_R)*exp(er_prime);
        
        y_prime_1 = ( (beta*ee1_prime_1*temp_prime_1) / (((1/exp(g_prime)) - 0.5*phi*(pi_prime_1 - pibar)^2)^(-tau)) )^(-1/(tau + alp*psi2*(1-rho_R)));
        y_prime_0 = ( (beta*ee1_prime_0*temp_prime_0) / (((1/exp(g_prime)) - 0.5*phi*(pi_prime_0 - pibar)^2)^(-tau)) )^(-1/(tau + alp*psi2*(1-rho_R)));
         
        trend_prime_1 = (trend^alp)*(y_prime_1^(1-alp))*exp(-alp*z_prime);
        trend_prime_0 = (trend^alp)*(y_prime_0^(1-alp))*exp(-alp*z_prime);
        
        R_prime_1  = ((r*pi_ss*((pi_prime_1/pi_ss)^psi1)*(((y_prime_1/trend_prime_1))^psi2))^(1-rho_R))*((R)^rho_R)*exp(er_prime);
        R_prime_0  = ((r*pi_ss*((pi_prime_0/pi_ss)^psi1)*(((y_prime_0/trend_prime_0))^psi2))^(1-rho_R))*((R)^rho_R)*exp(er_prime);
       
        % Check ZLB
        
        if R_prime_1 > 1            
            c_prime_1 = (beta*R_prime_1*ee1_prime_1)^(-1/tau);            
        else            
            R_prime_1 = 1;
            ee1_prime_1 = PSI_prime'*theta_ee1_1_2;
            pi_prime_1  = PSI_prime'*theta_pi_1_2;
            c_prime_1 = (beta*R_prime_1*ee1_prime_1)^(-1/tau);
            y_prime_1 = c_prime_1 / ((1/exp(g_prime)) - 0.5*phi*(pi_prime_1 - pibar)^2);            
        end
        
        if R_prime_0 > 1
            c_prime_0 = (beta*R_prime_0*ee1_prime_0)^(-1/tau); 
        else
            R_prime_0 = 1;
            ee1_prime_0 = PSI_prime'*theta_ee1_0_2;
            pi_prime_0  = PSI_prime'*theta_pi_0_2;
            c_prime_0 = (beta*R_prime_0*ee1_prime_0)^(-1/tau);
            y_prime_0 = c_prime_0 / ((1/exp(g_prime)) - 0.5*phi*(pi_prime_0 - pibar)^2);
        end
        
        integrand1_1(q,:) =  ((c_prime_1^-tau)/(gamma*pi_prime_1*exp(z_prime)))*exp(d_prime - d);
        integrand1_0(q,:) =  ((c_prime_0^-tau)/(gamma*pi_prime_0*exp(z_prime)))*exp(d_prime - d);
                
        integrand2_1(q,:) =  (((c_prime_1)^-tau)*(y_prime_1)*(pi_prime_1 - pibar)*pi_prime_1)*exp(d_prime - d);
        integrand2_0(q,:) =  (((c_prime_0)^-tau)*(y_prime_0)*(pi_prime_0 - pibar)*pi_prime_0)*exp(d_prime - d);           
    end

    sol_int1_1 = integrand1_1' * WEIGHT;
    sol_int1_0 = integrand1_0' * WEIGHT;
   
    sol_int2_1 = integrand2_1' * WEIGHT;
    sol_int2_0 = integrand2_0' * WEIGHT;              
     
    % Compute Euler Error %
    
    deltapi = (ppi - pibar)*((1-b)*ppi + b*pibar);
    
    if s == 1
        
        INT_EE1 = rho1*sol_int1_1 + (1-rho1)*sol_int1_0;
        INT_EE2 = rho1*sol_int2_1 + (1-rho1)*sol_int2_0;

    elseif s == 0
        
        INT_EE1 = (1-rho0)*sol_int1_1 + rho0*sol_int1_0;
        INT_EE2 = (1-rho0)*sol_int2_1 + rho0*sol_int2_0;
        
    end
    
    OUT.ERROR1(i,1) = 1 - ((beta * R * INT_EE1)^(-1/tau))/c;

    DENOM2  = y*((1/nu)*(1-chi_h*(c^tau)*(y^(1/eta))) + phi*deltapi - 1);

    OUT.ERROR2(i,1) = 1 - ((phi*beta*INT_EE2 / DENOM2)^(-1/tau))/c;

    
    % Compute residuals for each gridpoint i=1,...,M
    
    if s == 1 && R > 1
        
        res1_1_1(i,:) = ee1 - rho1*sol_int1_1 - (1-rho1)*sol_int1_0;
        res2_1_1(i,:) = ff - rho1*phi*beta*sol_int2_1 - (1-rho1)*phi*beta*sol_int2_0;   
        
    elseif s == 1 && R == 1
        
        res1_1_2(i,:) = ee1 - rho1*sol_int1_1 - (1-rho1)*sol_int1_0;
        res2_1_2(i,:) = ff - rho1*phi*beta*sol_int2_1 - (1-rho1)*phi*beta*sol_int2_0;
        
    elseif s == 0 && R > 1        
 
        res1_0_1(i,:) = ee1 - (1-rho0)*sol_int1_1 - rho0*sol_int1_0;
        res2_0_1(i,:) = ff - (1-rho0)*phi*beta*sol_int2_1 - rho0*phi*beta*sol_int2_0;
        
    elseif s == 0 && R == 1        
       
        res1_0_2(i,:) = ee1 - (1-rho0)*sol_int1_1 - rho0*sol_int1_0;
        res2_0_2(i,:) = ff - (1-rho0)*phi*beta*sol_int2_1 - rho0*phi*beta*sol_int2_0;
        
    else
        
        error('What are you doing here?')
    
    end

    
end

eemean1_out = mean(log10(abs(OUT.ERROR1)));
eemean2_out = mean(log10(abs(OUT.ERROR2)));

fprintf('\n EE1 = %2.4f, EE2 = %2.4f \n',eemean1_out, eemean2_out);

G = [res1_1_1;res1_1_2;res2_1_1;res2_1_2;res1_0_1;res1_0_2;res2_0_1;res2_0_2];

OUT.SSR = norm(G)^2;

OUT.G = G;