function plot_irf(Tirf,sunspot_initial_irf,label_in,shock_use,irf_bands,varargin)

% set the default figure position to be in the upper right
%set(0,'defaultFigurePosition',[1353 661 560 420])
close all;

global model_number tag_name pick_date country
global ind_period_one ind_print size_shock


% NUMBER OF SERIES TO PLOT
nseries = length(varargin)/2;

% FIELD NAMES OF INPUT SERIES
fldn    = fieldnames(varargin{1});

% ALLOCATE OBJECTS %

% Create an empty IRF structure for missing series %
for i=1:length(fldn)
    irfnull.(fldn{i}) = NaN(Tirf,1);
end

% Check for confidence bands
if isempty(irf_bands)==0
    lband = irf_bands(:,1);
    uband = irf_bands(:,2);
    
    % SET COLOR LINES AND WIDTH
    if sunspot_initial_irf == 1
        color_shade = [0.6758 0.8438 0.8984];
        set(0,'DefaultAxesColorOrder',[0 0 0.8008; 0.8008 0 0; 0 0.4 0; 0 .2 1; 0.8 0 1]);
    elseif sunspot_initial_irf == 0
        color_shade = [1.0000    0.6250    0.4766];
        set(0,'DefaultAxesColorOrder',[0.8008 0 0; 0 0 0.8008; 0 0.4 0; 0 .2 1; 0.8 0 1]);
    end
    
    set(0,'defaultlinelinewidth',2);
    
    
else
    lband = irfnull;
    uband = irfnull;
    
    color_shade = 'k';
    % COLOR ORDER: 1st series is red, 2nd series is medium blue
    set(0,'defaultlinelinewidth',3);
    
    set(0,'DefaultAxesColorOrder',[0.8008 0 0 ;0 0 0.8008;0 0.4 0; 0 .2 1;0.8 0 1]);
    
end


% ALLOCATE SERIES
switch nseries
    case 1 % Plot one series
        irf1 = varargin{1};  irf2 = irfnull; irf3 = irfnull; irf4=irfnull; irf5=irfnull;
    case 2  % Plot two series
        irf1 = varargin{1};  irf2 = varargin{2}; irf3 = irfnull; irf4=irfnull; irf5=irfnull;
    case 3  % Plot two series
        irf1 = varargin{1};  irf2 = varargin{2}; irf3 = varargin{3}; irf4=irfnull; irf5=irfnull;
    case 4  % Plot two series
        irf1 = varargin{1};  irf2 = varargin{2}; irf3 = varargin{3}; irf4=varargin{4}; irf5=irfnull;
    case 5  % Plot two series
        irf1 = varargin{1};  irf2 = varargin{2}; irf3 = varargin{3}; irf4=varargin{4}; irf5=varargin{5};
    otherwise
        error('Too many input series');
end



% LEGEND TO USE
legend_use = {varargin{nseries+1:length(varargin)}}';


%==========================================================================
%                               IMPULSE RESPONSES
%==========================================================================

xt = (1:Tirf);

%**** Government Expenditure Shock ****%
NTicks = 4;

if strcmp(shock_use,'3x4')
    
    figure(1);clf;
    set(figure(1),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[-0.2 -0.2 11.5 8]);
    
    subplot(3,4,1)
    plotshaded(xt,[lband.R_ez uband.R_ez]',color_shade); hold on
    h = plot(xt, irf1.R_ez,'-',xt, irf2.R_ez,'-',...
        xt, irf3.R_ez,'-x',xt,irf4.R_ez,'s-',...
        xt, irf5.R_ez,'*-');
    y=ylabel('$\epsilon_z$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
    set(y, 'Units', 'Normalized', 'Position', [-0.3, 0.5, 0]);
    beutifyplot('Interest Rate $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(3,4,2)
    plotshaded(xt,[lband.pi_ez uband.pi_ez]',color_shade); hold on
    plot(xt, irf1.pi_ez,'-',xt, irf2.pi_ez,'-',...
        xt, irf3.pi_ez,'-x',xt,irf4.pi_ez,'s-',...
        xt, irf5.pi_ez,'*-');
    beutifyplot('Inflation $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(3,4,3)
    plotshaded(xt,[lband.BIGY_ez uband.BIGY_ez]',color_shade); hold on
    plot(xt, irf1.BIGY_ez,'-',xt, irf2.BIGY_ez,'-',...
        xt, irf3.BIGY_ez,'-x',xt,irf4.BIGY_ez,'s-',...
        xt, irf5.BIGY_ez,'*-');
    beutifyplot('Y (Level) $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(3,4,4)
    plotshaded(xt,[lband.BIGC_ez uband.BIGC_ez]',color_shade); hold on
    plot(xt, irf1.BIGC_ez,'-',xt, irf2.BIGC_ez,'-',...
        xt, irf3.BIGC_ez,'-x',xt,irf4.BIGC_ez,'s-',...
        xt, irf5.BIGC_ez,'*-');
    beutifyplot('C (Level) $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)

    
    subplot(3,4,5)
    plotshaded(xt,[lband.R_eg uband.R_eg]',color_shade); hold on
    h = plot(xt, irf1.R_eg,'-',xt, irf2.R_eg,'-',...
        xt, irf3.R_eg,'-x',xt,irf4.R_eg,'s-',...
        xt, irf5.R_eg,'*-');
    y=ylabel('$\epsilon_g$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
    set(y, 'Units', 'Normalized', 'Position', [-0.3, 0.5, 0]);
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(3,4,6)
    plotshaded(xt,[lband.pi_eg uband.pi_eg]',color_shade); hold on
    plot(xt, irf1.pi_eg,'-',xt, irf2.pi_eg,'-',...
        xt, irf3.pi_eg,'-x',xt,irf4.pi_eg,'s-',...
        xt, irf5.pi_eg,'*-');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(3,4,7)
    plotshaded(xt,[lband.BIGY_eg uband.BIGY_eg]',color_shade); hold on
    plot(xt, irf1.BIGY_eg,'-',xt, irf2.BIGY_eg,'-',...
        xt, irf3.BIGY_eg,'-x',xt,irf4.BIGY_eg,'s-',...
        xt, irf5.BIGY_eg,'*-');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(3,4,8)
    plotshaded(xt,[lband.BIGC_eg uband.BIGC_eg]',color_shade); hold on
    plot(xt, irf1.BIGC_eg,'-',xt, irf2.BIGC_eg,'-',...
        xt, irf3.BIGC_eg,'-x',xt,irf4.BIGC_eg,'s-',...
        xt, irf5.BIGC_eg,'*-');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)

    
    subplot(3,4,9)
    plotshaded(xt,[lband.R_er uband.R_er]',color_shade); hold on
    plot(xt, irf1.R_er,'-',xt, irf2.R_er,'-',...
        xt, irf3.R_er,'-x',xt,irf4.R_er,'s-',...
        xt, irf5.R_er,'*-');
    y=ylabel('$\epsilon_r$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
    set(y, 'Units', 'Normalized', 'Position', [-0.3, 0.5, 0]);
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(3,4,10)
    plotshaded(xt,[lband.pi_er uband.pi_er]',color_shade); hold on
    plot(xt, irf1.pi_er,'-',xt, irf2.pi_er,'-',...
        xt, irf3.pi_er,'-x',xt,irf4.pi_er,'s-',...
        xt, irf5.pi_er,'*-');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(3,4,11)
    plotshaded(xt,[lband.BIGY_er uband.BIGY_er]',color_shade); hold on
    h= plot(xt, irf1.BIGY_er,'-',xt, irf2.BIGY_er,'-',...
        xt, irf3.BIGY_er,'-x',xt,irf4.BIGY_er,'s-',...
        xt, irf5.BIGY_er,'*-');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    
    subplot(3,4,12)
    plotshaded(xt,[lband.BIGC_er uband.BIGC_er]',color_shade); hold on
    h= plot(xt, irf1.BIGC_er,'-',xt, irf2.BIGC_er,'-',...
        xt, irf3.BIGC_er,'-x',xt,irf4.BIGC_er,'s-',...
        xt, irf5.BIGC_er,'*-');
    legend(h(1:nseries),legend_use,'Location','SE'); legend boxoff
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    suptitle(strrep(model_number,'_',''));
    
elseif strcmp(shock_use,'4x4')
    %%
    figure(1);clf;
    set(figure(1),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[-0.2 -0.2 11.5 8]);
    
    
    ub=max([irf1.logY_ez; irf2.logY_ez; irf1.logC_ez; irf2.logC_ez]);
    lb=min([irf1.logY_ez; irf2.logY_ez; irf1.logC_ez; irf2.logC_ez]);
    
    subplot(4,4,1)
    plotshaded(xt,[lband.logY_ez uband.logY_ez]',color_shade); hold on
    plot(xt, irf1.logY_ez,'-',xt, irf2.logY_ez,'--');
    y = ylabel('$\epsilon_z$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
    ylim([lb, ub]);
    set(y, 'Units', 'Normalized', 'Position', [-0.3, 0.5, 0]);
    beutifyplot('Output $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(4,4,2)
    plotshaded(xt,[lband.logC_ez uband.logC_ez]',color_shade); hold on
    h= plot(xt, irf1.logC_ez,'-',xt, irf2.logC_ez,'--'); 
    ylim([lb, ub]); %if max(abs(ylim_use))<0.005; ylim([-0.1 0.1]); end;
    beutifyplot('Consumption $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
        
    subplot(4,4,3)
    plotshaded(xt,[lband.pi_ez uband.pi_ez]',color_shade); hold on
    plot(xt, irf1.pi_ez,'-',xt, irf2.pi_ez,'--');
    beutifyplot('Inflation $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(4,4,4)
    plotshaded(xt,[lband.R_ez uband.R_ez]',color_shade); hold on
    h = plot(xt, irf1.R_ez,'-',xt, irf2.R_ez,'--');
    beutifyplot('Interest Rate $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    
    ub=max([irf1.logY_eg; irf2.logY_eg; irf1.logC_eg; irf2.logC_eg]);
    lb=min([irf1.logY_eg; irf2.logY_eg; irf1.logC_eg; irf2.logC_eg]);

    subplot(4,4,5)
    plotshaded(xt,[lband.logY_eg uband.logY_eg]',color_shade); hold on
    plot(xt, irf1.logY_eg,'-',xt, irf2.logY_eg,'--');
    ylim([lb, ub]);
    y=ylabel('$\epsilon_g$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
    set(y, 'Units', 'Normalized', 'Position', [-0.3, 0.5, 0]);    
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)

    subplot(4,4,6)
    plotshaded(xt,[lband.logC_eg uband.logC_eg]',color_shade); hold on
    ylim([lb, ub]);
    h= plot(xt, irf1.logC_eg,'-',xt, irf2.logC_eg,'--'); 
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
        
    subplot(4,4,7)
    plotshaded(xt,[lband.pi_eg uband.pi_eg]',color_shade); hold on
    plot(xt, irf1.pi_eg,'-',xt, irf2.pi_eg,'--');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(4,4,8)
    plotshaded(xt,[lband.R_eg uband.R_eg]',color_shade); hold on
    h = plot(xt, irf1.R_eg,'-',xt, irf2.R_eg,'--');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)

    ub=max([irf1.logY_ed; irf2.logY_ed; irf1.logC_ed; irf2.logC_ed]);
    lb=min([irf1.logY_ed; irf2.logY_ed; irf1.logC_ed; irf2.logC_ed]);    
    
    subplot(4,4,9)
    plotshaded(xt,[lband.BIGY_ed uband.BIGY_ed]',color_shade); hold on
    h= plot(xt, irf1.logY_ed,'-',xt, irf2.logY_ed,'--');
    ylim([lb, ub]);
    y=ylabel('$\epsilon_d$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
    set(y, 'Units', 'Normalized', 'Position', [-0.3, 0.5, 0]);
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)

    subplot(4,4,10)
    plotshaded(xt,[lband.logC_ed uband.logC_ed]',color_shade); hold on
    h= plot(xt, irf1.logC_ed,'-',xt, irf2.logC_ed,'--');
    ylim([lb, ub]); %if max(abs(ylim_use))<0.005; ylim([-0.1 0.1]); end;
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
            
    subplot(4,4,11)
    plotshaded(xt,[lband.pi_ed uband.pi_ed]',color_shade); hold on
    plot(xt, irf1.pi_ed,'-',xt, irf2.pi_ed,'--');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(4,4,12)
    plotshaded(xt,[lband.R_ed uband.R_ed]',color_shade); hold on
    plot(xt, irf1.R_ed,'-',xt, irf2.R_ed,'--');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    ub=max([irf1.logY_er; irf2.logY_er; irf1.logC_er; irf2.logC_er]);
    lb=min([irf1.logY_er; irf2.logY_er; irf1.logC_er; irf2.logC_er]);
    
    subplot(4,4,13)
    plotshaded(xt,[lband.logY_er uband.logY_er]',color_shade); hold on
    h= plot(xt, irf1.logY_er,'-',xt, irf2.logY_er,'--');
    ylim([lb, ub]);
    y=ylabel('$\epsilon_r$','Fontsize',18,'fontweight','bold','rot',360,'interpreter','Latex');
    set(y, 'Units', 'Normalized', 'Position', [-0.3, 0.5, 0]);    
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)

    subplot(4,4,14)
    plotshaded(xt,[lband.logC_er uband.logC_er]',color_shade); hold on
    h= plot(xt, irf1.logC_er,'-',xt, irf2.logC_er,'--'); ylim([-0.1 0.1]);
    ylim([lb, ub]); %if max(abs(ylim_use))<0.005; ylim([-0.1 0.1]); end;
    %legend(h(1:nseries),legend_use,'Location','SE'); legend boxoff
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)
            
    subplot(4,4,15)
    plotshaded(xt,[lband.pi_er uband.pi_er]',color_shade); hold on
    plot(xt, irf1.pi_er,'-',xt, irf2.pi_er,'--');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)    
    
    subplot(4,4,16)
    plotshaded(xt,[lband.R_er uband.R_er]',color_shade); hold on
    plot(xt, irf1.R_er,'-',xt, irf2.R_er,'--');
    beutifyplot('', [1 xt(end)], ylim, 'zeroline',NTicks)

    suptitle(['Trend Gap Model: ' strrep(model_number,'_','')]);
%%
else
    
    figure(1); clf;
    set(figure(1),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.25 0.25 10.5 8]);
    subplot(2,2,1)
    plotshaded(xt,[lband.(['R_' shock_use]) uband.(['R_' shock_use])]',color_shade); hold on
    h = plot(xt, irf1.(['R_' shock_use]),'-',xt, irf2.(['R_' shock_use]),'-',...
        xt, irf3.(['R_' shock_use]),'-x',xt,irf4.(['R_' shock_use]),'s-',...
        xt, irf5.(['R_' shock_use]),'*-');
    legend(h(1:nseries),legend_use,'Location','SW'); legend boxoff
    beutifyplot('Interest Rate $(\%)$', [1 xt(end)], [-.5 5], 'zeroline',NTicks)
    
    subplot(2,2,2)
    plotshaded(xt,[lband.(['pi_' shock_use]) uband.(['pi_' shock_use])]',color_shade); hold on
    plot(xt, irf1.(['pi_' shock_use]),'-',xt, irf2.(['pi_' shock_use]),'-',...
        xt, irf3.(['pi_' shock_use]),'-x',xt,irf4.(['pi_' shock_use]),'s-',...
        xt, irf5.(['pi_' shock_use]),'*-');
    beutifyplot('Inflation $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    % subplot(2,3,3)
    % plotshaded(xt,[lband.(['h_' shock_use]) uband.(['h_' shock_use])]',color_shade); hold on
    % plot(xt, irf1.(['h_' shock_use]),'-',xt, irf2.(['h_' shock_use]),'-',...
    %      xt, irf3.(['h_' shock_use]),'-x',xt,irf4.(['h_' shock_use]),'s-',...
    %      xt, irf5.(['h_' shock_use]),'*-');
    % beutifyplot('Hours $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    % subplot(2,3,4)
    % plotshaded(xt,[lband.(['w_' shock_use]) uband.(['w_' shock_use])]',color_shade); hold on
    % plot(xt, irf1.(['w_' shock_use]),'-',xt, irf2.(['w_' shock_use]),'-',...
    %      xt, irf3.(['w_' shock_use]),'-x',xt,irf4.(['w_' shock_use]),'s-',...
    %      xt, irf5.(['w_' shock_use]),'*-');
    % beutifyplot('Wages $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(2,2,3)
    plotshaded(xt,[lband.(['BIGC_' shock_use]) uband.(['BIGC_' shock_use])]',color_shade); hold on
    plot(xt, irf1.(['BIGC_' shock_use]),'-',xt, irf2.(['BIGC_' shock_use]),'-',...
        xt, irf3.(['BIGC_' shock_use]),'-x',xt,irf4.(['BIGC_' shock_use]),'s-',...
        xt, irf5.(['BIGC_' shock_use]),'*-');
    beutifyplot('C (Level) $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    subplot(2,2,4)
    plotshaded(xt,[lband.(['BIGY_' shock_use]) uband.(['BIGY_' shock_use])]',color_shade); hold on
    plot(xt, irf1.(['BIGY_' shock_use]),'-',xt, irf2.(['BIGY_' shock_use]),'-',...
        xt, irf3.(['BIGY_' shock_use]),'-x',xt,irf4.(['BIGY_' shock_use]),'s-',...
        xt, irf5.(['BIGY_' shock_use]),'*-');
    beutifyplot('Y (Level) $(\%)$', [1 xt(end)], ylim, 'zeroline',NTicks)
    
    % ADD SUP TITLE TO PLOT
    if isempty(pick_date)
        if strcmp(shock_use,'ez')
            suptitle([country '. Response to a technology shock']);
        elseif strcmp(shock_use,'eg') 
            suptitle([country '. Response to a demand shock']);
        elseif strcmp(shock_use,'er')
            suptitle([country '. Response to a monetary policy shock']);
        elseif strcmp(shock_use,'eg_fg') 
            suptitle([country '. Response to a demand shock with FG']);
        end
    else
        if strcmp(shock_use,'ez')
            suptitle([country '. Response to a technology shock : ' num2str(pick_date)]);
        elseif strcmp(shock_use,'eg')
            suptitle([country '. Response to a demand no FG shock : ' num2str(pick_date)]);
        elseif strcmp(shock_use,'er')
            suptitle([country '. Response to a monetary policy shock : ' num2str(pick_date)]);
        elseif strcmp(shock_use,'eg_fg')
            suptitle([country '. Response to a demand shock with FG: ' num2str(pick_date)]);
        end
    end
end


%==========================================================================
%                               PRINT FIGURES
%==========================================================================

if ind_print==1
    
    
    %**** File name options %
%     if size_shock>0
%         temp = ['Positive' num2str(abs(size_shock)) 'SD'];
%     else
%         temp = ['Negative' num2str(abs(size_shock)) 'SD'];
%     end
    
    temp = [];
    
    fprintf('\n Printing figures to a .pdf file ... \n');
    
    if ind_period_one==1;
        figname = strcat(pwd,'/FIGURES/IRF/',label_in,shock_use,'_',strrep(model_number,'_',''),tag_name,'.pdf');
    else
        figname = strcat(pwd,'/FIGURES/IRF/',label_in,shock_use,'_','ind0_',strrep(model_number,'_',''),tag_name,'_',temp,'.pdf');
    end
    
    %print(figure(1),'-dpsc2','-r600','-painters',figname);
    
    print(figure(1),'-dpdf','-r300','-painters',figname);
       
  
end





% print(3,'-dpdf','-r300','Test.pdf','-Painters')
%fill([xt,xt(end:-1:1)],[lband.R_eg uband.R_eg(end:-1:1)],[0.2,0.6,0.5],'EdgeColor','non')
%     ftitle = strcat('Rho0=',num2str(rho0),'-Rho1=',num2str(rho1),'--');
%     sub_title = strcat('pi_A(%) =  ', num2str(piannual), ' - ','pi_bar(%) =  ',num2str(400*(pibar-1)));

