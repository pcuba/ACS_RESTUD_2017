% Function to create grid points from the ergodic set based on a long 
% simulation of the model
% 
% simuse  = Structure containing the simulated endongeous variables.
% Mpoints = Number of grid points to generate from the ergodic set. 
%
% Created: April 18, 2014
% updated: February 12, 2015
%==========================================================================

function [GRID0,GRID1] = get_ergodic_grid(simuse,Mpoints)

simtemp(:,1) = simuse.R(1:end-1,1);     % R_lag;
simtemp(:,2) = simuse.trend(1:end-1,1); % trend_lag;
simtemp(:,3) = simuse.d(2:end,1);       % d
simtemp(:,4) = simuse.er(2:end,1);      % er
simtemp(:,5) = simuse.z(2:end,1);       % z
simtemp(:,6) = simuse.g(2:end,1);       % g
simtemp(:,7) = simuse.SUN(2:end,1);     % s
simtemp(:,8) = simuse.SUN(1:end-1,1);   % s_lag

simtemp1 = simtemp(simtemp(:,7) == 1,:);
simtemp0 = simtemp(simtemp(:,7) == 0,:);

[~, GRID1,~] = tsga_grid(simtemp1, round(Mpoints/2));

[~, GRID0, ~] = tsga_grid(simtemp0, round(Mpoints/2));

