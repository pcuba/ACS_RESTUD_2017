% AUXILIARY FUNCTION TO ADD FORMAT TO THE PLOTS
%           Argument   Description                   Type  
%           --------- --------------------------  -------------------
%           title_in:  Title for graph/subplot.      String
%           xlim:      Limits for x-axis.            [1x2] vector. 
%           ylim:      Limits for y-axis.            [1x2] vector. 
%           zeroline:  Draw dashed zero line.        Any input. [] to skip.
%           Nticks:    Number of ticks in yaxis.     Integer.
% 
% Writen by Pablo Cuba-Borda.
% University of Maryland. 
% 
% Created: March 1, 2014. 

    function beutifyplot(title_in, xlim_in, ylim_in, zeroline,NTicks)
        
        title(title_in,'FontSize',18,'fontweight','bold','Interpreter','latex');
        
        xlim(xlim_in);
        
        if ~isempty(zeroline); hline(0,'m--'); end;
        
        ylim_use = ylim;
        ylim(ylim_use);
        
%         axis tight;
%         L = get(gca,'YLim'); 
%         
%         
%         TickStep = (roundn(L(2),1) - L(1)) / (NTicks);
%         
%         if fix(TickStep/0.1)>0
%             TickStep = roundn(TickStep,1);
%         else 
%             TickStep = max(0.05,roundn(TickStep+0.02,2));
%         end
%         
%         L = roundn(L,1);
%         
%         yticks = (L(1):TickStep:L(2));
%         
%         if isempty(find(yticks==0, 1));
%             [~, index_zero] = min(abs(yticks));
%             yticks(index_zero) = 0;
%         end
%         
%         %yticks = yticks(1:NTicks+1);
%         
%         set(gca,'YTick',yticks)
%         
%         set(gca,'YTickLabel',sprintf('%3.2f|',yticks))
        
        
        set(gca,'FontSize',14);
        
        box on;
        
        set(gca,'Layer','top')
        
    end
