% Function the simulates the Sunspot Model (M3) with output gap trend rule 
% and returns a structure with the simulated series.
%
% Inputs:
%           theta_in: vector of coefficients from model solution.
%           shocks_in: structure with realizations of the exogenous shocks
%           init: structure with initial values for simulation
%           T: number of simulations to be produced
%           Tdrop: burn-in period for simulation
%           SUN: vector containing realizations of the sunspot variable
%
% Updates:
%         RH, 01/29/2015
%         PC, 02/17/2015
%         BA, 03/13/2015
%         PC, 05/12/2015
%--------------------------------------------------------------------------

function outsim = simulate_sunspot(theta_in,shocks_in,init,T,Tdrop,SUN)

global bad_sim_flag Rbar

global par ncoefs

%--------------------------------------------------------------------------
% Map Parameters
%--------------------------------------------------------------------------

phi    = par.phi;
tau    = par.tau;
eta    = par.eta;
psi1   = par.psi1;
psi2   = par.psi2;
beta   = par.beta;
gamma  = par.gamma;
pi_ss  = par.pi_ss;
pibar  = par.pibar;
gstar  = par.gstar;
rho_z  = par.rho_z;
rho_g  = par.rho_g;
r      = par.r;
rho_R  = par.rho_R;
rho_d  = par.rho_d;
chi_h  = par.chi_h;
alp    = par.alp;

%--------------------------------------------------------------------------
% Map Coefficients
%--------------------------------------------------------------------------

theta_ee1_1_1 = theta_in(1:ncoefs,1);             % 1 state THETA / NON ZLB
theta_pi_1_1  = theta_in(ncoefs+1:2*ncoefs,1);
theta_ee1_1_2 = theta_in(2*ncoefs+1:3*ncoefs,1);  % 1 state THETA / ZLB
theta_pi_1_2  = theta_in(3*ncoefs+1:4*ncoefs,1);

theta_ee1_0_1 = theta_in(4*ncoefs+1:5*ncoefs,1);  % 0 state THETA / NON ZLB
theta_pi_0_1  = theta_in(5*ncoefs+1:6*ncoefs,1);
theta_ee1_0_2 = theta_in(6*ncoefs+1:7*ncoefs,1);  % 0 state THETA / ZLB
theta_pi_0_2  = theta_in(7*ncoefs+1:8*ncoefs,1);

%--------------------------------------------------------------------------
%   Preallocate vectors
%--------------------------------------------------------------------------
TT = T + Tdrop;                                   % Total # of observations

ys  = zeros(TT,1);
Rstars = zeros(TT,1);
cs  = zeros(TT,1);
hs  = zeros(TT,1);
ws  = zeros(TT,1);
pis = zeros(TT,1);
Rs  = zeros(TT,1);
zs  = zeros(TT,1);
gs  = zeros(TT,1);
ds  = zeros(TT,1);
ee1s= zeros(TT,1);
CCs = zeros(TT,1);
YYs = zeros(TT,1);
GGs = zeros(TT,1);
As  = zeros(TT,1);
delys = zeros(TT,1);
delcs = zeros(TT,1);
trends= zeros(TT,1);
us = zeros(TT,1);
%--------------------------------------------------------------------------
% Map shocks
%--------------------------------------------------------------------------

ers = shocks_in.er;
egs = shocks_in.eg;
ezs = shocks_in.ez;
eds = shocks_in.ed;

%--------------------------------------------------------------------------
% Define Rbar for ZLB check
%--------------------------------------------------------------------------

if length(Rbar)==1
    Rbar_use = ones(TT,1)*Rbar;
elseif length(Rbar)==TT
    Rbar_use = Rbar;
else
    error('Not enouth observations in Rbar');
end

%--------------------------------------------------------------------------
%   Main Simulation Code
%--------------------------------------------------------------------------

for tt = 1 : TT
    
    if tt == 1
        
        R_lag = init.Rlag;
        trendlag = init.trendlag;
        y_lag = init.ylag;
        c_lag = init.clag;
        d_lag = init.dlag;
        z_lag = init.zlag;
        g_lag = init.glag;
        A_lag = init.Alag;
        
    else
        
        R_lag = Rs(tt-1);
        trendlag = trends(tt-1);
        y_lag = ys(tt-1);
        c_lag = cs(tt-1);
        d_lag = ds(tt-1);
        z_lag = zs(tt-1);
        g_lag = gs(tt-1);
        A_lag = As(tt-1);
        
    end
    
    ds(tt)   = rho_d*d_lag + eds(tt);
    zs(tt)   = rho_z*z_lag + ezs(tt);
    gs(tt)   = (1-rho_g)*log(gstar) + rho_g*g_lag + egs(tt);
    As(tt)   = gamma*A_lag*exp(zs(tt));
    
    
    % Basis Function %
    try
        PSI_use = basis_temp(R_lag, trendlag, ds(tt), ers(tt), zs(tt), gs(tt));
    catch
        bad_sim_flag = 1;
        outsim = [];
        fprintf('\n Warning! Bad simulation found in period %i \n',tt);
        keyboard
    end
    
    % Assuming ZLB is slack -- use "1" decision rules
    if SUN(tt,1) == 1        % s=1 --> STAR
        ee1s(tt) = PSI_use'*theta_ee1_1_1;
        pis(tt)  = PSI_use'*theta_pi_1_1;
    else                    % s=0 --> TILDE
        ee1s(tt) = PSI_use'*theta_ee1_0_1;
        pis(tt)  = PSI_use'*theta_pi_0_1;
    end
            
    % Assume ZLB is slack
    temp     =  ((r*pi_ss*((pis(tt)/pi_ss)^psi1)*((exp(zs(tt))/trendlag)^(alp*psi2)))^(1-rho_R))*((R_lag)^rho_R)*exp(ers(tt));         
    ys(tt)    =  ( (beta*ee1s(tt)*temp) / (((1/exp(gs(tt))) - 0.5*phi*(pis(tt) - pibar)^2)^(-tau)) )^(-1/(tau + alp*psi2*(1-rho_R)));
    trends(tt)= (trendlag^alp)*(ys(tt)^(1-alp))*exp(-alp*zs(tt));
    Rstars(tt)=  ((r*pi_ss*((pis(tt)/pi_ss)^psi1)*(((ys(tt)/trends(tt)))^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(ers(tt));            
    Rs(tt)    =  Rstars(tt);
    cs(tt)    = (beta*Rs(tt)*ee1s(tt))^(-1/tau);

    
    % Check ZLB %
    if Rs(tt) <=  Rbar_use(tt); % Then use the "2" decision rules
        
        Rs(tt) = 1;
        if SUN(tt,1) == 1        % s=1 --> STAR
            ee1s(tt) = PSI_use'*theta_ee1_1_2;
            pis(tt)  = PSI_use'*theta_pi_1_2;
        else                    % s=0 --> TILDE
            ee1s(tt) = PSI_use'*theta_ee1_0_2;
            pis(tt)  = PSI_use'*theta_pi_0_2;
        end
        
        cs(tt)    = (beta*Rs(tt)*ee1s(tt))^(-1/tau);
        ys(tt)    = cs(tt) / ((1/exp(gs(tt))) - 0.5*phi*(pis(tt) - pibar)^2);
        trends(tt)= (trendlag^alp)*(ys(tt)^(1-alp))*exp(-alp*zs(tt));

    end
    
    delys(tt) = 400 * log(gamma *exp(zs(tt)) * ys(tt) / y_lag);  
    delcs(tt) = 400 * log(gamma *exp(zs(tt)) * cs(tt) / c_lag);
   
    % Construct level variables %
    if As(tt) < 1E11;
        
        CCs(tt) = cs(tt)*As(tt);
        YYs(tt) = ys(tt)*As(tt);
        GGs(tt) = (1 - (1/exp(gs(tt)))) * YYs(tt);
        
    else
        
        CCs(tt)= NaN;
        YYs(tt)= NaN;
        GGs(tt)= NaN;
    end
    
    % Additional objects
    hs(tt) = ys(tt);
    ws(tt) = chi_h*(ys(tt)^(1/eta))*cs(tt)^tau;
    
    % Instantaneous utility
    u_t    = ((cs(tt)^(1-tau)-1)/(1-tau)) - chi_h*((hs(tt)^(1+1/eta))/(1+1/eta)); 
 
    us(tt) = u_t;
    
    % Check for errors %
    if cs(tt)<0 || ys(tt)<0;
        fprintf('\n There is some boundary problem in period %5i \n',tt);
        fprintf('\n  Adjust R_min, R_max, y_min, y_max!!!! \n');
        keyboard;
    end
    
    if isreal(pis(tt))==0;
        fprintf('\n Inflation is imaginary in period %5i \n',tt);
        keyboard;
        %        error('Error');
    end
    
end

%--------------------------------------------------------------------------
% Trim simulation and output results
%--------------------------------------------------------------------------

outsim.pi    = pis(Tdrop+1:T+Tdrop);
outsim.R     = Rs(Tdrop+1:T+Tdrop);
outsim.Rstar = Rstars(Tdrop+1:T+Tdrop);
outsim.y     = ys(Tdrop+1:T+Tdrop);
outsim.c   = cs(Tdrop+1:T+Tdrop);
outsim.h   = hs(Tdrop+1:T+Tdrop);
outsim.w   = ws(Tdrop+1:T+Tdrop);
outsim.ee1 = ee1s(Tdrop+1:T+Tdrop);
outsim.er  = ers(Tdrop+1:T+Tdrop);
outsim.eg  = egs(Tdrop+1:T+Tdrop);
outsim.ez  = ezs(Tdrop+1:T+Tdrop);
outsim.ed  = eds(Tdrop+1:T+Tdrop);
outsim.d   = ds(Tdrop+1:T+Tdrop);
outsim.z   = zs(Tdrop+1:T+Tdrop);
outsim.g   = gs(Tdrop+1:T+Tdrop);
outsim.BIGC= CCs(Tdrop+1:T+Tdrop);
outsim.BIGY= YYs(Tdrop+1:T+Tdrop);
outsim.BIGG= GGs(Tdrop+1:T+Tdrop);
outsim.A   = As(Tdrop+1:T+Tdrop);
outsim.SUN = SUN(Tdrop+1:T+Tdrop);
outsim.dely= delys(Tdrop+1:T+Tdrop);
outsim.delc= delcs(Tdrop+1:T+Tdrop);
outsim.trend= trends(Tdrop+1:T+Tdrop);
outsim.logy= log(ys(Tdrop+1:T+Tdrop));
outsim.UU  = us(Tdrop+1:T+Tdrop);

% Get lagged simulations of endogenous states %

if Tdrop==0
    outsim.Rlag(1,1)= init.Rlag;
    outsim.ylag(1,1)= init.ylag;
    outsim.clag(1,1)= init.clag;
    outsim.trendlag(1,1)= init.trendlag;

    outsim.Rlag(2:TT,1)=Rs(1:end-1);
    outsim.ylag(2:TT,1)=ys(1:end-1);
    outsim.clag(2:TT,1)=cs(1:end-1);
    outsim.trendlag(2:TT,1)=trends(1:end-1);

    
    
else
    outsim.Rlag= Rs(Tdrop:end-1);
    outsim.ylag= ys(Tdrop:end-1);
    outsim.clag= cs(Tdrop:end-1);    
    outsim.trendlag= trends(Tdrop:end-1);
    outsim.SUNlag = SUN(Tdrop:end-1);
end




