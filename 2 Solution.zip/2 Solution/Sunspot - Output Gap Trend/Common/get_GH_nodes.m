% Function to Construct GAUSS-HERMITE Integration Nodes
% This function returns the integration nodes using a tensor product rule
% 
% Updated (RH): 01/29/2015
%==========================================================================

function [ER_nodes, EZ_nodes, EG_nodes, ED_nodes, WEIGHT] = get_GH_nodes(Q_in)

global par
sig_r = par.sig_r;
sig_z = par.sig_z;
sig_g = par.sig_g;
sig_d = par.sig_d;

[quadpoint,weight] = ghpoints(Q_in);    % quadrature nodes and weights

% The following are the points for the case of 3 uncorrelated random process
% with mean zero and variance sig_

er_prime = (sqrt(2)*sig_r*quadpoint);                    
ez_prime = (sqrt(2)*sig_z*quadpoint);                    
eg_prime = (sqrt(2)*sig_g*quadpoint);
ed_prime = (sqrt(2)*sig_d*quadpoint);  

% Create product rule %

ER_nodes = kron(er_prime,ones(Q_in^3,1));                       % All the er'
EZ_nodes = kron(ones(Q_in,1),kron(ez_prime,ones(Q_in^2,1)));    % All the ez'
EG_nodes = kron(ones(Q_in^2,1),kron(eg_prime,ones(Q_in,1)));    % All the eg'
ED_nodes = kron(ones(Q_in^3,1),ed_prime);                       % All the ed'

WEIGHT  = ((1/sqrt(pi))^4)*(kron(weight,kron(weight,kron(weight,weight))));  % weights for the product rule integral