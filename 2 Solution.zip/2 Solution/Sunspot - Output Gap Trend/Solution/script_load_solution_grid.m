% Script to load filtered grid for Sunspot Treng Gap Model
%
%--------------------------------------------------------------------------

if O.ind_grid == 1
    
    filtered_states_use = ['FILTERED_GRID_SUNSPOT_' model_number];

    load(filtered_states_use);

    % 1   2   3   4   5   6   7   8       9       10      11      12  13  14
    % pi	R	y	c	h	w	ee1	epsr    epsg	epsz	epsd	d	z	g

    % 15  16  17  18          19  20  21      22      23          24
    % CC	YY	GG	LevelTrend	A	SUN	dely	delc	detrendTr	R(lag)

    % 25      26      27      28      29      30          31  32  33  34
    % y(lag)	c(lag)	d(lag)	z(lag)	g(lag)	SUN(lag)	my	mc	mpi	mR

    % ARRANGE FILTERED STATES
    FILTERED_STATES.er    = RAW(:,8);
    FILTERED_STATES.d     = RAW(:,12);
    FILTERED_STATES.z     = RAW(:,13);
    FILTERED_STATES.g     = RAW(:,14);
    FILTERED_STATES.A     = RAW(:,19);
    FILTERED_STATES.SUN   = RAW(:,20);
    FILTERED_STATES.dely  = RAW(:,21);
    FILTERED_STATES.trend = RAW(:,23);
    FILTERED_STATES.Rlag  = RAW(:,24);
    FILTERED_STATES.ylag  = RAW(:,25);
    FILTERED_STATES.clag  = RAW(:,26);
    FILTERED_STATES.dlag  = RAW(:,27);
    FILTERED_STATES.zlag  = RAW(:,28);
    FILTERED_STATES.glag  = RAW(:,29);

    FILTERED_STATES.ez = RAW(:,13) - rho_z .* RAW(:,28);
    FILTERED_STATES.eg = RAW(:,14) - (1 - rho_g) * log(gstar) ...
                       - rho_g .* RAW(:,29);
    FILTERED_STATES.ed = RAW(:,12) - rho_d .* RAW(:,27);

    % CONSTRUCT trend(-1):
    FILTERED_STATES.trendlag = exp( -((1-par.alp)/par.alp)*log(RAW(:,3)) + RAW(:,13) + (1/par.alp)*log(RAW(:,23)));

    clear RAW;

    num_filtered_states = length(FILTERED_STATES.Rlag);

    fprintf('\n *** I will use %i filtered states *** \n', num_filtered_states);

    % MAKE SURE FILTERED SUNSPOT IS IN {0,1}
    sun_threshold = 0.1;
    FILTERED_STATES.SUN(FILTERED_STATES.SUN<=sun_threshold)=0;
    FILTERED_STATES.SUN(FILTERED_STATES.SUN> sun_threshold)=1;


    % COLLECTED FILTERED STATES
    if O.ind_params==2;

        % Now bring in Filtered Data for the US

        % For the US we have:
        % Filtered data 2000Q1-2008Q4       36  obs
        % Filtered Particles 2009Q1-2013Q4	320 obs (8 particles per period)

        % The filtered data from 2000-2008Q4
        Rlaggrid2  = FILTERED_STATES.Rlag(1:36);        % R grid
        tlaggrid2  = FILTERED_STATES.trendlag(1:36);        % trendlag grid
        dgrid2     = FILTERED_STATES.d(1:36);           % d grid
        ergrid2    = FILTERED_STATES.er(1:36);          % e_R grid
        zgrid2     = FILTERED_STATES.z(1:36);           % z grid
        ggrid2     = FILTERED_STATES.g(1:36);           % g grid
        sgrid2     = max(FILTERED_STATES.SUN(1:36),ones(36,1));  % s grid

        % The filtered data from 2009Q1-2013Q4 assuming S = 0 throughout (8
        % particles per period)

        Rlaggrid3 = FILTERED_STATES.Rlag(37:196);       % R grid
        tlaggrid3 = FILTERED_STATES.trendlag(37:196);       % trendlag grid
        dgrid3  = FILTERED_STATES.d(37:196);            % d grid
        ergrid3 = FILTERED_STATES.er(37:196);           % e_R grid
        zgrid3  = FILTERED_STATES.z(37:196);            % z grid
        ggrid3  = FILTERED_STATES.g(37:196);            % g grid
        sgrid3  = FILTERED_STATES.SUN(37:196);          % s grid

        % The filtered data from 2009Q1-2013Q4 assuming S = 1 throughout (8
        % particles per period)

        Rlaggrid4 = FILTERED_STATES.Rlag(197:356);      % R grid
        tlaggrid4 = FILTERED_STATES.trendlag(197:356);      % trendlag grid
        dgrid4    = FILTERED_STATES.d(197:356);         % d grid
        ergrid4   = FILTERED_STATES.er(197:356);        % e_R grid
        zgrid4    = FILTERED_STATES.z(197:356);         % z grid
        ggrid4    = FILTERED_STATES.g(197:356);         % g grid
        sgrid4    = FILTERED_STATES.SUN(197:356);       % s grid

    elseif O.ind_params==3
        % For JP we have
        % No filtered states
        Rlaggrid2  = [];  % R grid
        tlaggrid2  = [];  % trendlag grid
        dgrid2     = [];  % d grid
        ergrid2    = [];  % e_R grid
        zgrid2     = [];  % z grid
        ggrid2     = [];  % g grid
        sgrid2     = [];  % s grid

        % Filtered particles from 1999Q1-2015Q1 assuming S = 0
        % throughout (3 particles per period)
        Rlaggrid3 = FILTERED_STATES.Rlag(1:130);       % Rlag grid
        tlaggrid3 = FILTERED_STATES.trendlag(1:130);   % trendlag grid
        dgrid3  = FILTERED_STATES.d(1:130);            % d grid
        ergrid3 = FILTERED_STATES.er(1:130);           % e_R grid
        zgrid3  = FILTERED_STATES.z(1:130);            % z grid
        ggrid3  = FILTERED_STATES.g(1:130);            % d grid
        sgrid3  = FILTERED_STATES.SUN(1:130);          % s grid


        % Filtered particles from 1999Q1-2015Q1 assuming S = 1
        % throughout (3 particles per period)
        Rlaggrid4 = FILTERED_STATES.Rlag(131:260);      % Rlag grid
        tlaggrid4 = FILTERED_STATES.trendlag(131:260);      % trendlag grid
        dgrid4    = FILTERED_STATES.d(131:260);         % d grid
        ergrid4   = FILTERED_STATES.er(131:260);        % e_R grid
        zgrid4    = FILTERED_STATES.z(131:260);         % z grid
        ggrid4    = FILTERED_STATES.g(131:260);         % g grid
        sgrid4    = FILTERED_STATES.SUN(131:260);       % s grid

    else
        error('Wrong configuration!')
    end

else
    filtered_states_use = 'None';
    num_filtered_states = 0;
end
