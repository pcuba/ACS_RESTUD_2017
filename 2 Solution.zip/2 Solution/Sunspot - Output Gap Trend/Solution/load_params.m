%==========================================================================
%                       REPLICATION FILE FOR
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% THIS FILE SETS PARAMETERS FOR SUNSPOT SOLUTION - OUTPUT GROWTH MODEL
%
% Updated with parameters estimaded on 08/06/2015
%
% Last Edited: August 6th, 2015.
%==========================================================================
global R_min R_max y_min y_max
global e_min e_max  d_min d_max z_min z_max g_min g_max
global rho0 rho1
global O par

% Store country indicator
O.ind_params = par.ind_params;

%==========================================================================
%                      ASSIGN MODEL PARAMETERS
%==========================================================================

% SUNSPOT PARAMETERS %
rho0 = par.rho0;
rho1 = par.rho1;

% MODEL PARAMETERS %
nu    = par.nu;
tau   = par.tau;
eta   = par.eta;
kappa = par.kappa;
chi_h = par.chi_h;
psi1  = par.psi1;
psi2  = par.psi2;
rho_R = par.rho_R;
rho_z = par.rho_z;
rho_g = par.rho_g;
rho_d = par.rho_d;
gstar = par.gstar;
sig_d = par.sig_d;
sig_z = par.sig_z;
sig_g = par.sig_g;
sig_r = par.sig_r;
alp   = par.alp;
piA   = par.piA;
rA    = par.rA;
gammaQ= par.gammaQ;

% TRANSFORMED PARAMETERS
pistar = 1 + (piA / 400);                      % Gross inflation
rr     = 1 + rA/400;                           % Gross real rate
gamma  = 1 + gammaQ/100;                       % Gross output growth rate

pibar  = pistar;                               % Inflation for adj cost
beta   = 1 / rr;                               % Discount rate
r      = rr * gamma;                           % Real interest rate
phi    = tau*(1-nu)/((nu * pistar^2 * kappa)); % Cost of adjusting prices
b      = 1/(2*nu);                             % Constant


%==========================================================================
%                   NON-STOCHASTIC STEADY STATE
%==========================================================================

%%% Targeted-Inflation steady state %%%
pi_ss  = pistar;
c_ss   = ( (1 - nu + phi*nu*(1-beta)*pi_ss*(pi_ss-pibar)-0.5*phi*(pi_ss-pibar)^2) / ...
         (chi_h*((1/gstar)-0.5*phi*(pi_ss-pibar)^2)^(-1/eta)) )^(1/(tau + 1/eta));
y_ss   = c_ss/(1/gstar - 0.5 * phi * (pi_ss -pibar)^2);
R_ss   = pi_ss * gamma/beta;
ee1_ss = (c_ss^-tau)/(gamma*pi_ss);

%%% Deflation steady  %%%
R_tilde   = 1;
pi_tilde  = beta / gamma;
c_tilde   = ( (1 - nu + phi*nu*(1-beta)*pi_tilde*(pi_tilde-pibar)-0.5*phi*(pi_tilde-pibar)^2) / ...
            (chi_h*((1/gstar)-0.5*phi*(pi_tilde-pibar)^2)^(-1/eta)) )^(1/(tau + 1/eta));
y_tilde   = c_tilde/(1/gstar - 0.5 * phi * (pi_tilde -pibar)^2);
ee1_tilde = (c_tilde^-tau)/(gamma*pi_tilde);



%==========================================================================
% MAP BOUNDARIES %
%==========================================================================

R_max = par.R_max;
R_min = par.R_min;
y_max = par.y_max;
y_min = par.y_min;
e_min = par.e_min;
e_max = par.e_max;
z_max = par.z_max;
z_min = par.z_min;
g_max = par.g_max;
g_min = par.g_min;
d_max = par.d_max;
d_min = par.d_min;

%==========================================================================
%               INITIAL CONDITIONS FOR SIMULATION
%==========================================================================

if sunspot_initial==1
    init_sun.Rlag = R_ss;
    init_sun.ylag = y_ss;               % Keep ylag for output growth
    init_sun.trendlag = y_ss;               % Keep ylag for output growth
    init_sun.clag = c_ss;               % Keep clag for consum growth
else
    init_sun.Rlag = R_tilde;
    init_sun.ylag = y_tilde;            % Keep ylag for output growth
    init_sun.trendlag = y_tilde;            % Keep ylag for output growth
    init_sun.clag = c_tilde;            % Keep clag for consum growth
end

init_sun.dlag = 0;
init_sun.zlag = 0;
init_sun.glag = log(gstar);
init_sun.Alag = 1;


