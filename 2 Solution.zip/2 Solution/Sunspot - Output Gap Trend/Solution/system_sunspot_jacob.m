% This function solves the system of equilibrium conditions of full model
% and solves for the SUNSPOT EQUILIBRIUM
%
% *************************************************************************
% *   ALGO 3: Output Gap Rule (M2), jacobian computed analytically        *
% *************************************************************************
% Inputs:
%           theta_in: (ncoefs*8)x1 vector of coefficients.
%           Rgrid_in:  Mx1 vector of grid points for R(-1).
%           ygrid_in:  Mx1 vector of grid points for trend(-1).
%           dgrid_in:  Mx1 vector of grid points for d.
%           ergrid_in: Mx1 vector of grid points for eR.
%           zgrid_in:  Mx1 vector of grid points for z.
%           ggrid_in:  Mx1 vector of grid points for g.
%           sgrid_in:  Mx1 vector of grid points for sunspot variable.
%           PSI: NcoefsxM matrix of basis functions evaluated at sol grid.
%           M:   Number of gridpoints.
%
% This code uses the sunspot variable on the grid. 
%
% This version: February 1, 2015
%==========================================================================

function [G, JACOB] = system_sunspot_jacob(theta_in, Rgrid_in, ygrid_in, dgrid_in, ergrid_in, zgrid_in, ggrid_in, sgrid_in, PSI,M)

global Q ncoefs par rho1 rho0
global WEIGHT
global ERPRIME ZPRIME GPRIME DPRIME
global index
%--------------------------------------------------------------------------
% MAP PARAMETERS
%--------------------------------------------------------------------------
beta = par.beta;  phi   = par.phi;   nu = par.nu; tau = par.tau; psi1 = par.psi1; 
psi2 = par.psi2;  chi_h = par.chi_h; eta = par.eta; pi_ss = par.pi_ss; 
pibar= par.pibar; gamma = par.gamma; r = par.r; rho_R = par.rho_R;
alp  = par.alp;
%--------------------------------------------------------------------------
%                               HOUSEKEEPING
%--------------------------------------------------------------------------

res1 = zeros(M,1);      
res2 = zeros(M,1);

% Integral 1 %
integrand_1_x_1 = zeros(Q,1);  % x --> 1
integrand_1_x_0 = zeros(Q,1);  % x --> 0

% Integral 2 %
integrand_2_x_1 = zeros(Q,1);  % x --> 1
integrand_2_x_0 = zeros(Q,1);  % x --> 0

% OBJECTS FOR JACOBIAN %

integrand_1_x_1_jacob = zeros(Q,8*ncoefs);
integrand_1_x_0_jacob = zeros(Q,8*ncoefs);

integrand_2_x_1_jacob = zeros(Q,8*ncoefs);
integrand_2_x_0_jacob = zeros(Q,8*ncoefs);

% MATRIX FOR JACOBIANS %

jacob_res1 = ones(M,8*ncoefs) * nan; 
jacob_res2 = ones(M,8*ncoefs) * nan; 

%--------------------------------------------------------------------------
% MAP COEF AND DECISION RULES
%--------------------------------------------------------------------------

theta_ee1_1_1 = theta_in(1:ncoefs,1);             % 1 state THETA / NON ZLB
theta_pi_1_1  = theta_in(ncoefs+1:2*ncoefs,1);
theta_ee1_1_2 = theta_in(2*ncoefs+1:3*ncoefs,1);  % 1 state THETA / ZLB
theta_pi_1_2  = theta_in(3*ncoefs+1:4*ncoefs,1);

theta_ee1_0_1 = theta_in(4*ncoefs+1:5*ncoefs,1);  % 0 state THETA / NON ZLB
theta_pi_0_1  = theta_in(5*ncoefs+1:6*ncoefs,1);
theta_ee1_0_2 = theta_in(6*ncoefs+1:7*ncoefs,1);  % 0 state THETA / ZLB
theta_pi_0_2  = theta_in(7*ncoefs+1:8*ncoefs,1);

EE1_1_1 = PSI'*theta_ee1_1_1;
PI_1_1  = PSI'*theta_pi_1_1;

EE1_1_2 = PSI'*theta_ee1_1_2;
PI_1_2  = PSI'*theta_pi_1_2;

EE1_0_1 = PSI'*theta_ee1_0_1;
PI_0_1  = PSI'*theta_pi_0_1;

EE1_0_2 = PSI'*theta_ee1_0_2;
PI_0_2  = PSI'*theta_pi_0_2;

%--------------------------------------------------------------------------
%                           DEFINE CONSTANTS 
%--------------------------------------------------------------------------
zeta = 1/(tau + alp*psi2*(1-rho_R)); % For Jacobian %
b    = 1/(2*nu);

%--------------------------------------------------------------------------
%                           MAIN LOOP
%--------------------------------------------------------------------------

for i = 1:M
    
    R_lag   = Rgrid_in(i,1);            % R(-1) from grid of R
    trend_lag = ygrid_in(i,1);          % trend(-1) from grid of ystar

    d      = dgrid_in(i,1);             % Preference Shock
    er     = ergrid_in(i,1);            % Monetary Shock
    g      = ggrid_in(i,1);             % Fiscal Shock
    z      = zgrid_in(i,1);             % Productivity shock   
    
    s      = sgrid_in(i,1);             % Sunspot
    
    %###### This is for the Jacobian WHEN S=1 ######%
    dee1_1_1_dtheta  =  [PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];
    dppi_1_1_dtheta  =  [0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];
    
    dee1_1_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];
    dppi_1_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];
    
    %###### This is for the Jacobian WHEN S=0 ######%
    dee1_0_1_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];
    dppi_0_1_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i)];
    
    dee1_0_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i)];
    dppi_0_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i)];
    %######################################%    
    
    if s == 1
        
        % === For s = 1 ===%
        
        % First non-ZLB decision rules        
        ee1 = EE1_1_1(i,1);
        ppi = PI_1_1(i,1);
               
        % Assume ZLB slack
        temp = ((r*pi_ss*((ppi/pi_ss)^psi1)*((exp(z)/trend_lag)^(alp*psi2)))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        y    = ( (beta*ee1*temp) / (((1/exp(g)) - 0.5*phi*(ppi - pibar)^2)^(-tau)) )^(-1/(tau + alp*psi2*(1-rho_R)));     % (61)
        trend = exp(alp*log(trend_lag) + (1-alp)*log(y) - alp*z);
        R    = ((r*pi_ss*((ppi/pi_ss)^psi1)*(((y/trend))^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        
        % Check ZLB        
        if R > 1
            c = (beta*R*ee1)^(-1/tau);
            ff = c^(-tau) * y *((1/nu) * (1 - chi_h*(c^tau)*(y^(1/eta))) + phi * (ppi - pibar) * ((1 - b)*ppi + pibar * b) - 1);
            
            % ### COMPUTE OBJECTS FOR DERIVATIVES S=1 #### %
            Gi = ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
            dG_dppi = -phi*(ppi-pibar);
            
            % Derivatives with respect to ee1 and ee1 when S=1%
            dy_dee1 = -(zeta*y/ee1);
            dR_dee1 = (-alp*psi2*(1-rho_R)*R*zeta/ee1);
            
            % Derivatives with respect to pi_1 and pi_2 when S=1%
            dy_dppi = -zeta*y*( (psi1*(1-rho_R)/ppi) + (tau/Gi)*dG_dppi );
            dR_dppi = R*((psi1*(1-rho_R)/ppi)+ (alp*psi2*(1-rho_R)/y)*dy_dppi);
            
            % These are the 8*ncoefsx1 vector with respect to theta_ee1 and theta_pi %
            dy_dtheta = [dy_dee1*dee1_1_1_dtheta(1:ncoefs,1);...
                dy_dppi*dppi_1_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dy_dee1*dee1_1_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dy_dppi*dppi_1_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dy_dee1*dee1_1_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dy_dppi*dppi_1_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dy_dee1*dee1_1_1_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dy_dppi*dppi_1_1_dtheta(7*ncoefs+1:8*ncoefs,1)];
            
            dR_dtheta = [dR_dee1*dee1_1_1_dtheta(1:ncoefs,1);...
                dR_dppi*dppi_1_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dR_dee1*dee1_1_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dR_dppi*dppi_1_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dR_dee1*dee1_1_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dR_dppi*dppi_1_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dR_dee1*dee1_1_1_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dR_dppi*dppi_1_1_dtheta(7*ncoefs+1:8*ncoefs,1)];
            
            % Objects for Jacobian in Residual 2 %
            m        = c^(-tau)*y;
            BigGamma = (1-b)*ppi^2 + (2*b-1)*pibar*ppi - b*(pibar^2);
            
            dm_dtheta          = m*(((1-tau)/y)*dy_dtheta - (tau/Gi)*dG_dppi*dppi_1_1_dtheta);
            dBigGamma_dtheta   = (2*(1-b)*ppi + (2*b-1)*pibar)*dppi_1_1_dtheta;
            dff_1_dtheta       = dm_dtheta *(2*b - 1 + phi*BigGamma)- 2*b*(chi_h*(1+(1/eta))*y^(1/eta))*dy_dtheta  + phi*m*dBigGamma_dtheta;
            % ############################################ %
        else
            R = 1;
            
            %fprintf('R=1 found at grid point %i, Rlag = %4.4f, s = %i \n', index(i),R_lag,s);
            
            ee1 = EE1_1_2(i,1);
            ppi = PI_1_2(i,1);
            
            c = (beta*R*ee1)^(-1/tau);
            y = c / ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
        trend = exp(alp*log(trend_lag) + (1-alp)*log(y) - alp*z);
            
            ff = c^(-tau) * y *((1/nu) * (1 - chi_h*(c^tau)*(y^(1/eta))) + phi * (ppi - pibar) * ((1 - b)*ppi + pibar * b) - 1);
            % ### COMPUTE OBJECTS FOR DERIVATIVES S=1 #### %
            Gi      = ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
            dG_dppi = -phi*(ppi-pibar);
            
            % Derivatives with respect to ee1_1 and ee1_2 %
            
            dy_dee1 = -(1/tau)*(y/ee1);
            dR_dee1 = 0;
            
            % Derivatives with respect to pi_1 and pi_2 %
            
            dy_dppi = -(y/Gi)*dG_dppi;
            dR_dppi = 0;
            
            % These are the 4*ncoefsx1 vector with respect to theta_ee1 and theta_pi %
            dy_dtheta = [dy_dee1*dee1_1_2_dtheta(1:ncoefs,1);...
                dy_dppi*dppi_1_2_dtheta(ncoefs+1:2*ncoefs,1);...
                dy_dee1*dee1_1_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dy_dppi*dppi_1_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dy_dee1*dee1_1_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dy_dppi*dppi_1_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dy_dee1*dee1_1_2_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dy_dppi*dppi_1_2_dtheta(7*ncoefs+1:8*ncoefs,1)];
            
            dR_dtheta = [dR_dee1*dee1_1_2_dtheta(1:ncoefs,1);...
                dR_dppi*dppi_1_2_dtheta(ncoefs+1:2*ncoefs,1);...
                dR_dee1*dee1_1_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dR_dppi*dppi_1_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dR_dee1*dee1_1_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dR_dppi*dppi_1_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dR_dee1*dee1_1_2_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dR_dppi*dppi_1_2_dtheta(7*ncoefs+1:8*ncoefs,1)];

            % Objects for Jacobian in Residual 2 %
            
            m        = c^(-tau)*y;
            BigGamma = (1-b)*ppi^2 + (2*b-1)*pibar*ppi - b*(pibar^2);
            
            dm_dtheta        = m*(((1-tau)/y)*dy_dtheta - (tau/Gi)*dG_dppi*dppi_1_2_dtheta);
            dBigGamma_dtheta = (2*(1-b)*ppi + (2*b-1)*pibar)*dppi_1_2_dtheta;
            dff_1_dtheta     =  dm_dtheta *(2*b - 1 + phi*BigGamma)- 2*b*(chi_h*(1+(1/eta))*y^(1/eta))*dy_dtheta  + phi*m*dBigGamma_dtheta;
            % ############################################ %
        end
        
    elseif s == 0
        
        % === For s = 0 ====%
        
        % First non-ZLB decision rules
        
        ee1 = EE1_0_1(i,1);
        ppi = PI_0_1(i,1);        
    
        % Assume ZLB slack S=0 %
        
        temp = ((r*pi_ss*((ppi/pi_ss)^psi1)*((exp(z)/trend_lag)^(alp*psi2)))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        y    = ( (beta*ee1*temp) / (((1/exp(g)) - 0.5*phi*(ppi - pibar)^2)^(-tau)) )^(-1/(tau + alp*psi2*(1-rho_R)));
       trend = exp(alp*log(trend_lag) + (1-alp)*log(y) - alp*z);
        R    = ((r*pi_ss*((ppi/pi_ss)^psi1)*(((y/trend))^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        
        % Check ZLB %
        
        if R > 1
            c  = (beta*R*ee1)^(-1/tau);
            ff = c^(-tau) * y *((1/nu) * (1 - chi_h*(c^tau)*(y^(1/eta))) + phi * (ppi - pibar) * ((1 - b)*ppi + pibar * b) - 1);
            
            % ### COMPUTE OBJECTS FOR DERIVATIVES S=0 #### %
            Gi = ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
            dG_dppi = -phi*(ppi-pibar);
            
            % Derivatives with respect to ee1_1 and ee1_2 when S=0%
            
            dy_dee1 = -(zeta*y/ee1);
            dR_dee1 = (-alp*psi2*(1-rho_R)*R*zeta/ee1);
          
            % Derivatives with respect to pi_1 and pi_2 when S=1%
            
            dy_dppi = -zeta*y*( (psi1*(1-rho_R)/ppi) + (tau/Gi)*dG_dppi );
            dR_dppi = R*((psi1*(1-rho_R)/ppi)+ (alp*psi2*(1-rho_R)/y)*dy_dppi);
            
            % These are the 2*ncoefsx1 vector with respect to theta_ee1 and theta_pi %
            
            dy_dtheta = [dy_dee1*dee1_0_1_dtheta(1:ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dy_dee1*dee1_0_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dy_dee1*dee1_0_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dy_dee1*dee1_0_1_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(7*ncoefs+1:8*ncoefs,1)];
            
            dR_dtheta = [dR_dee1*dee1_0_1_dtheta(1:ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dR_dee1*dee1_0_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dR_dee1*dee1_0_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dR_dee1*dee1_0_1_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(7*ncoefs+1:8*ncoefs,1)];
            
            % Objects for Jacobian in Residual 2 %
            m        = c^(-tau)*y;
            BigGamma = (1-b)*ppi^2 + (2*b-1)*pibar*ppi - b*(pibar^2);
            
            dm_dtheta          = m*(((1-tau)/y)*dy_dtheta - (tau/Gi)*dG_dppi*dppi_0_1_dtheta);
            dBigGamma_dtheta   = (2*(1-b)*ppi + (2*b-1)*pibar)*dppi_0_1_dtheta;
            dff_0_dtheta       = dm_dtheta *(2*b - 1 + phi*BigGamma)- 2*b*(chi_h*(1+(1/eta))*y^(1/eta))*dy_dtheta  + phi*m*dBigGamma_dtheta;
            % ############################################ %
        else
            R = 1;
            
            ee1 = EE1_0_2(i,1);
            ppi = PI_0_2(i,1);
            
            c  = (beta*R*ee1)^(-1/tau);
            y  = c / ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);            
           trend = exp(alp*log(trend_lag) + (1-alp)*log(y) - alp*z);
            ff = c^(-tau) * y *((1/nu) * (1 - chi_h*(c^tau)*(y^(1/eta))) + phi * (ppi - pibar) * ((1 - b)*ppi + pibar * b) - 1);
            
            % ### COMPUTE OBJECTS FOR DERIVATIVES S=0 #### %
            Gi      = ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
            dG_dppi = -phi*(ppi-pibar);
            
            % Derivatives with respect to ee1_1 and ee1_2 %
            
            dy_dee1 = -(1/tau)*(y/ee1);
            dR_dee1 = 0;
            
            % Derivatives with respect to pi_1 and pi_2 %
            
            dy_dppi = -(y/Gi)*dG_dppi;
            dR_dppi = 0;
            
            % These are the 4*ncoefsx1 vector with respect to theta_ee1 and theta_pi %
            
            dy_dtheta = [dy_dee1*dee1_0_2_dtheta(1:ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(ncoefs+1:2*ncoefs,1);...
                dy_dee1*dee1_0_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dy_dee1*dee1_0_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dy_dee1*dee1_0_2_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(7*ncoefs+1:8*ncoefs,1)];
            
            dR_dtheta = [dR_dee1*dee1_0_2_dtheta(1:ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(ncoefs+1:2*ncoefs,1);...
                dR_dee1*dee1_0_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dR_dee1*dee1_0_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dR_dee1*dee1_0_2_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(7*ncoefs+1:8*ncoefs,1)];
            
            % Objects for Jacobian in Residual 2 %            

            m        = c^(-tau)*y;
            BigGamma = (1-b)*ppi^2 + (2*b-1)*pibar*ppi - b*(pibar^2);
            
            dm_dtheta        = m*(((1-tau)/y)*dy_dtheta - (tau/Gi)*dG_dppi*dppi_0_2_dtheta);
            dBigGamma_dtheta = (2*(1-b)*ppi + (2*b-1)*pibar)*dppi_0_2_dtheta;
            dff_0_dtheta     =  dm_dtheta *(2*b - 1 + phi*BigGamma)- 2*b*(chi_h*(1+(1/eta))*y^(1/eta))*dy_dtheta  + phi*m*dBigGamma_dtheta;
            % ############################################ %
        end
    end
        
    %----------------------------------------------------------------------
    %                                   INTEGRALS
    %----------------------------------------------------------------------
    
    for q = 1:Q;
        
        % THIS ARE THE STOCHASTIC PROCESS OVER WHICH WE INTEGRATE %
        
        er_prime = ERPRIME(q,i);
        z_prime  = ZPRIME(q,i);
        g_prime  = GPRIME(q,i);
        d_prime  = DPRIME(q,i);
        
        % Build PSI_prime
        
        PSI_prime = basis_temp(R,trend,d_prime,er_prime,z_prime,g_prime); % basis for prime objects                
        
        % Approximate t+1 objects (start with unconstrained)
        % x -> 1
        ee1_prime_x_1 = PSI_prime'*theta_ee1_1_1;
        pi_prime_x_1  = PSI_prime'*theta_pi_1_1;

        % x -> 0
        ee1_prime_x_0 = PSI_prime'*theta_ee1_0_1;
        pi_prime_x_0  = PSI_prime'*theta_pi_0_1;
        
        % Get t+1 objects
        temp_prime_x_1 = ((r*pi_ss*((pi_prime_x_1/pi_ss)^psi1)*((exp(z_prime)/trend)^(alp*psi2)))^(1-rho_R))*((R)^rho_R)*exp(er_prime);
        temp_prime_x_0 = ((r*pi_ss*((pi_prime_x_0/pi_ss)^psi1)*((exp(z_prime)/trend)^(alp*psi2)))^(1-rho_R))*((R)^rho_R)*exp(er_prime);

        y_prime_x_1 = ( (beta*ee1_prime_x_1*temp_prime_x_1) / (((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_1 - pibar)^2)^(-tau)) )^(-1/(tau + alp*psi2*(1-rho_R)));
        y_prime_x_0 = ( (beta*ee1_prime_x_0*temp_prime_x_0) / (((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_0 - pibar)^2)^(-tau)) )^(-1/(tau + alp*psi2*(1-rho_R)));
     
        trend_prime_x_1 = exp(alp*log(trend) + (1-alp)*log(y_prime_x_1) - alp*z_prime);
        trend_prime_x_0 = exp(alp*log(trend) + (1-alp)*log(y_prime_x_0) - alp*z_prime);        
        
        R_prime_x_1  = ((r*pi_ss*((pi_prime_x_1/pi_ss)^psi1)*(((y_prime_x_1/trend_prime_x_1))^psi2))^(1-rho_R))*((R)^rho_R)*exp(er_prime);
        R_prime_x_0  = ((r*pi_ss*((pi_prime_x_0/pi_ss)^psi1)*(((y_prime_x_0/trend_prime_x_0))^psi2))^(1-rho_R))*((R)^rho_R)*exp(er_prime);
    
        G_prime_x_1  = ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_1 - pibar)^2);
        G_prime_x_0  = ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_0 - pibar)^2);
       
        %% x-->1
        
        if R_prime_x_1 > 1
            
            c_prime_x_1    = (beta*R_prime_x_1*ee1_prime_x_1)^(-1/tau);
          
            dGprime_dpiprime_x_1 = -phi*(pi_prime_x_1 - pibar);
            dtrend_dtheta = (1-alp)*(trend/y)*dy_dtheta;
            
            %######## THIS IS FOR THE JACOBIAN: DERIVATIVES OF E1q and PIq (EVALUATED NUMERICALLY) ##########%
            [dee1_dR_prime, dee1_dy_prime, dpi_dR_prime, dpi_dy_prime] = get_prime_derivatives(R,trend,d_prime,er_prime,z_prime,g_prime,ee1_prime_x_1, pi_prime_x_1, theta_ee1_1_1,theta_pi_1_1);
            
            dee1prime_dtheta_x_1 = [PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dtrend_dtheta;
            
            dpiprime_dtheta_x_1  = [0*PSI_prime(:,1);
                  PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dtrend_dtheta;
            
            %### COMPUTE DERIVARIVES FOR R_prime > 1 ###%
            
            
            dyprime_dtheta_x_1 = -y_prime_x_1*zeta * ...
                ( (psi1*(1-rho_R)/pi_prime_x_1)*dpiprime_dtheta_x_1 ...
                - (alp*psi2*(1-rho_R)/trend)*dtrend_dtheta ...
                + (rho_R/R)*dR_dtheta ...
                + (tau/G_prime_x_1)*dGprime_dpiprime_x_1*dpiprime_dtheta_x_1...
                + (1/ee1_prime_x_1)*dee1prime_dtheta_x_1 );
            
            dRprime_dtheta_x_1 = R_prime_x_1 * ...
                ((psi1*(1-rho_R)/pi_prime_x_1)*dpiprime_dtheta_x_1 ...
                + (alp*psi2*(1-rho_R)/y_prime_x_1)*dyprime_dtheta_x_1 ...
                - (alp*psi2*(1-rho_R)/trend)*dtrend_dtheta ...
                + (rho_R/R)*dR_dtheta);
            
            %############################################

        else

            
            %wfprintf('R_prime_x_1 = 1 found at grid point %i, R = %4.4f, s = %i \n', index(i),R,s);
            
            
            R_prime_x_1   = 1;
            ee1_prime_x_1 = PSI_prime'*theta_ee1_1_2;
            pi_prime_x_1  = PSI_prime'*theta_pi_1_2;
            c_prime_x_1   = (beta*R_prime_x_1*ee1_prime_x_1)^(-1/tau);
            y_prime_x_1   = c_prime_x_1 / ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_1 - pibar)^2);
            G_prime_x_1   = ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_1 - pibar)^2);
            
            dtrend_dtheta = (1-alp)*(trend/y)*dy_dtheta;
            
            %######## THIS IS FOR THE JACOBIAN: DERIVATIVES OF E1q and PIq (EVALUATED NUMERICALLY) ##########%
            [dee1_dR_prime, dee1_dy_prime, dpi_dR_prime, dpi_dy_prime] = get_prime_derivatives(R,trend,d_prime,er_prime,z_prime,g_prime,ee1_prime_x_1, pi_prime_x_1, theta_ee1_1_2,theta_pi_1_2);

            dee1prime_dtheta_x_1 = [0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                  PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dtrend_dtheta;
            

            dpiprime_dtheta_x_1  = [0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                  PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dtrend_dtheta;

            %### COMPUTE DERIVARIVES FOR R_prime = 1 ###%
            dGprime_dpiprime_x_1 = -phi*(pi_prime_x_1 - pibar);
            dyprime_dtheta_x_1   = -(y_prime_x_1/tau)*( (1/ee1_prime_x_1)*dee1prime_dtheta_x_1 + (tau/G_prime_x_1)*dGprime_dpiprime_x_1*dpiprime_dtheta_x_1);
            dRprime_dtheta_x_1   = zeros(8*ncoefs,1);
            %############################################
        end
        
        %% x-->0
        
        if R_prime_x_0 > 1
            
            c_prime_x_0 = (beta*R_prime_x_0*ee1_prime_x_0)^(-1/tau);
            
            dtrend_dtheta = (1-alp)*(trend/y)*dy_dtheta;
            
            %######## THIS IS FOR THE JACOBIAN: DERIVATIVES OF E1q and PIq (EVALUATED NUMERICALLY) ##########%
            [dee1_dR_prime, dee1_dy_prime, dpi_dR_prime, dpi_dy_prime] = get_prime_derivatives(R,trend,d_prime,er_prime,z_prime,g_prime,ee1_prime_x_0, pi_prime_x_0, theta_ee1_0_1,theta_pi_0_1);
            
            % NOTE THE VECTOR OF PSI_PRIME HAS TO BE FLIPPED TO GET THE
            % TRANSITION DERIVATIVES CORRECTLY
            
            dee1prime_dtheta_x_0 = [0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                  PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dtrend_dtheta;
            
            dpiprime_dtheta_x_0  = [0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                  PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dtrend_dtheta;
            
            %### COMPUTE DERIVARIVES FOR R_prime > 1 ###%
            dGprime_dpiprime_x_0 = -phi*(pi_prime_x_0 - pibar);
            dtrend_dtheta = ((1-alp)*trend/y)*dy_dtheta;
            
            dyprime_dtheta_x_0   = -y_prime_x_0 * zeta * ...
                ( (psi1*(1-rho_R)/pi_prime_x_0)*dpiprime_dtheta_x_0 ...
                - (alp*psi2*(1-rho_R)/trend)*dtrend_dtheta ...
                + (rho_R/R)*dR_dtheta ...
                + (tau/G_prime_x_0)*dGprime_dpiprime_x_0*dpiprime_dtheta_x_0 ...
                + (1/ee1_prime_x_0)*dee1prime_dtheta_x_0);
            
            dRprime_dtheta_x_0   = R_prime_x_0 * ...
                ((psi1*(1-rho_R)/pi_prime_x_0) * dpiprime_dtheta_x_0 ...
                + (alp*psi2*(1-rho_R)/y_prime_x_0) * dyprime_dtheta_x_0 ...
                - (alp*psi2*(1-rho_R)/trend)*dtrend_dtheta ...
                + (rho_R/R)*dR_dtheta);
            %############################################
            
        else
            
            %fprintf('R_prime_x_0 = 1 found at grid point %i, R = %4.4f, s = %i \n', i,R,s);

            R_prime_x_0   = 1;
            
            ee1_prime_x_0 = PSI_prime'*theta_ee1_0_2;
            pi_prime_x_0  = PSI_prime'*theta_pi_0_2;
            
            c_prime_x_0   = (beta*R_prime_x_0*ee1_prime_x_0)^(-1/tau);
            y_prime_x_0   = c_prime_x_0 / ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_0 - pibar)^2);
            G_prime_x_0   = ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_0 - pibar)^2);
            
            dtrend_dtheta = (1-alp)*(trend/y)*dy_dtheta;
            
            %######## THIS IS FOR THE JACOBIAN: DERIVATIVES OF E1q and PIq (EVALUATED NUMERICALLY) ##########%
            [dee1_dR_prime, dee1_dy_prime, dpi_dR_prime, dpi_dy_prime] = get_prime_derivatives(R,trend,d_prime,er_prime,z_prime,g_prime,ee1_prime_x_0, pi_prime_x_0, theta_ee1_0_2,theta_pi_0_2);
            
            dee1prime_dtheta_x_0 = [0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                  PSI_prime(:,1);
                0*PSI_prime(:,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dtrend_dtheta;

            dpiprime_dtheta_x_0  = [0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                0*PSI_prime(:,1);
                  PSI_prime(:,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dtrend_dtheta;
            %### COMPUTE DERIVARIVES FOR R_prime = 1 ###%
            dGprime_dpiprime_x_0 = -phi*(pi_prime_x_0 - pibar);
            dyprime_dtheta_x_0   = -(y_prime_x_0/tau)*( (1/ee1_prime_x_0)*dee1prime_dtheta_x_0 + (tau/G_prime_x_0)*dGprime_dpiprime_x_0*dpiprime_dtheta_x_0);
            dRprime_dtheta_x_0   = zeros(8*ncoefs,1);
            %############################################

        end     
        
        %------------------------------------------------------------------
        % Build Integrands
        %------------------------------------------------------------------
        
        integrand_1_x_1(q,:) =  (c_prime_x_1^-tau)*exp(d_prime - d)/(gamma*pi_prime_x_1*exp(z_prime));
        integrand_1_x_0(q,:) =  (c_prime_x_0^-tau)*exp(d_prime - d)/(gamma*pi_prime_x_0*exp(z_prime));
    
        integrand_2_x_1(q,:) =  ((c_prime_x_1)^-tau)*exp(d_prime - d)*(y_prime_x_1)*(pi_prime_x_1 - pibar)*pi_prime_x_1;
        integrand_2_x_0(q,:) =  ((c_prime_x_0)^-tau)*exp(d_prime - d)*(y_prime_x_0)*(pi_prime_x_0 - pibar)*pi_prime_x_0;
      
        %****************************
        % THIS IS FOR THE JACOBIAN
        %****************************
        
        % JACOBIAN INTEGRAND FOR RESIDUAL 1 %
        integrand_1_x_1_jacob(q,:)= (beta/(gamma*exp(z_prime)))*exp(d_prime - d)*((dRprime_dtheta_x_1*ee1_prime_x_1  ...
            + dee1prime_dtheta_x_1*R_prime_x_1)*pi_prime_x_1  - dpiprime_dtheta_x_1*(R_prime_x_1*ee1_prime_x_1)) /(pi_prime_x_1^2);
        
        integrand_1_x_0_jacob(q,:)= (beta/(gamma*exp(z_prime)))*exp(d_prime - d)*((dRprime_dtheta_x_0*ee1_prime_x_0  ...
            + dee1prime_dtheta_x_0*R_prime_x_0)*pi_prime_x_0  - dpiprime_dtheta_x_0*(R_prime_x_0*ee1_prime_x_0)) /(pi_prime_x_0^2);
  
        % JACOBIAN INTEGRAND FOR RESIDUAL 2 %
        Omega_q_x_1 = (y_prime_x_1^(1-tau))*(G_prime_x_1^-tau)*(pi_prime_x_1 - pibar)*pi_prime_x_1*exp(d_prime - d);
        Omega_q_x_0 = (y_prime_x_0^(1-tau))*(G_prime_x_0^-tau)*(pi_prime_x_0 - pibar)*pi_prime_x_0*exp(d_prime - d);
      
        integrand_2_x_1_jacob(q,:)= Omega_q_x_1*( ((1-tau)/y_prime_x_1)*dyprime_dtheta_x_1 - (tau/G_prime_x_1)*dGprime_dpiprime_x_1*dpiprime_dtheta_x_1 ...
            + ((2*pi_prime_x_1 - pibar)/((pi_prime_x_1 - pibar)*pi_prime_x_1))*dpiprime_dtheta_x_1 );
        
        integrand_2_x_0_jacob(q,:)= Omega_q_x_0*( ((1-tau)/y_prime_x_0)*dyprime_dtheta_x_0 - (tau/G_prime_x_0)*dGprime_dpiprime_x_0*dpiprime_dtheta_x_0 ...
            + ((2*pi_prime_x_0 - pibar)/((pi_prime_x_0 - pibar)*pi_prime_x_0))*dpiprime_dtheta_x_0 );

% Check for NaN inside integral:        
        if ~isreal(integrand_1_x_1(q,:)) || ~isreal(integrand_1_x_0) || ~isreal(integrand_2_x_1) || ~isreal(integrand_2_x_0)
            keyboard;
        end
    end
    
    sol_int1_x_1 = integrand_1_x_1' * WEIGHT;
    sol_int1_x_0 = integrand_1_x_0' * WEIGHT;

    sol_int2_x_1 = integrand_2_x_1' * WEIGHT;
    sol_int2_x_0 = integrand_2_x_0' * WEIGHT;
  
    %### Solve Integral for Jacobian ###%
    
    sol_int1_jacob_x_1 =  integrand_1_x_1_jacob'*WEIGHT;
    sol_int1_jacob_x_0 =  integrand_1_x_0_jacob'*WEIGHT;
 
    sol_int2_jacob_x_1 =  integrand_2_x_1_jacob'*WEIGHT;
    sol_int2_jacob_x_0 =  integrand_2_x_0_jacob'*WEIGHT;
   
    
    %------------------------------------------------------------------
    %         Compute residuals for each gridpoint i=1,...,M
    %------------------------------------------------------------------
    if s == 1
        
        res1(i,:) = ee1 - rho1*sol_int1_x_1 - (1-rho1)*sol_int1_x_0;
        res2(i,:) = ff  - rho1*phi*beta*sol_int2_x_1 - (1-rho1)*phi*beta*sol_int2_x_0;
                
        if R > 1            
        
        %### Create Jacobian Matrices S=1 ###%
        
        jacob_res1(i,:) =  dee1_1_1_dtheta - rho1*sol_int1_jacob_x_1 - (1-rho1)*sol_int1_jacob_x_0;
        jacob_res2(i,:) =  dff_1_dtheta  - rho1*phi*beta*sol_int2_jacob_x_1 - (1-rho1)*phi*beta*sol_int2_jacob_x_0;
                
        else
                   
        jacob_res1(i,:) = dee1_1_2_dtheta - rho1*sol_int1_jacob_x_1 - (1-rho1)*sol_int1_jacob_x_0;
        jacob_res2(i,:) = dff_1_dtheta    - rho1*phi*beta*sol_int2_jacob_x_1 - (1-rho1)*phi*beta*sol_int2_jacob_x_0;  
              
        end
        
    elseif s == 0
    
        if R > 1
            
            res1(i,:) = ee1 - rho0*sol_int1_x_0 - (1-rho0)*sol_int1_x_1;
            res2(i,:) = ff  - rho0*phi*beta*sol_int2_x_0 - (1-rho0)*phi*beta*sol_int2_x_1;
            
            %### Create Jacobian Matrices S=0 ###%
            
            jacob_res1(i,:) = dee1_0_1_dtheta - rho0*sol_int1_jacob_x_0 - (1-rho0)*sol_int1_jacob_x_1;
            jacob_res2(i,:) = dff_0_dtheta    - rho0*phi*beta*sol_int2_jacob_x_0 - (1-rho0)*phi*beta*sol_int2_jacob_x_1;
            
        else
            res1(i,:) = ee1 - rho0*sol_int1_x_0 - (1-rho0)*sol_int1_x_1;
            res2(i,:) = ff  - rho0*phi*beta*sol_int2_x_0 - (1-rho0)*phi*beta*sol_int2_x_1;
            
            %### Create Jacobian Matrices S=0 ###%
            
            jacob_res1(i,:) = dee1_0_2_dtheta - rho0*sol_int1_jacob_x_0 - (1-rho0)*sol_int1_jacob_x_1;
            jacob_res2(i,:) = dff_0_dtheta    - rho0*phi*beta*sol_int2_jacob_x_0 - (1-rho0)*phi*beta*sol_int2_jacob_x_1;
                
        end
        
    end

end

if ~isreal(res1) || ~isreal(res2)
    keyboard;
end

% STORE RESIDUALS
G = [res1;res2];


% STORE JACOBIAN
JACOB = [jacob_res1;jacob_res2];

%
% if sum(isnan(G))> 0 || sum(sum(isnan(JACOB),2))
%     keyboard;
% end