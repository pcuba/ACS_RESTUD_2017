%==========================================================================
%                       REPLICATION FILE FOR
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% THIS CODE SOLVES THE SUNSPOT EQUILIBRIUM  - OUTPUT TREND GAP MODEL - ORDER 4
%
% Stored models are:
%                     US_3vGap             JP_3vGap
%                     US_4vGap_C           JP_4vGap_C
%                     US_4vGap_G           JP_4vGap_G
% 
%==========================================================================

clear all; close all; clc; delete *.asv *.~m

% ADD IMPORTANT PATHS
addpath ../Matfiles/            % Directory with mat files (Filtered States)
addpath ../Common/              % Directory with common functions

% GLOBAL VARIABLES
global O Q order ncoefs 
global ER_prime EZ_prime EG_prime ED_prime WEIGHT
global ERPRIME ZPRIME GPRIME DPRIME
global Rbar seedname

%==========================================================================
%                      USER OPTIONS
%==========================================================================

order         = 4;                   % Order of polynomial approximation. Keep at 4
O.ind_impose  = 1;                   % [0] No ZLB / [1] ZLB. Keep at 1
O.ind_grid    = 1;                   % [0] Just ergodic distribution / [1] Ergodic and Filtered States

O.ind_fresh_shocks = 0;              % [1] Draw new shocks / [0] use stored shocks
O.integration_rule = 'M1';           % Integration Rule GH = Gauss-Hermite quadrature, M1 = Monomial 1


Npoints = 200;                       % Points to evaluate the model Euler Errors
Q1      = 5;                         % Order of Quadrature Integration
Q2      = 5;                         % Quadrature points for evaluation
Niter   = 5;                         % Number of Iterations >  1
Tsim    = 10000;                     % Number of periods for simulating ergodic distribution
Tdrop   = 150;                       % Number of initial simulations that will be dropped
TolFun_use  = 1E-12;                 % Set TolFun for minimizer
TolX_use    = 1E-5;                  % Set TolX for minimizer
MaxIter_use = 1000;                  % Set Maximum number of Iterations for solver

Rbar = 1;                            % ZLB cutoff
sunspot_initial = 1;                 % [1] s=1 / [0] s=0
seedname  = 'mrg32k3a';              % String to generate RandomNumber Streams

options_use_jacob = optimset('display','iter','MaxFunEvals',100000,...
                             'MaxIter',MaxIter_use,'TolFun',TolFun_use,...
                             'TolX',TolX_use,'FunValCheck','On',...
                             'Jacobian','On','DerivativeCheck','Off');


%**************************************************************************
%********** END OF USER'S OPTIONS *****************************************
%**************************************************************************

model_number = input(' Sunspot Model to Solve: ','s');

if Niter < 1
    error('\n **** Need to iterate solution at least once!. Set Niter >=1 \n');
end


%==========================================================================
%                   SET PARAMETER VALUES
%==========================================================================


% LOAD PARAMETERS OF DESIRED MODEL
fprintf('\n **** Loading Parameters .... \n')
fprintf('\n **** Model = %s \n', model_number);
load(['SOLUTION_SUNSPOT_' model_number],'par')

% LOAD PARAMETERS
load_params;

% SET NUMBER OF POINTS FOR ORDER 4 SOLUTION. 
M = par.M;                            

% LOAD STORED SOLUTION
THETA_SAVED = load(['SOLUTION_SUNSPOT_' model_number '.mat']);

% LOAD INITIAL MODEL
init_model = par.init_model;

size_initial = length(THETA_SAVED.THETA.r5) / 8;

theta_old = reshape([reshape(THETA_SAVED.THETA.r0,size_initial,8);zeros(ncoefs - size_initial,8)], ncoefs*8,1);

clear THETA


%==========================================================================
%                           HOUSEKEEPING
%==========================================================================

% SET NUMBER OF COEFFICIENTS FOR 4TH ORDER SOLUTION
ncoefs = 210;


% KEEP A COPY OF INITIAL GUESS
theta_0_keep = theta_old;

% DRAW EXOGENOUS SHOCKS (STRUCTURAL + SUNSPOT INNOVATIONS)
if O.ind_fresh_shocks==0

    load SHOCKSMAT.mat

    shocks.er = shocks.er*par.sig_r;
    shocks.ez = shocks.ez*par.sig_z;
    shocks.eg = shocks.eg*par.sig_g;
    shocks.ed = shocks.ed*par.sig_d;

elseif O.ind_fresh_shocks==1

    [s_er, s_ez, s_eg, s_ed] = RandStream.create(seedname,'NumStreams',4);

    shocks.er = sig_r*randn(s_er, Tsim+Tdrop, 1);
    shocks.ez = sig_z*randn(s_ez, Tsim+Tdrop, 1);
    shocks.eg = sig_g*randn(s_eg, Tsim+Tdrop, 1);
    shocks.ed = sig_d*randn(s_ed, Tsim+Tdrop, 1);
end


% CONSTRUCT INTEGRATION NODES AND WEIGHTS
if strcmp(O.integration_rule,'GH')
    [ER_prime, EZ_prime, EG_prime, ED_prime, WEIGHT] = get_GH_nodes(Q1);
    Q = Q1^4;
    IntRule = strcat(O.integration_rule,num2str(Q1));
elseif strcmp(O.integration_rule,'M1')
    N = 4;
    [ER_prime, EZ_prime, EG_prime, ED_prime, WEIGHT, Q] = get_Monomial_nodes('M1',N);
    IntRule = O.integration_rule;
end

% DRAW SUNSPOT SHOCKS
SUNSPOT = get_sunspot(Tsim,sunspot_initial,Tdrop, 1);

% LOAD FILTERED PARTICLES AND CREATE SOLUTION GRID
script_load_solution_grid;


%==========================================================================
%                           MODEL SOLUTION
%==========================================================================

% INITIALIZE COUNTERS
label     = cell(Niter,1);
THETA.r0  = theta_old;
time_keep = 0;
ssr_old   = 10e6;

for iter_count=1:Niter

%==========================================================================
%                       SIMULATE ERGODIC SET
%==========================================================================

    label(iter_count) = {strcat('r',num2str(iter_count))};

    simuse = simulate_sunspot(theta_old,shocks,init_sun,Tsim,Tdrop,SUNSPOT);

%==========================================================================
%                       CONSTRUCT SOLUTION GRID
%==========================================================================

    if O.ind_grid == 0  % Just the ergodic distribution

        fprintf('\n Creating TSGA grid - Order %i - Iteration %i. Wait... \n',order,iter_count)

        [GRID0.(label{iter_count}), GRID1.(label{iter_count})] = get_ergodic_grid(simuse,M);

        Rlaggrid1 = GRID1.(label{iter_count})(:,1);     % R_lag grid
        tlaggrid1 = GRID1.(label{iter_count})(:,2);     % trend_lag grid
        dgrid1    = GRID1.(label{iter_count})(:,3);     % d grid
        ergrid1   = GRID1.(label{iter_count})(:,4);     % e_R grid
        zgrid1    = GRID1.(label{iter_count})(:,5);     % z grid
        ggrid1    = GRID1.(label{iter_count})(:,6);     % g grid
        sgrid1    = GRID1.(label{iter_count})(:,7);     % s grid

        Rlaggrid0 = GRID0.(label{iter_count})(:,1);     % R_lag grid
        tlaggrid0 = GRID0.(label{iter_count})(:,2);     % trend_lag grid
        dgrid0    = GRID0.(label{iter_count})(:,3);     % d grid
        ergrid0   = GRID0.(label{iter_count})(:,4);     % e_R grid
        zgrid0    = GRID0.(label{iter_count})(:,5);     % z grid
        ggrid0    = GRID0.(label{iter_count})(:,6);     % g grid
        sgrid0    = GRID0.(label{iter_count})(:,7);     % s grid

        Rlaggrid  = [Rlaggrid1;Rlaggrid0];
        tlaggrid  = [tlaggrid1;tlaggrid0];
        dgrid     = [dgrid1;dgrid0];
        ergrid    = [ergrid1;ergrid0];
        zgrid     = [zgrid1;zgrid0];
        ggrid     = [ggrid1;ggrid0];
        sgrid     = [sgrid1;sgrid0];

    elseif O.ind_grid == 1  % Combine the ergodic distribution with the filtered states

        fprintf('\n Creating TSGA grid augmented with Filtered States - Order %i - Iteration %i.\n',order,iter_count)
        [GRID0.(label{iter_count}), GRID1.(label{iter_count})] = get_ergodic_grid(simuse,M - num_filtered_states);

        Rlaggrid0 = GRID0.(label{iter_count})(:,1);     % R_lag grid
        tlaggrid0 = GRID0.(label{iter_count})(:,2);     % trend_lag grid
        dgrid0    = GRID0.(label{iter_count})(:,3);     % d grid
        ergrid0   = GRID0.(label{iter_count})(:,4);     % e_R grid
        zgrid0    = GRID0.(label{iter_count})(:,5);     % z grid
        ggrid0    = GRID0.(label{iter_count})(:,6);     % g grid
        sgrid0    = GRID0.(label{iter_count})(:,7);     % s grid

        Rlaggrid1 = GRID1.(label{iter_count})(:,1);     % R_lag grid
        tlaggrid1 = GRID1.(label{iter_count})(:,2);     % trend_lag grid
        dgrid1    = GRID1.(label{iter_count})(:,3);     % d grid
        ergrid1   = GRID1.(label{iter_count})(:,4);     % e_R grid
        zgrid1    = GRID1.(label{iter_count})(:,5);     % z grid
        ggrid1    = GRID1.(label{iter_count})(:,6);     % g grid
        sgrid1    = GRID1.(label{iter_count})(:,7);     % s grid

        % COMBINE GRIDS
        Rlaggrid  = [Rlaggrid1;Rlaggrid0;Rlaggrid2;Rlaggrid3;Rlaggrid4];
        tlaggrid  = [tlaggrid1;tlaggrid0;tlaggrid2;tlaggrid3;tlaggrid4];
        dgrid     = [dgrid1;dgrid0;dgrid2;dgrid3;dgrid4];
        ergrid    = [ergrid1;ergrid0;ergrid2;ergrid3;ergrid4];
        zgrid     = [zgrid1;zgrid0;zgrid2;zgrid3;zgrid4];
        ggrid     = [ggrid1;ggrid0;ggrid2;ggrid3;ggrid4];
        sgrid     = [sgrid1;sgrid0;sgrid2;sgrid3;sgrid4];

    end

%==========================================================================
%       TABULATE THE EXOGENOUS PROCESS ERPRIME, ZPRIME, GPRIME, DPRIME
%         (THIS USES THE CURRENT GRID OBTAINED FROM SIMULATION)
%==========================================================================

    % Clean up the matrices
    ERPRIME = NaN(Q,M);
    ZPRIME  = NaN(Q,M);
    GPRIME  = NaN(Q,M);
    DPRIME  = NaN(Q,M);

    for i=1:M;
        for q=1:Q
            ERPRIME(q,i)   = ER_prime(q);
            ZPRIME(q,i)    = rho_z*zgrid(i) + EZ_prime(q);
            GPRIME(q,i)    = (1-rho_g)*log(gstar) + rho_g*ggrid(i) + EG_prime(q);
            DPRIME(q,i)    = rho_d*dgrid(i) + ED_prime(q);
        end
    end

%==========================================================================
%  COMPUTE OBJECTS RELATED TO GRID
%==========================================================================

    % COLLECT GRID OBJECTS
    GRID = [Rlaggrid tlaggrid dgrid ergrid zgrid ggrid sgrid];
    EXO  = [ER_prime EZ_prime EG_prime ED_prime];

    % BASIS FUNCTION
    PSI  = basis_temp(Rlaggrid, tlaggrid, dgrid, ergrid, zgrid, ggrid);

%==========================================================================
%                         THIS IS THE SOLUTION BLOCK
%==========================================================================

    fprintf('\n Solving Sunspot Model -  Order %i - Iteration %i \n',order, iter_count);

    ssr_temp = norm(system_sunspot_jacob(theta_old, Rlaggrid,tlaggrid,dgrid,ergrid,zgrid,ggrid,sgrid,PSI, M))^2;

    if abs(ssr_temp - ssr_old) > TolFun_use

        fprintf('\n *** Solving with Analytical Derivatives - Order %i - Iteration %i \n',order, iter_count);

        tic
        [theta_use,resnorm,res_use,exitflag,output,lambda,jacobian] = lsqnonlin(@(theta_in) system_sunspot_jacob(theta_in,Rlaggrid,tlaggrid,dgrid,ergrid,zgrid,ggrid,sgrid,PSI,M), theta_old,[],[],options_use_jacob);
        time = toc;

        jacob = full(jacobian);

    else
        fprintf('\n **** The simulate/solve procedure seems to have converged, skipping this step *** \n');
        theta_use = theta_old;
    end

    ssr_old = norm(system_sunspot_jacob(theta_use, Rlaggrid,tlaggrid,dgrid,ergrid,zgrid,ggrid,sgrid,PSI, M))^2;

    fprintf('\n **** Done solving - Order %i - Iteration %i.\n', order, iter_count);

    % COLLECT SOLUTION OBJECTS
    THETA.(label{iter_count}) = theta_use;
    RESID.(label{iter_count}) = res_use;
    TIME.(label{iter_count})  = time;
    SIM.(label{iter_count})   = simulate_sunspot(theta_use,shocks,init_sun,Tsim,Tdrop,SUNSPOT);
    JACOB.(label{iter_count}) = jacob;

    % ANNUALIZE SIMULATED DATA
    infl = (SIM.(label{iter_count}).pi-1)*400;
    R    = (SIM.(label{iter_count}).R-1)*400;
    sun  = SIM.(label{iter_count}).SUN;

    disp('Display inflation check');
    fprintf('S = 0, mean(pi) = , %4.4f \n', mean(infl(sun==0)));
    fprintf('S = 1, mean(pi) = , %4.4f \n', mean(infl(sun==1)));

    % STORE SOLUTION AND PREPARE FOR NEXT ITERATION
    theta_old = theta_use;
    time_keep = time_keep + time;
    fprintf('\n Done with Iteration = %i \n', iter_count);


end
%%

%==========================================================================
%                       COMPUTE EULER ERRORS
%==========================================================================
fprintf('\n Over the Ergodic Distribution')

simeval(:,1) = SIM.(label{iter_count}).R(1:Tsim-1,1);     % R_lag;
simeval(:,2) = SIM.(label{iter_count}).trend(1:Tsim-1,1); % trend_lag;
simeval(:,3) = SIM.(label{iter_count}).d(2:Tsim,1);       % d
simeval(:,4) = SIM.(label{iter_count}).er(2:Tsim,1);      % er
simeval(:,5) = SIM.(label{iter_count}).z(2:Tsim,1);       % z
simeval(:,6) = SIM.(label{iter_count}).g(2:Tsim,1);       % g
simeval(:,7) = SIM.(label{iter_count}).SUN(2:Tsim,1);     % s

[ERGODICTEMP, EVAL, CINDEXTEMP] = tsga_grid(simeval,Npoints);

[ERROR1, ERROR2, OUT ] = euler_error(theta_use, EVAL, Q2);

fprintf('\n Over the Solution Grid')

[ERROR1_SOL, ERROR2_SOL, OUT_SOL] = euler_error(theta_use, GRID, Q2);

%==========================================================================
%               ADD ADITIONAL INFORMATION TO PAR STRUCTURE
%==========================================================================

par.EE1     = ERROR1;
par.EE2     = ERROR2;
par.EE1_sol = ERROR1_SOL;
par.EE2_sol = ERROR2_SOL;
par.time    = time_keep;
par.ssr     = ssr_old;

fprintf('\n Total time with 1 Node = %4.4f minutes \n',time_keep/60);
