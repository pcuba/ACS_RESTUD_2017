%==========================================================================
% Function to compute derivatives inside integral 
%
% This version for trend gap in policy rule.
% 
% Written by: Pablo Cuba-Borda. University of Maryland.
% Updated: 01/25/2015.
%==========================================================================
function [dee1_dR_prime, dee1_dtrend_prime, dpi_dR_prime, dpi_dtrend_prime] = get_prime_derivatives(R,trend,d_prime,er_prime,z_prime,g_prime,ee1_prime,pi_prime,theta_ee1_in,theta_pi_in)

            h = 1E-7;       % step for derivative %
            PSI_prime_eps_R = basis_temp(R+h,trend,d_prime,er_prime,z_prime,g_prime);
            PSI_prime_eps_trend = basis_temp(R,trend+h,d_prime,er_prime,z_prime,g_prime);
            
            ee1_prime_eps_R = PSI_prime_eps_R'*theta_ee1_in;
            ee1_prime_eps_trend = PSI_prime_eps_trend'*theta_ee1_in;
            
            pi_prime_eps_R  = PSI_prime_eps_R'*theta_pi_in;
            pi_prime_eps_trend  = PSI_prime_eps_trend'*theta_pi_in;
            
            dee1_dR_prime   = ((ee1_prime_eps_R - ee1_prime)/h);
            dee1_dtrend_prime   = ((ee1_prime_eps_trend - ee1_prime)/h);
            
            dpi_dR_prime    = ((pi_prime_eps_R - pi_prime)/h);
            dpi_dtrend_prime    = ((pi_prime_eps_trend - pi_prime)/h);

end