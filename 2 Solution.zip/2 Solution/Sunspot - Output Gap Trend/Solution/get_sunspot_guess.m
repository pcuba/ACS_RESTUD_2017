% Function to construct initial guess for Sunspot solution
%
% LOADS FROM A PREVIOUSLY STORED SUNSPOT SOLUTION
%
% Created: April 18, 2014
%--------------------------------------------------------------------------

function theta_old = get_sunspot_guess(model_number)

global ncoefs

    
    %*********** THIS LOADS FROM A SUNSPOT SOLUTION  ***********
  
        fprintf('\n **** Loading THETA_SUNSPOT_%s  as an initial guess *** \n',model_number);
        
        load(strcat(pwd,'/SAVEDRESULTS/SOLUTION_SUNSPOT_',model_number,'.mat'),'THETA');
        
        size_initial = length(THETA.r5) / 8;
        
        theta_old = reshape([reshape(THETA.r5,size_initial,8);zeros(ncoefs - size_initial,8)], ncoefs*8,1);
        
        clear THETA   

end
