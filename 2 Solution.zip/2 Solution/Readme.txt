%==========================================================================
%                           README FILE FOR:
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
%
% This version: March 15, 2017
%==========================================================================

1. FOLDER STRUCTURE: This folder has three subdirectories:

Sunspot - Output Gap Trend/
Sunspot - Output Growth/
Solutions for Filter/

i) Select the subdirectory containing the desired sunspot model specification.

ii) The Solution for Filter/ subdirectory collects the inputs passed to the
filtering routines. See Filtering/Readme.txt for details on the nonlinear filter.

2. MAIN SCRIPT: The main code is Solution/script_solve.m.

 i) Running this scripts will prompt to select a model to load stored parameters
 from the folder Matfiles/ subdirectory. The available models are:

  /Sunspot - Output Growth/
  -------------------------------------------
          US                      JP
  -------------------------------------------
  i.   US_3vGrowth          JP_3vGrowth
  ii.  US_4vGrowth_C        JP_4vGrowth_C
  iii. US_4vGrowth_G        JP_4vGrowth_G

  /Sunspot - Output Gap Trend/
  -------------------------------------------
          US                      JP
  -------------------------------------------
  i.   US_3vGap             JP_3vGap
  ii.  US_4vGap_C           JP_4vGap_C
  iii. US_4vGap_G           JP_4vGap_G


ii) Auxiliary files for the solution procedure are stores in /Common/
in each subdirectory.

iii) The filtered states and particles to construct the grid used in each model
are stored in the the Matfiles/ subdirectory following the same naming
convention.

3. MEX FILES: for the Output Growth specification we provide sample MEX code to
speed up the computation. We used Intel Visual Fortran Composer XE 2013
with Microsoft Visual Studio 2012 and the code is written in Fortran F90.

To configure the MEX environment in Matlab's command line execute the following:
mex -setup FORTRAN
mex system_sunspot_jacob_mex.F90

In Sunspot - Output Growth/Solution/script_solve.m uncomment lines 389,402,417

4. SIMULATION CODE: simulate_sunspot.m and simulate_sunspot_infexp.m in Commom/
are used to produce simulations for the respective models. In the paper we only
computed inflation expectations decision rules for the 3vGrowth model, results
are stored as US_3vGrowth_INFEXP and JP_3vGrowth_INFEXP in Matfiles/.

For details on how to produce simulation from the sunspot model see the sample
code in Analysis/FiguresforRestud/Figure 5/.
