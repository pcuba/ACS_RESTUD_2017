% This function solves the system of equilibrium conditions of full model
% and solves for the SUNSPOT EQUILIBRIUM
%
% *************************************************************************
% *   Output Growth Rule, jacobian computed analytically        *
% *************************************************************************
% Inputs:
%           theta_in: (ncoefs*8)x1 vector of coefficients.
%           Rgrid_in:  Mx1 vector of grid points for R(-1).
%           dgrid_in:  Mx1 vector of grid points for d.
%           ergrid_in: Mx1 vector of grid points for eR.
%           zgrid_in:  Mx1 vector of grid points for z.
%           ggrid_in:  Mx1 vector of grid points for g.
%           sgrid_in:  Mx1 vector of grid points for sunspot variable.
%           PSI: NcoefsxM matrix of basis functions evaluated at sol grid.
%           M:   Number of gridpoints.
%
% This code uses the sunspot variable on the grid.
%
% This version: February 1, 2015
%==========================================================================

function [G, JACOB] = system_sunspot_jacob(theta_in, Rgrid_in, ygrid_in, dgrid_in, ergrid_in, zgrid_in, ggrid_in, sgrid_in, PSI,M)

global Q ncoefs ncoefs_trunc par rho1 rho0
global WEIGHT
global ERPRIME ZPRIME GPRIME DPRIME
global O
global R_min R_max y_min y_max d_min d_max e_min e_max z_min z_max g_min g_max

%--------------------------------------------------------------------------
% MAP PARAMETERS
%--------------------------------------------------------------------------
beta = par.beta; phi = par.phi; nu = par.nu; tau = par.tau; psi1 = par.psi1;
psi2 = par.psi2; chi_h = par.chi_h; eta = par.eta; pi_ss = par.pi_ss;
pibar = par.pibar; gamma = par.gamma; r = par.r; rho_R = par.rho_R;

%--------------------------------------------------------------------------
%                               HOUSEKEEPING
%--------------------------------------------------------------------------

res1 = zeros(M,1);
res2 = zeros(M,1);

% Integral 1 %
integrand_1_x_1 = zeros(Q,1);  % x --> 1
integrand_1_x_0 = zeros(Q,1);  % x --> 0

% Integral 2 %
integrand_2_x_1 = zeros(Q,1);  % x --> 1
integrand_2_x_0 = zeros(Q,1);  % x --> 0


%--------------------------------------------------------------------------
% MAP COEF AND DECISION RULES
%--------------------------------------------------------------------------

theta_ee1_1_1 = theta_in(1:ncoefs,1);             % 1 state THETA / NON ZLB
theta_pi_1_1  = theta_in(ncoefs+1:2*ncoefs,1);
theta_ee1_1_2 = theta_in(2*ncoefs+1:3*ncoefs,1);  % 1 state THETA / ZLB
theta_pi_1_2  = theta_in(3*ncoefs+1:4*ncoefs,1);
theta_ee1_0_1 = theta_in(4*ncoefs+1:5*ncoefs,1);  % 0 state THETA / NON ZLB
theta_pi_0_1  = theta_in(5*ncoefs+1:6*ncoefs,1);

if O.ind_truncate_tilde==0

    theta_ee1_0_2 = theta_in(6*ncoefs+1:7*ncoefs,1);  % 0 state THETA / ZLB
    theta_pi_0_2  = theta_in(7*ncoefs+1:8*ncoefs,1);


    % OBJECTS FOR JACOBIAN %

    integrand_1_x_1_jacob = zeros(Q,8*ncoefs);
    integrand_1_x_0_jacob = zeros(Q,8*ncoefs);

    integrand_2_x_1_jacob = zeros(Q,8*ncoefs);
    integrand_2_x_0_jacob = zeros(Q,8*ncoefs);

    % MATRIX FOR JACOBIANS %

    jacob_res1 = ones(M,8*ncoefs) * nan;
    jacob_res2 = ones(M,8*ncoefs) * nan;

else
    % Initialize for size of vectors
    theta_ee1_0_2 = zeros(ncoefs,1);
    theta_pi_0_2  = zeros(ncoefs,1);

    % Map guess
    theta_ee1_0_2(1:ncoefs_trunc) = theta_in(6*ncoefs+1:6*ncoefs+ncoefs_trunc,1);
    theta_pi_0_2(1:ncoefs_trunc)  = theta_in(6*ncoefs+ncoefs_trunc+1:6*ncoefs+2*ncoefs_trunc,1);

    % OBJECTS FOR JACOBIAN %

    integrand_1_x_1_jacob = zeros(Q,6*ncoefs+2*ncoefs_trunc);
    integrand_1_x_0_jacob = zeros(Q,6*ncoefs+2*ncoefs_trunc);

    integrand_2_x_1_jacob = zeros(Q,6*ncoefs+2*ncoefs_trunc);
    integrand_2_x_0_jacob = zeros(Q,6*ncoefs+2*ncoefs_trunc);

    % MATRIX FOR JACOBIANS %

    jacob_res1 = ones(M,6*ncoefs+2*ncoefs_trunc) * nan;
    jacob_res2 = ones(M,6*ncoefs+2*ncoefs_trunc) * nan;

    % INDEX TO PICK UP MATRIX ELEMENTS
    ti = 1:ncoefs_trunc;
end

EE1_1_1 = PSI'*theta_ee1_1_1;
PI_1_1  = PSI'*theta_pi_1_1;

EE1_1_2 = PSI'*theta_ee1_1_2;
PI_1_2  = PSI'*theta_pi_1_2;

EE1_0_1 = PSI'*theta_ee1_0_1;
PI_0_1  = PSI'*theta_pi_0_1;

EE1_0_2 = PSI'*theta_ee1_0_2;
PI_0_2  = PSI'*theta_pi_0_2;

%--------------------------------------------------------------------------
%                           DEFINE CONSTANTS
%--------------------------------------------------------------------------
zeta = 1/(tau + psi2*(1-rho_R)); % For Jacobian %
b    = 1/(2*nu);

%--------------------------------------------------------------------------
%                           MAIN LOOP
%--------------------------------------------------------------------------

for i = 1:M

    R_lag  = Rgrid_in(i,1);             % R(-1) from grid of R
    y_lag  = ygrid_in(i,1);             % y(-1) from grid of y

    d      = dgrid_in(i,1);             % Preference Shock
    er     = ergrid_in(i,1);            % Monetary Shock
    z      = zgrid_in(i,1);             % Productivity shock
    g      = ggrid_in(i,1);             % Fiscal Shock

    s      = sgrid_in(i,1);             % Sunspot

    if O.ind_truncate_tilde==0
        %###### This is for the Jacobian WHEN S=1 ######%
        dee1_1_1_dtheta  =  [PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];
        dppi_1_1_dtheta  =  [0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];

        dee1_1_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];
        dppi_1_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];

        %###### This is for the Jacobian WHEN S=0 ######%
        dee1_0_1_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i)];
        dppi_0_1_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i)];

        dee1_0_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i)];
        dppi_0_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i)];
        %######################################%
    else
        %###### This is for the Jacobian WHEN S=1 ######%
        dee1_1_1_dtheta  =  [PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(ti,i);0*PSI(ti,i)];
        dppi_1_1_dtheta  =  [0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(ti,i);0*PSI(ti,i)];

        dee1_1_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(ti,i);0*PSI(ti,i)];
        dppi_1_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(ti,i);0*PSI(ti,i)];

        %###### This is for the Jacobian WHEN S=0 ######%
        dee1_0_1_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(:,i);0*PSI(ti,i);0*PSI(ti,i)];
        dppi_0_1_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(:,i);0*PSI(ti,i);0*PSI(ti,i)];

        dee1_0_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);PSI(ti,i);0*PSI(ti,i)];
        dppi_0_2_dtheta  =  [0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(:,i);0*PSI(ti,i);PSI(ti,i)];
        %######################################%
    end

    if s == 1

        % === For s = 1 ===%

        % First non-ZLB decision rules

        ee1 = EE1_1_1(i,1);
        ppi = PI_1_1(i,1);


        % Assume ZLB slack
        temp = ((r*pi_ss*((ppi/pi_ss)^psi1)*((exp(z)/y_lag)^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        y = ( (beta*ee1*temp) / (((1/exp(g)) - 0.5*phi*(ppi - pibar)^2)^(-tau)) )^(-1/(tau + psi2*(1-rho_R)));     % (61)
        R  = ((r*pi_ss*((ppi/pi_ss)^psi1)*(((y/y_lag)*exp(z))^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(er);

        % Check ZLB

        if R > 1
            c = (beta*R*ee1)^(-1/tau);
            ff = c^(-tau) * y *((1/nu) * (1 - chi_h*(c^tau)*(y^(1/eta))) + phi * (ppi - pibar) * ((1 - b)*ppi + pibar * b) - 1);

            % ### COMPUTE OBJECTS FOR DERIVATIVES S=1 #### %
            Gi = ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
            dG_dppi = -phi*(ppi-pibar);

            % Derivatives with respect to ee1 and ee1 when S=1%
            dy_dee1 = -(zeta*y/ee1);
            dR_dee1 = (-psi2*(1-rho_R)*R*zeta/ee1);

            % Derivatives with respect to pi_1 and pi_2 when S=1%
            dy_dppi = -zeta*y*( (psi1*(1-rho_R)/ppi) + (tau/Gi)*dG_dppi );
            dR_dppi = R*((psi1*(1-rho_R)/ppi)+ (psi2*(1-rho_R)/y)*dy_dppi);

            % These are the 8*ncoefsx1 vector with respect to theta_ee1 and theta_pi %
            if O.ind_truncate_tilde==0
            dy_dtheta = [dy_dee1*dee1_1_1_dtheta(1:ncoefs,1);...
                dy_dppi*dppi_1_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dy_dee1*dee1_1_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dy_dppi*dppi_1_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dy_dee1*dee1_1_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dy_dppi*dppi_1_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dy_dee1*dee1_1_1_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dy_dppi*dppi_1_1_dtheta(7*ncoefs+1:8*ncoefs,1)];

            dR_dtheta = [dR_dee1*dee1_1_1_dtheta(1:ncoefs,1);...
                dR_dppi*dppi_1_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dR_dee1*dee1_1_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dR_dppi*dppi_1_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dR_dee1*dee1_1_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dR_dppi*dppi_1_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dR_dee1*dee1_1_1_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dR_dppi*dppi_1_1_dtheta(7*ncoefs+1:8*ncoefs,1)];
            else

                dy_dtheta = [dy_dee1*dee1_1_1_dtheta(1:ncoefs,1);...                                %1
                dy_dppi*dppi_1_1_dtheta(ncoefs+1:2*ncoefs,1);...                                    %2
                dy_dee1*dee1_1_1_dtheta(2*ncoefs+1:3*ncoefs,1);...                                  %3
                dy_dppi*dppi_1_1_dtheta(3*ncoefs+1:4*ncoefs,1);...                                  %4
                dy_dee1*dee1_1_1_dtheta(4*ncoefs+1:5*ncoefs,1);...                                  %5
                dy_dppi*dppi_1_1_dtheta(5*ncoefs+1:6*ncoefs,1);...                                  %6
                dy_dee1*dee1_1_1_dtheta(6*ncoefs+1:6*ncoefs+ncoefs_trunc,1);...                     %7
                dy_dppi*dppi_1_1_dtheta(6*ncoefs+ncoefs_trunc+1:6*ncoefs+2*ncoefs_trunc,1)];      %8

                dR_dtheta = [dR_dee1*dee1_1_1_dtheta(1:ncoefs,1);...                                %1
                dR_dppi*dppi_1_1_dtheta(ncoefs+1:2*ncoefs,1);...                                    %2
                dR_dee1*dee1_1_1_dtheta(2*ncoefs+1:3*ncoefs,1);...                                  %3
                dR_dppi*dppi_1_1_dtheta(3*ncoefs+1:4*ncoefs,1);...                                  %4
                dR_dee1*dee1_1_1_dtheta(4*ncoefs+1:5*ncoefs,1);...                                  %5
                dR_dppi*dppi_1_1_dtheta(5*ncoefs+1:6*ncoefs,1);...                                  %6
                dR_dee1*dee1_1_1_dtheta(6*ncoefs+1:6*ncoefs+ncoefs_trunc,1);...                     %7
                dR_dppi*dppi_1_1_dtheta(6*ncoefs+ncoefs_trunc+1:6*ncoefs+2*ncoefs_trunc,1)];        %8

            end
            % Objects for Jacobian in Residual 2 %
            m        = c^(-tau)*y;
            BigGamma = (1-b)*ppi^2 + (2*b-1)*pibar*ppi - b*(pibar^2);

            dm_dtheta          = m*(((1-tau)/y)*dy_dtheta - (tau/Gi)*dG_dppi*dppi_1_1_dtheta);
            dBigGamma_dtheta   = (2*(1-b)*ppi + (2*b-1)*pibar)*dppi_1_1_dtheta;
            dff_1_dtheta       = dm_dtheta *(2*b - 1 + phi*BigGamma)- 2*b*(chi_h*(1+(1/eta))*y^(1/eta))*dy_dtheta  + phi*m*dBigGamma_dtheta;
            % ############################################ %
        else
            R = 1;

            ee1 = EE1_1_2(i,1);
            ppi = PI_1_2(i,1);

            c = (beta*R*ee1)^(-1/tau);
            y = c / ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);

            ff = c^(-tau) * y *((1/nu) * (1 - chi_h*(c^tau)*(y^(1/eta))) + phi * (ppi - pibar) * ((1 - b)*ppi + pibar * b) - 1);
            % ### COMPUTE OBJECTS FOR DERIVATIVES S=1 #### %
            Gi      = ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
            dG_dppi = -phi*(ppi-pibar);

            % Derivatives with respect to ee1_1 and ee1_2 %

            dy_dee1 = -(1/tau)*(y/ee1);
            dR_dee1 = 0;

            % Derivatives with respect to pi_1 and pi_2 %

            dy_dppi = -(y/Gi)*dG_dppi;
            dR_dppi = 0;

            % These are the 4*ncoefsx1 vector with respect to theta_ee1 and theta_pi %
            if O.ind_truncate_tilde==0
                    dy_dtheta = [dy_dee1*dee1_1_2_dtheta(1:ncoefs,1);...
                    dy_dppi*dppi_1_2_dtheta(ncoefs+1:2*ncoefs,1);...
                    dy_dee1*dee1_1_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                    dy_dppi*dppi_1_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                    dy_dee1*dee1_1_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                    dy_dppi*dppi_1_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                    dy_dee1*dee1_1_2_dtheta(6*ncoefs+1:7*ncoefs,1);...
                    dy_dppi*dppi_1_2_dtheta(7*ncoefs+1:8*ncoefs,1)];

                    dR_dtheta = [dR_dee1*dee1_1_2_dtheta(1:ncoefs,1);...
                    dR_dppi*dppi_1_2_dtheta(ncoefs+1:2*ncoefs,1);...
                    dR_dee1*dee1_1_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                    dR_dppi*dppi_1_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                    dR_dee1*dee1_1_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                    dR_dppi*dppi_1_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                    dR_dee1*dee1_1_2_dtheta(6*ncoefs+1:7*ncoefs,1);...
                    dR_dppi*dppi_1_2_dtheta(7*ncoefs+1:8*ncoefs,1)];
            else

                    dy_dtheta = [dy_dee1*dee1_1_2_dtheta(1:ncoefs,1);...
                    dy_dppi*dppi_1_2_dtheta(ncoefs+1:2*ncoefs,1);...
                    dy_dee1*dee1_1_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                    dy_dppi*dppi_1_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                    dy_dee1*dee1_1_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                    dy_dppi*dppi_1_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                    dy_dee1*dee1_1_2_dtheta(6*ncoefs+1:6*ncoefs+ncoefs_trunc,1);...                     %7
                    dy_dppi*dppi_1_2_dtheta(6*ncoefs+ncoefs_trunc+1:6*ncoefs+2*ncoefs_trunc,1)];        %8

                    dR_dtheta = [dR_dee1*dee1_1_2_dtheta(1:ncoefs,1);...
                    dR_dppi*dppi_1_2_dtheta(ncoefs+1:2*ncoefs,1);...
                    dR_dee1*dee1_1_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                    dR_dppi*dppi_1_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                    dR_dee1*dee1_1_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                    dR_dppi*dppi_1_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                    dR_dee1*dee1_1_2_dtheta(6*ncoefs+1:6*ncoefs+ncoefs_trunc,1);...                     %7
                    dR_dppi*dppi_1_2_dtheta(6*ncoefs+ncoefs_trunc+1:6*ncoefs+2*ncoefs_trunc,1)];        %8

            end
            % Objects for Jacobian in Residual 2 %

            m        = c^(-tau)*y;
            BigGamma = (1-b)*ppi^2 + (2*b-1)*pibar*ppi - b*(pibar^2);

            dm_dtheta        = m*(((1-tau)/y)*dy_dtheta - (tau/Gi)*dG_dppi*dppi_1_2_dtheta);
            dBigGamma_dtheta = (2*(1-b)*ppi + (2*b-1)*pibar)*dppi_1_2_dtheta;
            dff_1_dtheta     =  dm_dtheta *(2*b - 1 + phi*BigGamma)- 2*b*(chi_h*(1+(1/eta))*y^(1/eta))*dy_dtheta  + phi*m*dBigGamma_dtheta;
            % ############################################ %
        end

    elseif s == 0

        % === For s = 0 ====%

        % First non-ZLB decision rules

        ee1 = EE1_0_1(i,1);
        ppi = PI_0_1(i,1);

        % Assume ZLB slack S=0 %

        temp = ((r*pi_ss*((ppi/pi_ss)^psi1)*((exp(z)/y_lag)^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(er);
        y    = ( (beta*ee1*temp) / (((1/exp(g)) - 0.5*phi*(ppi - pibar)^2)^(-tau)) )^(-1/(tau + psi2*(1-rho_R)));
        R    = ((r*pi_ss*((ppi/pi_ss)^psi1)*(((y/y_lag)*exp(z))^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(er);

        % Check ZLB %

        if R > 1
            c  = (beta*R*ee1)^(-1/tau);
            ff = c^(-tau) * y *((1/nu) * (1 - chi_h*(c^tau)*(y^(1/eta))) + phi * (ppi - pibar) * ((1 - b)*ppi + pibar * b) - 1);

            % ### COMPUTE OBJECTS FOR DERIVATIVES S=0 #### %
            Gi = ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
            dG_dppi = -phi*(ppi-pibar);

            % Derivatives with respect to ee1_1 and ee1_2 when S=0%

            dy_dee1 = -(zeta*y/ee1);
            dR_dee1 = (-psi2*(1-rho_R)*R*zeta/ee1);

            % Derivatives with respect to pi_1 and pi_2 when S=1%

            dy_dppi = -zeta*y*( (psi1*(1-rho_R)/ppi) + (tau/Gi)*dG_dppi );
            dR_dppi = R*((psi1*(1-rho_R)/ppi)+ (psi2*(1-rho_R)/y)*dy_dppi);

            % These are the 2*ncoefsx1 vector with respect to theta_ee1 and theta_pi %
            if O.ind_truncate_tilde==0
            dy_dtheta = [dy_dee1*dee1_0_1_dtheta(1:ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dy_dee1*dee1_0_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dy_dee1*dee1_0_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dy_dee1*dee1_0_1_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(7*ncoefs+1:8*ncoefs,1)];

            dR_dtheta = [dR_dee1*dee1_0_1_dtheta(1:ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dR_dee1*dee1_0_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dR_dee1*dee1_0_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dR_dee1*dee1_0_1_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(7*ncoefs+1:8*ncoefs,1)];
            else
            dy_dtheta = [dy_dee1*dee1_0_1_dtheta(1:ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dy_dee1*dee1_0_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dy_dee1*dee1_0_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dy_dppi*dppi_0_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dy_dee1*dee1_0_1_dtheta(6*ncoefs+1:6*ncoefs+ncoefs_trunc,1);...
                dy_dppi*dppi_0_1_dtheta(6*ncoefs+ncoefs_trunc+1:6*ncoefs+2*ncoefs_trunc,1)];

            dR_dtheta = [dR_dee1*dee1_0_1_dtheta(1:ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(ncoefs+1:2*ncoefs,1);...
                dR_dee1*dee1_0_1_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dR_dee1*dee1_0_1_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dR_dppi*dppi_0_1_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dR_dee1*dee1_0_1_dtheta(6*ncoefs+1:6*ncoefs+ncoefs_trunc,1);...
                dR_dppi*dppi_0_1_dtheta(6*ncoefs+ncoefs_trunc+1:6*ncoefs+2*ncoefs_trunc,1)];

            end
            % Objects for Jacobian in Residual 2 %
            m        = c^(-tau)*y;
            BigGamma = (1-b)*ppi^2 + (2*b-1)*pibar*ppi - b*(pibar^2);

            dm_dtheta          = m*(((1-tau)/y)*dy_dtheta - (tau/Gi)*dG_dppi*dppi_0_1_dtheta);
            dBigGamma_dtheta   = (2*(1-b)*ppi + (2*b-1)*pibar)*dppi_0_1_dtheta;
            dff_0_dtheta       = dm_dtheta *(2*b - 1 + phi*BigGamma)- 2*b*(chi_h*(1+(1/eta))*y^(1/eta))*dy_dtheta  + phi*m*dBigGamma_dtheta;
            % ############################################ %
        else
            R = 1;

            ee1 = EE1_0_2(i,1);
            ppi = PI_0_2(i,1);

            c  = (beta*R*ee1)^(-1/tau);
            y  = c / ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);

            ff = c^(-tau) * y *((1/nu) * (1 - chi_h*(c^tau)*(y^(1/eta))) + phi * (ppi - pibar) * ((1 - b)*ppi + pibar * b) - 1);
            % ### COMPUTE OBJECTS FOR DERIVATIVES S=0 #### %
            Gi      = ((1/exp(g)) - 0.5*phi*(ppi - pibar)^2);
            dG_dppi = -phi*(ppi-pibar);

            % Derivatives with respect to ee1_1 and ee1_2 %

            dy_dee1 = -(1/tau)*(y/ee1);
            dR_dee1 = 0;

            % Derivatives with respect to pi_1 and pi_2 %

            dy_dppi = -(y/Gi)*dG_dppi;
            dR_dppi = 0;

            % These are the 4*ncoefsx1 vector with respect to theta_ee1 and theta_pi %
            if O.ind_truncate_tilde==0
            dy_dtheta = [dy_dee1*dee1_0_2_dtheta(1:ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(ncoefs+1:2*ncoefs,1);...
                dy_dee1*dee1_0_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dy_dee1*dee1_0_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dy_dee1*dee1_0_2_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(7*ncoefs+1:8*ncoefs,1)];

            dR_dtheta = [dR_dee1*dee1_0_2_dtheta(1:ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(ncoefs+1:2*ncoefs,1);...
                dR_dee1*dee1_0_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dR_dee1*dee1_0_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dR_dee1*dee1_0_2_dtheta(6*ncoefs+1:7*ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(7*ncoefs+1:8*ncoefs,1)];
            else

            dy_dtheta = [dy_dee1*dee1_0_2_dtheta(1:ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(ncoefs+1:2*ncoefs,1);...
                dy_dee1*dee1_0_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dy_dee1*dee1_0_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dy_dppi*dppi_0_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dy_dee1*dee1_0_2_dtheta(6*ncoefs+1:6*ncoefs+ncoefs_trunc,1);...
                dy_dppi*dppi_0_2_dtheta(6*ncoefs+ncoefs_trunc+1:6*ncoefs+2*ncoefs_trunc,1)];

            dR_dtheta = [dR_dee1*dee1_0_2_dtheta(1:ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(ncoefs+1:2*ncoefs,1);...
                dR_dee1*dee1_0_2_dtheta(2*ncoefs+1:3*ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(3*ncoefs+1:4*ncoefs,1);...
                dR_dee1*dee1_0_2_dtheta(4*ncoefs+1:5*ncoefs,1);...
                dR_dppi*dppi_0_2_dtheta(5*ncoefs+1:6*ncoefs,1);...
                dR_dee1*dee1_0_2_dtheta(6*ncoefs+1:6*ncoefs+ncoefs_trunc,1);...
                dR_dppi*dppi_0_2_dtheta(6*ncoefs+ncoefs_trunc+1:6*ncoefs+2*ncoefs_trunc,1)];

            end
            % Objects for Jacobian in Residual 2 %

            m        = c^(-tau)*y;
            BigGamma = (1-b)*ppi^2 + (2*b-1)*pibar*ppi - b*(pibar^2);

            dm_dtheta        = m*(((1-tau)/y)*dy_dtheta - (tau/Gi)*dG_dppi*dppi_0_2_dtheta);
            dBigGamma_dtheta = (2*(1-b)*ppi + (2*b-1)*pibar)*dppi_0_2_dtheta;
            dff_0_dtheta     =  dm_dtheta *(2*b - 1 + phi*BigGamma)- 2*b*(chi_h*(1+(1/eta))*y^(1/eta))*dy_dtheta  + phi*m*dBigGamma_dtheta;
            % ############################################ %
        end
    end

    %----------------------------------------------------------------------
    %                                   INTEGRALS
    %----------------------------------------------------------------------

    for q = 1:Q;

        % THIS ARE THE STOCHASTIC PROCESS OVER WHICH WE INTEGRATE %

        er_prime = ERPRIME(q,i);
        z_prime  = ZPRIME(q,i);
        g_prime  = GPRIME(q,i);
        d_prime  = DPRIME(q,i);

%         fprintf('z: %4.15f \n',z);
%         fprintf('z_prime: %4.15f \n',z_prime);
%
%         % Temporary
%         x_R = 2*((R - R_min)./(R_max-R_min))-1;
%         x_y = 2*((y - y_min)./(y_max-y_min))-1;
%         x_d = 2*((d_prime - d_min)./(d_max-d_min))-1;
%         x_e = 2*((er_prime - e_min)./(e_max-e_min))-1;
%         x_z = 2*((z_prime - z_min)./(z_max-z_min))-1;
%         x_g = 2*((g_prime - g_min)./(g_max-g_min))-1;
%
%         fprintf('x_R: %4.15f \n',x_R);
%         fprintf('x_y: %4.15f \n',x_y);
%         fprintf('x_e: %4.15f \n',x_e);
%         fprintf('x_z: %4.15f \n',x_z);
%         fprintf('x_g: %4.15f \n',x_g);
%         fprintf('x_d: %4.15f \n',x_d);

        % Build PSI_prime
        try
            PSI_prime = basis_temp(R,y,d_prime,er_prime,z_prime,g_prime); % basis for prime objects
        catch
            keyboard
        end



        % Approximate t+1 objects (start with unconstrained)
        % x -> 1
        ee1_prime_x_1 = PSI_prime'*theta_ee1_1_1;
        pi_prime_x_1  = PSI_prime'*theta_pi_1_1;

        % x -> 0
        ee1_prime_x_0 = PSI_prime'*theta_ee1_0_1;
        pi_prime_x_0  = PSI_prime'*theta_pi_0_1;

        % Get t+1 objects
        temp_prime_x_1 = ((r*pi_ss*((pi_prime_x_1/pi_ss)^psi1)*((exp(z_prime)/y)^psi2))^(1-rho_R))*((R)^rho_R)*exp(er_prime);
        temp_prime_x_0 = ((r*pi_ss*((pi_prime_x_0/pi_ss)^psi1)*((exp(z_prime)/y)^psi2))^(1-rho_R))*((R)^rho_R)*exp(er_prime);

        y_prime_x_1 = ( (beta*ee1_prime_x_1*temp_prime_x_1) / (((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_1 - pibar)^2)^(-tau)) )^(-1/(tau + psi2*(1-rho_R)));
        y_prime_x_0 = ( (beta*ee1_prime_x_0*temp_prime_x_0) / (((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_0 - pibar)^2)^(-tau)) )^(-1/(tau + psi2*(1-rho_R)));

        R_prime_x_1  = ((r*pi_ss*((pi_prime_x_1/pi_ss)^psi1)*(((y_prime_x_1/y)*exp(z_prime))^psi2))^(1-rho_R))*((R)^rho_R)*exp(er_prime);
        R_prime_x_0  = ((r*pi_ss*((pi_prime_x_0/pi_ss)^psi1)*(((y_prime_x_0/y)*exp(z_prime))^psi2))^(1-rho_R))*((R)^rho_R)*exp(er_prime);

        G_prime_x_1  = ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_1 - pibar)^2);
        G_prime_x_0  = ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_0 - pibar)^2);


%         fprintf('ee1_prime_x_1: %4.15f \n',ee1_prime_x_1);
%         fprintf('pi_prime_x_1: %4.15f \n',pi_prime_x_1);
%         fprintf('temp_prime_x_1: %4.15f \n',temp_prime_x_1);
%         fprintf('y_prime_x_1: %4.15f \n',y_prime_x_1);


        %% x-->1

        if R_prime_x_1 > 1

            c_prime_x_1    = (beta*R_prime_x_1*ee1_prime_x_1)^(-1/tau);

            %######## THIS IS FOR THE JACOBIAN: DERIVATIVES OF E1q and PIq (EVALUATED NUMERICALLY) ##########%
            [dee1_dR_prime, dee1_dy_prime, dpi_dR_prime, dpi_dy_prime] = get_prime_derivatives(R,y,d_prime,er_prime,z_prime,g_prime,ee1_prime_x_1, pi_prime_x_1, theta_ee1_1_1,theta_pi_1_1);
            if O.ind_truncate_tilde==0
            dee1prime_dtheta_x_1 = [PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dy_dtheta;

            dpiprime_dtheta_x_1  = [0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dy_dtheta;
            else
            dee1prime_dtheta_x_1 = [PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(ti,1);0*PSI_prime(ti,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dy_dtheta;

            dpiprime_dtheta_x_1  = [0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(ti,1);0*PSI_prime(ti,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dy_dtheta;
            end
%             fprintf('***s=1***\n')
%             fprintf('dee1_dR_prime: %4.15f\n',dee1_dR_prime)
%             fprintf('dee1_dy_prime: %4.15f\n',dee1_dy_prime)
%             fprintf('dpi_dR_prime: %4.15f\n',dpi_dR_prime)
%             fprintf('dpi_dy_prime: %4.15f\n',dpi_dy_prime)
%
%             fprintf('dee1prime_dtheta_x_1(211): %4.15f\n',dee1prime_dtheta_x_1(211))
%             fprintf('dpiprime_dtheta_x_1(211): %4.15f\n',dpiprime_dtheta_x_1(211))
%             fprintf('dR_dtheta(211): %4.15f\n',dR_dtheta(211))
%             fprintf('dy_dtheta(211): %4.15f\n',dy_dtheta(211))

            %### COMPUTE DERIVARIVES FOR R_prime > 1 ###%
            dGprime_dpiprime_x_1 = -phi*(pi_prime_x_1 - pibar);

            dyprime_dtheta_x_1   = y_prime_x_1*zeta*( -(psi1*(1-rho_R)/pi_prime_x_1)*dpiprime_dtheta_x_1 + (psi2*(1-rho_R)/y)*dy_dtheta ...
                - (rho_R/R)*dR_dtheta - (tau/G_prime_x_1)*dGprime_dpiprime_x_1*dpiprime_dtheta_x_1 - (1/ee1_prime_x_1)*dee1prime_dtheta_x_1 );

            dRprime_dtheta_x_1   = R_prime_x_1*((psi1*(1-rho_R)/pi_prime_x_1)*dpiprime_dtheta_x_1 + (psi2*(1-rho_R)/y_prime_x_1)*dyprime_dtheta_x_1 ...
                - (psi2*(1-rho_R)/y)*dy_dtheta + (rho_R/R)*dR_dtheta);
            %############################################

        else

            R_prime_x_1   = 1;
            ee1_prime_x_1 = PSI_prime'*theta_ee1_1_2;
            pi_prime_x_1  = PSI_prime'*theta_pi_1_2;
            c_prime_x_1   = (beta*R_prime_x_1*ee1_prime_x_1)^(-1/tau);
            y_prime_x_1   = c_prime_x_1 / ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_1 - pibar)^2);
            G_prime_x_1   = ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_1 - pibar)^2);

            %######## THIS IS FOR THE JACOBIAN: DERIVATIVES OF E1q and PIq (EVALUATED NUMERICALLY) ##########%
            [dee1_dR_prime, dee1_dy_prime, dpi_dR_prime, dpi_dy_prime] = get_prime_derivatives(R,y,d_prime,er_prime,z_prime,g_prime,ee1_prime_x_1, pi_prime_x_1, theta_ee1_1_2,theta_pi_1_2);

            if O.ind_truncate_tilde==0
                                    %1                 %2                 %3               %4                 %5                 %6                 %7                 %8
            dee1prime_dtheta_x_1 = [0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dy_dtheta;

                                    %1                 %2                 %3                 %4               %5                 %6                 %7                 %8
            dpiprime_dtheta_x_1  = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dy_dtheta;
            else
                                    %1                 %2                 %3               %4                 %5                 %6                 %7                 %8
            dee1prime_dtheta_x_1 = [0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(ti,1);0*PSI_prime(ti,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dy_dtheta;

                                    %1                 %2                 %3                 %4               %5                 %6                 %7                 %8
            dpiprime_dtheta_x_1  = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(ti,1);0*PSI_prime(ti,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dy_dtheta;
            end
            %### COMPUTE DERIVARIVES FOR R_prime = 1 ###%
            dGprime_dpiprime_x_1 = -phi*(pi_prime_x_1 - pibar);
            dyprime_dtheta_x_1   = -(y_prime_x_1/tau)*( (1/ee1_prime_x_1)*dee1prime_dtheta_x_1 + (tau/G_prime_x_1)*dGprime_dpiprime_x_1*dpiprime_dtheta_x_1);
            if O.ind_truncate_tilde==0
                dRprime_dtheta_x_1   = zeros(8*ncoefs,1);
            else
                dRprime_dtheta_x_1   = zeros(6*ncoefs+2*ncoefs_trunc,1);
            end
            %############################################
        end

        %% x-->0

        if R_prime_x_0 > 1

            c_prime_x_0 = (beta*R_prime_x_0*ee1_prime_x_0)^(-1/tau);

            %######## THIS IS FOR THE JACOBIAN: DERIVATIVES OF E1q and PIq (EVALUATED NUMERICALLY) ##########%
            [dee1_dR_prime, dee1_dy_prime, dpi_dR_prime, dpi_dy_prime] = get_prime_derivatives(R,y,d_prime,er_prime,z_prime,g_prime,ee1_prime_x_0, pi_prime_x_0, theta_ee1_0_1,theta_pi_0_1);

            % NOTE THE VECTOR OF PSI_PRIME HAS TO BE FLIPPED TO GET THE
            % TRANSITION DERIVATIVES CORRECTLY
            if  O.ind_truncate_tilde==0
                %1                 %2                 %3                 %4                %5                 %6                 %7                 %8
                dee1prime_dtheta_x_0 = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1)] ...
                    + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dy_dtheta;

                %1                 %2                 %3                 %4                %5                 %6                 %7                 %8
                dpiprime_dtheta_x_0  = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1)] ...
                    + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dy_dtheta;
            else
                %1                 %2                 %3                 %4                %5                 %6                 %7                 %8
                dee1prime_dtheta_x_0 = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(ti,1);0*PSI_prime(ti,1)] ...
                    + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dy_dtheta;

                %1                 %2                 %3                 %4                %5                 %6                 %7                 %8
                dpiprime_dtheta_x_0  = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(ti,1);0*PSI_prime(ti,1)] ...
                    + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dy_dtheta;

            end
%             fprintf('***s=0***\n')
%             fprintf('dee1_dR_prime: %4.15f\n',dee1_dR_prime)
%             fprintf('dee1_dy_prime: %4.15f\n',dee1_dy_prime)
%             fprintf('dpi_dR_prime: %4.15f\n',dpi_dR_prime)
%             fprintf('dpi_dy_prime: %4.15f\n',dpi_dy_prime)
%
%             fprintf('dee1prime_dtheta_x_0(211): %4.15f\n',dee1prime_dtheta_x_0(211))
%             fprintf('dpiprime_dtheta_x_0(211): %4.15f\n',dpiprime_dtheta_x_0(211))
%             fprintf('dR_dtheta(211): %4.15f\n',dR_dtheta(211))
%             fprintf('dy_dtheta(211): %4.15f\n',dy_dtheta(211))


            %### COMPUTE DERIVARIVES FOR R_prime > 1 ###%
            dGprime_dpiprime_x_0 = -phi*(pi_prime_x_0 - pibar);

            dyprime_dtheta_x_0   = y_prime_x_0*zeta*( -(psi1*(1-rho_R)/pi_prime_x_0)*dpiprime_dtheta_x_0 + (psi2*(1-rho_R)/y)*dy_dtheta ...
                - (rho_R/R)*dR_dtheta - (tau/G_prime_x_0)*dGprime_dpiprime_x_0*dpiprime_dtheta_x_0 - (1/ee1_prime_x_0)*dee1prime_dtheta_x_0);

            dRprime_dtheta_x_0   = R_prime_x_0*((psi1*(1-rho_R)/pi_prime_x_0)*dpiprime_dtheta_x_0 + (psi2*(1-rho_R)/y_prime_x_0)*dyprime_dtheta_x_0 ...
                - (psi2*(1-rho_R)/y)*dy_dtheta + (rho_R/R)*dR_dtheta);
            %############################################

        else

            R_prime_x_0   = 1;

            ee1_prime_x_0 = PSI_prime'*theta_ee1_0_2;
            pi_prime_x_0  = PSI_prime'*theta_pi_0_2;

            c_prime_x_0   = (beta*R_prime_x_0*ee1_prime_x_0)^(-1/tau);
            y_prime_x_0   = c_prime_x_0 / ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_0 - pibar)^2);
            G_prime_x_0   = ((1/exp(g_prime)) - 0.5*phi*(pi_prime_x_0 - pibar)^2);

            %######## THIS IS FOR THE JACOBIAN: DERIVATIVES OF E1q and PIq (EVALUATED NUMERICALLY) ##########%
            [dee1_dR_prime, dee1_dy_prime, dpi_dR_prime, dpi_dy_prime] = get_prime_derivatives(R,y,d_prime,er_prime,z_prime,g_prime,ee1_prime_x_0, pi_prime_x_0, theta_ee1_0_2,theta_pi_0_2);
            if O.ind_truncate_tilde ==0
            %1                 %2                 %3                 %4                %5                 %6                 %7                 %8
            dee1prime_dtheta_x_0 = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1);0*PSI_prime(:,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dy_dtheta;
            %1                 %2                 %3                 %4                %5                 %6                 %7                 %8
            dpiprime_dtheta_x_0  = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(:,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dy_dtheta;
            else
                            %1                 %2                 %3                 %4                %5                 %6                 %7                 %8
            dee1prime_dtheta_x_0 = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);PSI_prime(ti,1);0*PSI_prime(ti,1)] ...
                + dee1_dR_prime*dR_dtheta + dee1_dy_prime*dy_dtheta;
            %1                 %2                 %3                 %4                %5                 %6                 %7                 %8
            dpiprime_dtheta_x_0  = [0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(:,1);0*PSI_prime(ti,1);PSI_prime(ti,1)] ...
                + dpi_dR_prime*dR_dtheta  + dpi_dy_prime*dy_dtheta;
            end

            %### COMPUTE DERIVARIVES FOR R_prime = 1 ###%
            dGprime_dpiprime_x_0 = -phi*(pi_prime_x_0 - pibar);
            dyprime_dtheta_x_0   = -(y_prime_x_0/tau)*( (1/ee1_prime_x_0)*dee1prime_dtheta_x_0 + (tau/G_prime_x_0)*dGprime_dpiprime_x_0*dpiprime_dtheta_x_0);

            if O.ind_truncate_tilde==0
                dRprime_dtheta_x_0   = zeros(8*ncoefs,1);
            else
                dRprime_dtheta_x_0   = zeros(6*ncoefs+2*ncoefs_trunc,1);
            end
            %############################################

        end

        %------------------------------------------------------------------
        % Build Integrands
        %------------------------------------------------------------------

        integrand_1_x_1(q,:) =  (c_prime_x_1^-tau)*exp(d_prime - d)/(gamma*pi_prime_x_1*exp(z_prime));
        integrand_1_x_0(q,:) =  (c_prime_x_0^-tau)*exp(d_prime - d)/(gamma*pi_prime_x_0*exp(z_prime));

        integrand_2_x_1(q,:) =  ((c_prime_x_1)^-tau)*exp(d_prime - d)*(y_prime_x_1)*(pi_prime_x_1 - pibar)*pi_prime_x_1;
        integrand_2_x_0(q,:) =  ((c_prime_x_0)^-tau)*exp(d_prime - d)*(y_prime_x_0)*(pi_prime_x_0 - pibar)*pi_prime_x_0;

        %****************************
        % THIS IS FOR THE JACOBIAN
        %****************************

        % JACOBIAN INTEGRAND FOR RESIDUAL 1 %

        integrand_1_x_1_jacob(q,:)= (beta/(gamma*exp(z_prime)))*exp(d_prime - d)*((dRprime_dtheta_x_1*ee1_prime_x_1  ...
            + dee1prime_dtheta_x_1*R_prime_x_1)*pi_prime_x_1  - dpiprime_dtheta_x_1*(R_prime_x_1*ee1_prime_x_1)) /(pi_prime_x_1^2);

%         integrand_1_x_0_jacob(q,:)= (beta/(gamma*exp(z_prime)))*exp(d_prime - d)*((dRprime_dtheta_x_0*ee1_prime_x_0  ...
%             + dee1prime_dtheta_x_0*R_prime_x_0)*pi_prime_x_0  - dpiprime_dtheta_x_0*(R_prime_x_0*ee1_prime_x_0)) /(pi_prime_x_0^2);

        integrand_1_x_0_jacob(q,:)= (beta/(gamma*exp(z_prime)))*exp(d_prime - d)*((dRprime_dtheta_x_0*ee1_prime_x_0  ...
            + dee1prime_dtheta_x_0*R_prime_x_0)*pi_prime_x_0  - dpiprime_dtheta_x_0*(R_prime_x_0*ee1_prime_x_0)) /(pi_prime_x_0^2);


        % JACOBIAN INTEGRAND FOR RESIDUAL 2 %
        Omega_q_x_1 = (y_prime_x_1^(1-tau))*(G_prime_x_1^-tau)*(pi_prime_x_1 - pibar)*pi_prime_x_1*exp(d_prime - d);
        Omega_q_x_0 = (y_prime_x_0^(1-tau))*(G_prime_x_0^-tau)*(pi_prime_x_0 - pibar)*pi_prime_x_0*exp(d_prime - d);

        integrand_2_x_1_jacob(q,:)= Omega_q_x_1*( ((1-tau)/y_prime_x_1)*dyprime_dtheta_x_1 - (tau/G_prime_x_1)*dGprime_dpiprime_x_1*dpiprime_dtheta_x_1 ...
            + ((2*pi_prime_x_1 - pibar)/((pi_prime_x_1 - pibar)*pi_prime_x_1))*dpiprime_dtheta_x_1 );

        integrand_2_x_0_jacob(q,:)= Omega_q_x_0*( ((1-tau)/y_prime_x_0)*dyprime_dtheta_x_0 - (tau/G_prime_x_0)*dGprime_dpiprime_x_0*dpiprime_dtheta_x_0 ...
            + ((2*pi_prime_x_0 - pibar)/((pi_prime_x_0 - pibar)*pi_prime_x_0))*dpiprime_dtheta_x_0 );

%         fprintf('integrand_1_x_0_jacob(1,1): %4.15f\n',integrand_1_x_0_jacob(1,1))
%         fprintf('integrand_1_x_0_jacob(2,1): %4.15f\n',integrand_1_x_0_jacob(1,2))
%         fprintf('integrand_1_x_0_jacob(212,1): %4.15f\n',integrand_1_x_0_jacob(1,212))
%         fprintf('integrand_1_x_0_jacob(422,1): %4.15f\n',integrand_1_x_0_jacob(1,422))
%         fprintf('integrand_1_x_0_jacob(632,1): %4.15f\n',integrand_1_x_0_jacob(1,632))
%         fprintf('integrand_1_x_0_jacob(842,1): %4.15f\n',integrand_1_x_0_jacob(1,842))
%         fprintf('integrand_1_x_0_jacob(1052,1): %4.15f\n',integrand_1_x_0_jacob(1,1052))
%         fprintf('integrand_1_x_0_jacob(1472,1): %4.15f\n',integrand_1_x_0_jacob(1,1472))
%
%         fprintf('dRprime_dtheta_x_0(1,1): %4.15f\n',dRprime_dtheta_x_0(1,1))
%         fprintf('dRprime_dtheta_x_0(211,1): %4.15f\n',dRprime_dtheta_x_0(211,1))
%         fprintf('dRprime_dtheta_x_0(421,1): %4.15f\n',dRprime_dtheta_x_0(421,1))
%         fprintf('dRprime_dtheta_x_0(631,1): %4.15f\n',dRprime_dtheta_x_0(631,1))
%         fprintf('dRprime_dtheta_x_0(841,1): %4.15f\n',dRprime_dtheta_x_0(841,1))
%         fprintf('dRprime_dtheta_x_0(1051,1): %4.15f\n',dRprime_dtheta_x_0(1051,1))
%         fprintf('dRprime_dtheta_x_0(1471,1): %4.15f\n',dRprime_dtheta_x_0(1471,1))
%
%         fprintf('dpiprime_dtheta_x_0(1,1): %4.15f\n',dpiprime_dtheta_x_0(1,1))
%         fprintf('dpiprime_dtheta_x_0(211,1): %4.15f\n',dpiprime_dtheta_x_0(211,1))
%         fprintf('dpiprime_dtheta_x_0(421,1): %4.15f\n',dpiprime_dtheta_x_0(421,1))
%         fprintf('dpiprime_dtheta_x_0(631,1): %4.15f\n',dpiprime_dtheta_x_0(631,1))
%         fprintf('dpiprime_dtheta_x_0(841,1): %4.15f\n',dpiprime_dtheta_x_0(841,1))
%         fprintf('dpiprime_dtheta_x_0(1051,1): %4.15f\n',dpiprime_dtheta_x_0(1051,1))
%         fprintf('dpiprime_dtheta_x_0(1471,1): %4.15f\n',dpiprime_dtheta_x_0(1471,1))
%
%         fprintf('dee1prime_dtheta_x_0(1,1): %4.15f\n',dee1prime_dtheta_x_0(1,1))
%         fprintf('dee1prime_dtheta_x_0(211,1): %4.15f\n',dee1prime_dtheta_x_0(211,1))
%         fprintf('dee1prime_dtheta_x_0(421,1): %4.15f\n',dee1prime_dtheta_x_0(421,1))
%         fprintf('dee1prime_dtheta_x_0(631,1): %4.15f\n',dee1prime_dtheta_x_0(631,1))
%         fprintf('dee1prime_dtheta_x_0(841,1): %4.15f\n',dee1prime_dtheta_x_0(841,1))
%         fprintf('dee1prime_dtheta_x_0(1051,1): %4.15f\n',dee1prime_dtheta_x_0(1051,1))
%         fprintf('dee1prime_dtheta_x_0(1471,1): %4.15f\n',dee1prime_dtheta_x_0(1471,1))
%
%
%         fprintf('ee1_prime_x_0: %4.15f\n',ee1_prime_x_0)
%         fprintf('R_prime_x_0: %4.15f\n',R_prime_x_0)
%         fprintf('pi_prime_x_0: %4.15f\n',pi_prime_x_0)
%         fprintf('z_prime: %4.15f\n',z_prime)
%         fprintf('d_prime: %4.15f\n',d_prime)

% Check for NaN inside integral:
        if isnan(integrand_2_x_1_jacob(q,:))
            keyboard;
        end
    end

    sol_int1_x_1 = integrand_1_x_1' * WEIGHT;
    sol_int1_x_0 = integrand_1_x_0' * WEIGHT;

    sol_int2_x_1 = integrand_2_x_1' * WEIGHT;
    sol_int2_x_0 = integrand_2_x_0' * WEIGHT;

    %### Solve Integral for Jacobian ###%

    sol_int1_jacob_x_1 =  integrand_1_x_1_jacob'*WEIGHT;
    sol_int1_jacob_x_0 =  integrand_1_x_0_jacob'*WEIGHT;

    sol_int2_jacob_x_1 =  integrand_2_x_1_jacob'*WEIGHT;
    sol_int2_jacob_x_0 =  integrand_2_x_0_jacob'*WEIGHT;


%     fprintf('sol_int1_jacob_x_0(1,1): %4.15f\n',sol_int1_jacob_x_0(1))
%     fprintf('sol_int1_jacob_x_0(1,2): %4.15f\n',sol_int1_jacob_x_0(2))
%     fprintf('sol_int1_jacob_x_0(1,211): %4.15f\n',sol_int1_jacob_x_0(211))
%     fprintf('sol_int1_jacob_x_0(1,421): %4.15f\n',sol_int1_jacob_x_0(421))
%     fprintf('sol_int1_jacob_x_0(1,631): %4.15f\n',sol_int1_jacob_x_0(631))
%     fprintf('sol_int1_jacob_x_0(1,841): %4.15f\n',sol_int1_jacob_x_0(841))


%             if i<3
%         fprintf('**** q = %i, i=%i ***** \n',q,i);
%         fprintf('R_prime_x_1: %4.15f \n',R_prime_x_1);
%         fprintf('R_prime_x_0: %4.15f \n',R_prime_x_0);
%         end

    %------------------------------------------------------------------
    %         Compute residuals for each gridpoint i=1,...,M
    %------------------------------------------------------------------
    if s == 1

        res1(i,:) = ee1 - rho1*sol_int1_x_1 - (1-rho1)*sol_int1_x_0;
        res2(i,:) = ff  - rho1*phi*beta*sol_int2_x_1 - (1-rho1)*phi*beta*sol_int2_x_0;

        if R > 1

        %### Create Jacobian Matrices S=1 ###%

        jacob_res1(i,:) =  dee1_1_1_dtheta - rho1*sol_int1_jacob_x_1 - (1-rho1)*sol_int1_jacob_x_0;
        jacob_res2(i,:) =  dff_1_dtheta  - rho1*phi*beta*sol_int2_jacob_x_1 - (1-rho1)*phi*beta*sol_int2_jacob_x_0;

        else

        jacob_res1(i,:) = dee1_1_2_dtheta - rho1*sol_int1_jacob_x_1 - (1-rho1)*sol_int1_jacob_x_0;
        jacob_res2(i,:) = dff_1_dtheta    - rho1*phi*beta*sol_int2_jacob_x_1 - (1-rho1)*phi*beta*sol_int2_jacob_x_0;

        end

    elseif s == 0

        if R > 1

            res1(i,:) = ee1 - rho0*sol_int1_x_0 - (1-rho0)*sol_int1_x_1;
            res2(i,:) = ff  - rho0*phi*beta*sol_int2_x_0 - (1-rho0)*phi*beta*sol_int2_x_1;

            %### Create Jacobian Matrices S=0 ###%

            jacob_res1(i,:) = dee1_0_1_dtheta - rho0*sol_int1_jacob_x_0 - (1-rho0)*sol_int1_jacob_x_1;
            jacob_res2(i,:) = dff_0_dtheta    - rho0*phi*beta*sol_int2_jacob_x_0 - (1-rho0)*phi*beta*sol_int2_jacob_x_1;

        else
            res1(i,:) = ee1 - rho0*sol_int1_x_0 - (1-rho0)*sol_int1_x_1;
            res2(i,:) = ff  - rho0*phi*beta*sol_int2_x_0 - (1-rho0)*phi*beta*sol_int2_x_1;

            %### Create Jacobian Matrices S=0 ###%

            jacob_res1(i,:) = dee1_0_2_dtheta - rho0*sol_int1_jacob_x_0 - (1-rho0)*sol_int1_jacob_x_1;
            jacob_res2(i,:) = dff_0_dtheta    - rho0*phi*beta*sol_int2_jacob_x_0 - (1-rho0)*phi*beta*sol_int2_jacob_x_1;

        end

    end

end
% STORE RESIDUALS
G = [res1;res2];

%         fprintf('sol_int1_jacob_x_1(1,1) = %4.15f \n',sol_int1_jacob_x_1(1,1))
%         fprintf('sol_int1_jacob_x_1(5,1) = %4.15f \n',sol_int1_jacob_x_1(5,1))
%         fprintf('integrand_1_x_1_jacob(1,1) = %4.15f \n',integrand_1_x_1_jacob(1,1))
%         fprintf('integrand_1_x_1_jacob(2,1) = %4.15f \n',integrand_1_x_1_jacob(2,1))
%         fprintf('jacob_res1(1,1) = %4.15f \n',jacob_res1(1,1))
%         fprintf('jacob_res1(1,5) = %4.15f \n',jacob_res1(1,5))
%
%         fprintf('jacob_res1(2,1) = %4.15f \n',jacob_res1(2,1))
%         fprintf('jacob_res1(2,5) = %4.15f \n',jacob_res1(2,5))


% STORE JACOBIAN
JACOB = [jacob_res1;jacob_res2];

%
% if sum(isnan(G))> 0 || sum(sum(isnan(JACOB),2))
%     keyboard;
% end
