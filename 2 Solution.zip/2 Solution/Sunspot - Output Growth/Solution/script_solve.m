%==========================================================================
%                       REPLICATION FILE FOR
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide) 
%
% MAIN FILE TO SOLVE SUNSPOT OUTPUT GROWTH MODEL:
%
% Stored models are:
%                      US_3vGrowth          JP_3vGrowth
%                      US_4vGrowth_C        JP_4vGrowth_C
%                      US_4vGrowth_G        JP_4vGrowth_G   
%
%==========================================================================


clear all; close all; clc; delete *.asv *.~m

% ADD IMPORTANT PATHS
addpath ../Matfiles/            % Directory with mat files (Filtered States)
addpath ../Common/              % Directory with common functions

% GLOBAL VARIABLES 
global O Q order ncoefs 
global ER_prime EZ_prime EG_prime ED_prime WEIGHT
global ERPRIME ZPRIME GPRIME DPRIME
global rho1 rho0 Rbar seedname

% MEX COMPILATION
% To run the solution using the mex implementation first you need to setup
% a Fortran compiler (We used Intel Visual Fortran Composer XE 2013 
% with Microsoft Visual Studio 2012). 
% On the command line first run:
% mex -setup FORTRAN
% mex system_sunspot_jacob_mex.F90
% And uncomment lines 389,402,417 below.

%==========================================================================
%                      USER OPTIONS
%==========================================================================

order           = 4;                 % Order of polynomial approximation (automatically selects M = 30 for order 2, 60 for order 3, 130 for order 4, 260 for order 5)
ncoefs          = 210;               % Number of coefficients for 4th order solution
O.ind_impose    = 1;                 % Keep at 1
O.ind_grid      = 1;                 % [0] Just ergodic distribution [1] With Filtered States (67 points for data, rest from ergodic distribution)
                                     % Note that ind_grid = 1 should be used with order = 4. (override  below)

O.ind_fresh_shocks = 0;              % [1] Draw new shocks / [0] use stored shocks
O.integration_rule = 'M1';           % Integration Rule GH = Gauss-Hermite quadrature, M1 = Monomial 1, M2 = Monomial 2.

O.ind_truncate_tilde = 0;            % [Deprecated] Keep at 0
O.truncation_order = 2;              % [Deprecated] Keep at 2


Npoints = 200;                       % Points to evaluate the model Euler Errors
Q1      = 5;                         % Order of Quadrature Integration
Q2      = 5;                         % Quadrature points for evaluation
Niter   = 5;                         % Number of Iterations >  1;
Tsim = 10000;                        % Number of periods for simulating ergodic distribution. 
Tdrop   = 150;                       % Number of initial simulations that will be dropped.
TolFun_use = 1E-12;                  % Set TolFun for minimizer
TolX_use = 1E-5;                     % Set TolX for minimizer
MaxIter_use = 1000;                  % Set Maximum number of Iterations for solver

Rbar = 1;                            % ZLB cutoff
sunspot_initial = 1;                 % [1] STAR / [0] TILDE
seedname  = 'mrg32k3a';              % String to generate RandomNumber Streams

options_use       = optimset('display','iter','MaxFunEvals',100000,'MaxIter',MaxIter_use,'TolFun',TolFun_use,'TolX',TolX_use,'FunValCheck','On');
options_use_jacob = optimset('display','iter','MaxFunEvals',100000,'MaxIter',MaxIter_use,'TolFun',TolFun_use,'TolX',TolX_use,'FunValCheck','On','Jacobian','On','DerivativeCheck','Off');

%**************************************************************************
%********** END OF USER'S OPTIONS *****************************************
%**************************************************************************

model_number = input('Sunspot Model to Solve: ','s');

if Niter < 1
    error('\n **** Need to iterate solution at least once!. Set Niter >=1 \n');
end

%--------------------------------------------------------------------------
%                 SET PARAMETER VALUES
%--------------------------------------------------------------------------

% GET INITIAL GUESS FROM STORED SOLUTION
theta_old = get_sunspot_guess(model_number);

% LOAD PARAMETERS
load_params; 

% NUMBER OF GRID POINTS FROM STORED SOLUTION
M = par.M;

% KEEP A COPY OF INITIAL GUESS
theta_0_keep = theta_old;

%--------------------------------------------------------------------------
% DRAW EXOGENOUS SHOCKS (STRUCTURAL + SUNSPOT)
%--------------------------------------------------------------------------

if O.ind_fresh_shocks==0

    load SHOCKSMAT.mat
    
    shocks.er = shocks.er*par.sig_r;
    shocks.ez = shocks.ez*par.sig_z;
    shocks.eg = shocks.eg*par.sig_g;
    shocks.ed = shocks.ed*par.sig_d;

elseif O.ind_fresh_shocks==1

    [s_er, s_ez, s_eg, s_ed] = RandStream.create(seedname,'NumStreams',4);
    
    shocks.er = sig_r*randn(s_er, Tsim+Tdrop, 1);
    shocks.ez = sig_z*randn(s_ez, Tsim+Tdrop, 1);
    shocks.eg = sig_g*randn(s_eg, Tsim+Tdrop, 1);
    shocks.ed = sig_d*randn(s_ed, Tsim+Tdrop, 1);
end

SUNSPOT = get_sunspot(Tsim,sunspot_initial,Tdrop, 1);

%--------------------------------------------------------------------------
% NODES AND WEIGHTS FOR INTEGRATION
%--------------------------------------------------------------------------


if strcmp(O.integration_rule,'GH')
    [ER_prime, EZ_prime, EG_prime, ED_prime, WEIGHT] = get_GH_nodes(Q1);
    Q = Q1^4;
    IntRule = strcat(O.integration_rule,num2str(Q1));
elseif strcmp(O.integration_rule,'M1')
    N = 4;
    [ER_prime, EZ_prime, EG_prime, ED_prime, WEIGHT, Q] = get_Monomial_nodes('M1',N);
    IntRule = O.integration_rule;
end

%--------------------------------------------------------------------------
% LOAD FILTERED STATES
%--------------------------------------------------------------------------

if O.ind_grid == 1          
    filtered_states_use = ['FILTERED_GRID_SUNSPOT_' model_number];

    load(filtered_states_use);
    
    % ARRANGE FILTERED STATES AND OBTAIN FILTERED SHOCKS   
    FILTERED_STATES.er    = RAW(:,8);
    FILTERED_STATES.d     = RAW(:,12);
    FILTERED_STATES.z     = RAW(:,13);
    FILTERED_STATES.g     = RAW(:,14);
    FILTERED_STATES.A     = RAW(:,18);
    FILTERED_STATES.SUN   = RAW(:,19);
    FILTERED_STATES.Rlag  = RAW(:,22);
    FILTERED_STATES.ylag  = RAW(:,23);
    FILTERED_STATES.clag  = RAW(:,24);
    FILTERED_STATES.dlag  = RAW(:,25);
    FILTERED_STATES.zlag  = RAW(:,26);
    FILTERED_STATES.glag  = RAW(:,27);
    
    FILTERED_STATES.ez   = RAW(:,13) - rho_z .* RAW(:,26);
    FILTERED_STATES.eg   = RAW(:,14) - (1 - rho_g) * log(gstar) ...
        - rho_g .* RAW(:,27);
    FILTERED_STATES.ed   = RAW(:,12) - rho_d .* RAW(:,25);

    clear RAW;

    num_filtered_states = length(FILTERED_STATES.Rlag);
    
    fprintf('\n *** I will use %i filtered states *** \n', num_filtered_states);
    
    sun_threshold = 0.1;
    
    FILTERED_STATES.SUN(FILTERED_STATES.SUN<=sun_threshold)=0;

    FILTERED_STATES.SUN(FILTERED_STATES.SUN> sun_threshold)=1;

else
    filtered_states_use = 'None';
    num_filtered_states = 0;
end


%--------------------------------------------------------------------------
%           MODEL SOLUTION-SIMULATION LOOP 
%--------------------------------------------------------------------------

label     = cell(Niter,1);
THETA.r0  = theta_old;
time_keep = 0;
ssr_old   = 10e6;


for iter_count=1:Niter
    
    % *** SIMULATE ERGODIC SET *** %   
    label(iter_count) = {strcat('r',num2str(iter_count))};
    
    simuse = simulate_sunspot(theta_old,shocks,init_sun,Tsim,Tdrop,SUNSPOT);

    % *** CONSTRUCT SOLUTION GRID *** %
    
    if O.ind_grid == 0  % Just the ergodic distribution
    
        fprintf('\n Creating TSGA grid - Algo 3 - Order %i - Iteration %i. Wait... \n',order,iter_count)
                
        [GRID0.(label{iter_count}), GRID1.(label{iter_count})] = get_ergodic_grid(simuse,M);
        
        Rlaggrid1  = GRID1.(label{iter_count})(:,1);     % R_lag grid
        ylaggrid1  = GRID1.(label{iter_count})(:,2);     % y_lag grid
        dgrid1     = GRID1.(label{iter_count})(:,3);     % d grid
        ergrid1    = GRID1.(label{iter_count})(:,4);     % e_R grid
        zgrid1     = GRID1.(label{iter_count})(:,5);     % z grid
        ggrid1     = GRID1.(label{iter_count})(:,6);     % g grid
        sgrid1     = GRID1.(label{iter_count})(:,7);     % s grid
               
        Rlaggrid0  = GRID0.(label{iter_count})(:,1);     % R_lag grid
        ylaggrid0  = GRID0.(label{iter_count})(:,2);     % y_lag grid
        dgrid0     = GRID0.(label{iter_count})(:,3);     % d grid
        ergrid0    = GRID0.(label{iter_count})(:,4);     % e_R grid
        zgrid0     = GRID0.(label{iter_count})(:,5);     % z grid
        ggrid0     = GRID0.(label{iter_count})(:,6);     % g grid
        sgrid0     = GRID0.(label{iter_count})(:,7);     % s grid
        
        Rlaggrid   = [Rlaggrid1;Rlaggrid0];
        ylaggrid   = [ylaggrid1;ylaggrid0];
        dgrid      = [dgrid1;dgrid0];
        ergrid     = [ergrid1;ergrid0];
        zgrid      = [zgrid1;zgrid0];
        ggrid      = [ggrid1;ggrid0];
        sgrid      = [sgrid1;sgrid0];
        
    elseif O.ind_grid == 1  % Combine the ergodic distribution with the filtered states
                
        fprintf('\n Creating TSGA grid augmented with Filtered States - Order %i - Iteration %i.\n',order,iter_count)
        if mod(M-num_filtered_states,2)>0
            [GRID0.(label{iter_count}), GRID1.(label{iter_count})] = get_ergodic_grid(simuse,M + 1 - num_filtered_states);
        else
            [GRID0.(label{iter_count}), GRID1.(label{iter_count})] = get_ergodic_grid(simuse,M - num_filtered_states);
        end
        Rlaggrid0  = GRID0.(label{iter_count})(:,1);     % R_lag grid
        ylaggrid0  = GRID0.(label{iter_count})(:,2);     % y_lag grid        
        dgrid0     = GRID0.(label{iter_count})(:,3);     % d grid
        ergrid0    = GRID0.(label{iter_count})(:,4);     % e_R grid
        zgrid0     = GRID0.(label{iter_count})(:,5);     % z grid
        ggrid0     = GRID0.(label{iter_count})(:,6);     % g grid
        sgrid0     = GRID0.(label{iter_count})(:,7);     % s grid

        Rlaggrid1  = GRID1.(label{iter_count})(:,1);     % R_lag grid
        ylaggrid1  = GRID1.(label{iter_count})(:,2);     % y_lag grid        
        dgrid1     = GRID1.(label{iter_count})(:,3);     % d grid
        ergrid1    = GRID1.(label{iter_count})(:,4);     % e_R grid
        zgrid1     = GRID1.(label{iter_count})(:,5);     % z grid
        ggrid1     = GRID1.(label{iter_count})(:,6);     % g grid
        sgrid1     = GRID1.(label{iter_count})(:,7);     % s grid
               
        % Now bring in Filtered Data for the US
        if O.ind_params==2;             
            % For the US we have: 
            % Filtered data 2000Q1-2008Q4       36  obs
            % Filtered Particles 2009Q1-2013Q4	320 obs (8 particles per period)	

            % The filtered data from 2000-2008Q4
            Rlaggrid2  = FILTERED_STATES.Rlag(1:36);        % R grid
            ylaggrid2  = FILTERED_STATES.ylag(1:36);        % ylag grid
            dgrid2     = FILTERED_STATES.d(1:36);           % d grid
            ergrid2    = FILTERED_STATES.er(1:36);          % e_R grid
            zgrid2     = FILTERED_STATES.z(1:36);           % z grid
            ggrid2     = FILTERED_STATES.g(1:36);           % g grid
            sgrid2     = max(FILTERED_STATES.SUN(1:36),ones(36,1));  % s grid
            
            % The filtered data from 2009Q1-2013Q4 assuming S = 0 throughout (8
            % particles per period)
            
            Rlaggrid3 = FILTERED_STATES.Rlag(37:196);      % R grid
            ylaggrid3 = FILTERED_STATES.ylag(37:196);       % ylag grid
            dgrid3  = FILTERED_STATES.d(37:196);            % d grid
            ergrid3 = FILTERED_STATES.er(37:196);           % e_R grid
            zgrid3  = FILTERED_STATES.z(37:196);            % z grid
            ggrid3  = FILTERED_STATES.g(37:196);            % g grid
            sgrid3  = FILTERED_STATES.SUN(37:196);          % s grid
            
            % The filtered data from 2009Q1-2013Q4 assuming S = 1 throughout (8
            % particles per period)
            
            Rlaggrid4 = FILTERED_STATES.Rlag(197:356);      % R grid
            ylaggrid4 = FILTERED_STATES.ylag(197:356);      % ylag grid
            dgrid4    = FILTERED_STATES.d(197:356);         % d grid
            ergrid4   = FILTERED_STATES.er(197:356);        % e_R grid
            zgrid4    = FILTERED_STATES.z(197:356);         % z grid
            ggrid4    = FILTERED_STATES.g(197:356);         % g grid
            sgrid4    = FILTERED_STATES.SUN(197:356);       % s grid
            
            elseif O.ind_params==3
            % For JP we have
            % No filtered states
            Rlaggrid2  = [];  % R grid
            ylaggrid2  = [];  % ylag grid
            dgrid2     = [];  % d grid
            ergrid2    = [];  % e_R grid
            zgrid2     = [];  % z grid
            ggrid2     = [];  % g grid
            sgrid2     = [];  % s grid
            
            % Filtered particles from 1999Q1-2015Q1 assuming S = 0 
            % throughout (3 particles per period)
            
            s0end   = find(FILTERED_STATES.SUN==0,1,'last');
            
            if ~isempty(s0end)
                
                Rlaggrid3 = FILTERED_STATES.Rlag(1:s0end);      % R grid
                ylaggrid3 = FILTERED_STATES.ylag(1:s0end);       % ylag grid
                dgrid3  = FILTERED_STATES.d(1:s0end);            % d grid
                ergrid3 = FILTERED_STATES.er(1:s0end);           % e_R grid
                zgrid3  = FILTERED_STATES.z(1:s0end);            % z grid
                ggrid3  = FILTERED_STATES.g(1:s0end);            % g grid
                sgrid3  = FILTERED_STATES.SUN(1:s0end);          % s grid
            else
                Rlaggrid3 = [];       % R grid
                ylaggrid3 = [];        % ylag grid
                dgrid3  = [];             % d grid
                ergrid3 = [];            % e_R grid
                zgrid3  = [];             % z grid
                ggrid3  = [];             % g grid
                sgrid3  = [];           % s grid

                s0end=0;
            end
            
            % Filtered particles from 1999Q1-2015Q1 assuming S = 1 
            % throughout (3 particles per period)

            Rlaggrid4 = FILTERED_STATES.Rlag(s0end+1:end);      % R grid
            ylaggrid4 = FILTERED_STATES.ylag(s0end+1:end);      % ylag grid
            dgrid4    = FILTERED_STATES.d(s0end+1:end);         % d grid
            ergrid4   = FILTERED_STATES.er(s0end+1:end);        % e_R grid
            zgrid4    = FILTERED_STATES.z(s0end+1:end);         % z grid
            ggrid4    = FILTERED_STATES.g(s0end+1:end);         % g grid
            sgrid4    = FILTERED_STATES.SUN(s0end+1:end);       % s grid
        
            
        else
            error('Wrong configuration!')
        end
        
        % Combine Grids

        Rlaggrid  = [Rlaggrid1;Rlaggrid0;Rlaggrid2;Rlaggrid3;Rlaggrid4];
        ylaggrid  = [ylaggrid1;ylaggrid0;ylaggrid2;ylaggrid3;ylaggrid4];
        dgrid     = [dgrid1;dgrid0;dgrid2;dgrid3;dgrid4];
        ergrid    = [ergrid1;ergrid0;ergrid2;ergrid3;ergrid4];
        zgrid     = [zgrid1;zgrid0;zgrid2;zgrid3;zgrid4];
        ggrid     = [ggrid1;ggrid0;ggrid2;ggrid3;ggrid4];
        sgrid     = [sgrid1;sgrid0;sgrid2;sgrid3;sgrid4];
 
    end
       
    % STORE SOLUTION GRID
    EVAL_SOL = [Rlaggrid ylaggrid dgrid ergrid zgrid ggrid sgrid]; 
   
    % BASIS FUNCTION
    PSI  = basis_temp(Rlaggrid, ylaggrid, dgrid, ergrid, zgrid, ggrid);
    
    % TABULATE THE EXOGENOUS PROCESS ERPRIME, ZPRIME, GPRIME, DPRIME     
    ERPRIME = NaN(Q,M);       % Clean up the matrices
    ZPRIME  = NaN(Q,M);
    GPRIME  = NaN(Q,M);
    DPRIME  = NaN(Q,M);
   
    for i=1:M;
        for q=1:Q
            ERPRIME(q,i)   = ER_prime(q);
            ZPRIME(q,i)    = rho_z*zgrid(i) + EZ_prime(q);
            GPRIME(q,i)    = (1-rho_g)*log(gstar) + rho_g*ggrid(i) + EG_prime(q);
            DPRIME(q,i)    = rho_d*dgrid(i) + ED_prime(q);
        end    
    end
  
    GRID = [Rlaggrid ylaggrid dgrid ergrid zgrid ggrid sgrid];
    EXO  = [ER_prime EZ_prime EG_prime ED_prime];
    
    %----------------------------------------------------------------------
    %                       THIS IS THE SOLUTION BLOCK
    %----------------------------------------------------------------------
        
    fprintf('\n Solving Sunspot Model -  Order %i - Iteration %i \n',order, iter_count);
    
    % Uncomment if using mex code
    %ssr_temp = norm(system_sunspot_jacob_mex(theta_old, PSI ,GRID, WEIGHT, EXO))^2;

    ssr_temp = norm(system_sunspot_jacob(theta_old, Rlaggrid,ylaggrid,dgrid,ergrid,zgrid,ggrid,sgrid,PSI, M))^2;
    
    if abs(ssr_temp - ssr_old) > TolFun_use       

            fprintf('\n *** Solving with Analytical Derivatives - Order %i - Iteration %i \n',order, iter_count);

            tic
            [theta_use,resnorm,res_use,exitflag,output,lambda,jacobian] = ...
            lsqnonlin(@(theta_in) system_sunspot_jacob(theta_in, Rlaggrid,ylaggrid,dgrid,ergrid,zgrid,ggrid,sgrid,PSI, M), theta_old,[],[],options_use_jacob);
            
            % Uncomment if using mex code
            % lsqnonlin(@(theta_in) system_sunspot_jacob_mex(theta_in, PSI ,GRID, WEIGHT, EXO), theta_old,[],[],options_use_jacob);

            time = toc;
 
            jacob = full(jacobian);                                    
    else
        
        fprintf('\n **** The simulate/solve procedure seems to have converged, skipping this step *** \n');
        theta_use = theta_old;
        
    end
    
    ssr_old = norm(system_sunspot_jacob(theta_use, Rlaggrid,ylaggrid,dgrid,ergrid,zgrid,ggrid,sgrid,PSI, M))^2;

    % Uncomment if using mex code
    % ssr_old = norm(system_sunspot_jacob_mex(theta_use, PSI, GRID, WEIGHT, EXO))^2;

    fprintf('\n **** Done solving - Order %i - Iteration %i.\n', order, iter_count);
    
    THETA.(label{iter_count}) = theta_use;
    RESID.(label{iter_count}) = res_use;
    TIME.(label{iter_count})  = time;
    SIM.(label{iter_count})   = simulate_sunspot(theta_use,shocks,init_sun,Tsim,Tdrop,SUNSPOT);
    JACOB.(label{iter_count}) = jacob;      

    
    infl = (SIM.(label{iter_count}).pi-1)*400;
    R    = (SIM.(label{iter_count}).R-1)*400;
    sun  = SIM.(label{iter_count}).SUN;
    
    disp('Inflation');
    disp(sprintf('S = 0, mean(pi) = , %4.4f', mean(infl(sun==0))));
    disp(sprintf('S = 1, mean(pi) = , %4.4f', mean(infl(sun==1))));
    
    theta_old = theta_use;
    time_keep = time_keep + time;
    fprintf('\n Done with Iteration = %i \n', iter_count);
    
    
end


% **** COMPUTE EULER ERRORS **** %

fprintf('\n Over the Ergodic Distribution')

simeval(:,1) = SIM.(label{iter_count}).R(1:Tsim-1,1);     % R_lag;
simeval(:,2) = SIM.(label{iter_count}).y(1:Tsim-1,1);     % y_lag;
simeval(:,3) = SIM.(label{iter_count}).d(2:Tsim,1);       % d
simeval(:,4) = SIM.(label{iter_count}).er(2:Tsim,1);      % er
simeval(:,5) = SIM.(label{iter_count}).z(2:Tsim,1);       % z
simeval(:,6) = SIM.(label{iter_count}).g(2:Tsim,1);       % g
simeval(:,7) = SIM.(label{iter_count}).SUN(2:Tsim,1);     % s

[ERGODICTEMP, EVAL, CINDEXTEMP] = tsga_grid(simeval,Npoints);

[ERROR1.(label{iter_count}), ERROR2.(label{iter_count}), OUT ] = euler_error(theta_use, EVAL, Q2);

fprintf('\n Over the Solution Grid')

[ERROR1_SOL.(label{iter_count}), ERROR2_SOL.(label{iter_count}), OUT_SOL] = euler_error(theta_use, EVAL_SOL, Q2);


