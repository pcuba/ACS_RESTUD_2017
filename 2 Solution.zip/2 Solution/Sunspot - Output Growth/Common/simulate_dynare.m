%==========================================================================
% Function the simulates the model using Dynare decision rules of NK model
% with output growth rule and discount factor shocks
%
% 
% Updated: 02/12/2015
%==========================================================================
function outsim = simulate_dynare(shocks_in,init,T,Tdrop)

global ncoefs oo_
global par;

gamma = par.gamma;
gstar = par.gstar;
rho_z = par.rho_z;
rho_g = par.rho_g;
rho_d = par.rho_d;

%---------------------
% Housekeeping
%---------------------

[~, alpha0, alpha_R, alpha_y, alpha_d, alpha_er, alpha_z, alpha_g] = dr_dynare(oo_, ncoefs);      

T_total = T + Tdrop;

cs  = zeros(T_total,1);      % Preallocate vector that will
pis = zeros(T_total,1);      % carry the simulations
ys  = zeros(T_total,1);
Rs  = zeros(T_total,1);
ers = zeros(T_total,1);
ds  = zeros(T_total,1);
zs  = zeros(T_total,1);
gs  = zeros(T_total,1);
ee1s= zeros(T_total,1);
CCs = zeros(T_total,1);
YYs = zeros(T_total,1);
As  = zeros(T_total,1);
delys= zeros(T_total,1);
delcs= zeros(T_total,1);

er_in = shocks_in.er;
eg_in = shocks_in.eg;
ez_in = shocks_in.ez;
ed_in = shocks_in.ed;


for i = 1 : T_total
    
    if i == 1
        R_lag = init.Rlag;
        y_lag = init.ylag;     
        c_lag = init.clag;
        d_lag = init.dlag;
        z_lag = init.zlag;
        g_lag = init.glag;
        A_lag = init.Alag;
    else       
        R_lag = Rs(i-1);
        y_lag = ys(i-1);
        c_lag = cs(i-1);
        d_lag = ds(i-1);
        z_lag = zs(i-1);
        g_lag = gs(i-1);
        A_lag = As(i-1);
    end

    ds(i) = rho_d*d_lag + ed_in(i);
    zs(i) = rho_z*z_lag + ez_in(i);
    gs(i) = (1-rho_g)*log(gstar) + rho_g*g_lag + eg_in(i);
    As(i) = gamma*A_lag*exp(zs(i));
    
    ers(i)   = er_in(i);
    
    cs(i)   = alpha0(1) +  alpha_R(1)*R_lag +  alpha_y(1)*y_lag + alpha_d(1)*ds(i) + alpha_er(1)*ers(i) + alpha_z(1)*zs(i) + alpha_g(1)*gs(i);
    
    pis(i)  = alpha0(3) +  alpha_R(3)*R_lag +  alpha_y(3)*y_lag + alpha_d(3)*ds(i) + alpha_er(3)*ers(i) + alpha_z(3)*zs(i) + alpha_g(3)*gs(i);
    
    ys(i)   = alpha0(4) +  alpha_R(4)*R_lag +  alpha_y(4)*y_lag + alpha_d(4)*ds(i) + alpha_er(4)*ers(i) + alpha_z(4)*zs(i) + alpha_g(4)*gs(i);
    
    Rs(i)   = alpha0(5) +  alpha_R(5)*R_lag +  alpha_y(5)*y_lag + alpha_d(5)*ds(i) + alpha_er(5)*ers(i) + alpha_z(5)*zs(i) + alpha_g(5)*gs(i);
    
    ee1s(i) = alpha0(6) +  alpha_R(6)*R_lag +  alpha_y(6)*y_lag + alpha_d(6)*ds(i) + alpha_er(6)*ers(i) + alpha_z(6)*zs(i) + alpha_g(6)*gs(i);
       
    % Output growth
    delys(i) = 400 * log(gamma *exp(zs(i)) * ys(i) / y_lag);
    delcs(i) = 400 * log(gamma *exp(zs(i)) * cs(i) / c_lag);

    % Construct level variables % 
    if As(i) < 1E11;    
        CCs(i)= cs(i)*As(i);
        YYs(i)= ys(i)*As(i);
    else
        CCs(i)= NaN;
        YYs(i)= NaN;
    end
    
end

% Trim simulation and output results

outsim.pi  = pis(Tdrop+1:end);
outsim.R   = Rs(Tdrop+1:end);
outsim.c   = cs(Tdrop+1:end);
outsim.y   = ys(Tdrop+1:end);
outsim.ee1 = ee1s(Tdrop+1:end);
outsim.d   = ds(Tdrop+1:end);
outsim.er  = ers(Tdrop+1:end);
outsim.z   = zs(Tdrop+1:end);
outsim.g   = gs(Tdrop+1:end);
outsim.BIGC= CCs(Tdrop+1:end);
outsim.BIGY= YYs(Tdrop+1:end);
outsim.A   = As(Tdrop+1:end);
outsim.dely= delys(Tdrop+1:end);
outsim.delc= delcs(Tdrop+1:end);




