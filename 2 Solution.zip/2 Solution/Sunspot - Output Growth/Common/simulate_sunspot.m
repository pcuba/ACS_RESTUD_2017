%==========================================================================
%                       REPLICATION FILE FOR
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide) 
%
% This function simulates the Sunspot Model with output growth rule
%
% Inputs:
%           theta_in:   vector of coefficients from model solution.
%           shocks_in:  structure with exogenous shocks
%           init:       structure with initial values for simulation
%           T:          number of simulations
%           Tdrop:      burn-in period
%           SUN:        vector containing sunspot variable
%
% Updates:
%         RH, 01/29/2015
%         PC, 02/17/2015
%         BA, 03/13/2015
%==========================================================================


function outsim = simulate_sunspot(theta_in,shocks_in,init,T,Tdrop,SUN)

global bad_sim_flag Rbar

global par ncoefs

%--------------------------------------------------------------------------
% Map Parameters
%--------------------------------------------------------------------------

phi    = par.phi;
tau    = par.tau;
nu     = par.nu;
eta    = par.eta;
psi1   = par.psi1;
psi2   = par.psi2;
beta   = par.beta;
gamma  = par.gamma;
pi_ss  = par.pi_ss;
pibar  = par.pibar;
gstar  = par.gstar;
rho_z  = par.rho_z;
rho_g  = par.rho_g;
r      = par.r;
rho_R  = par.rho_R;
rho_d  = par.rho_d;
chi_h  = par.chi_h;

%--------------------------------------------------------------------------
% Map Coefficients
%--------------------------------------------------------------------------
theta_ee1_1_1 = theta_in(1:ncoefs,1);             % 1 state THETA / NON ZLB
theta_pi_1_1  = theta_in(ncoefs+1:2*ncoefs,1);

theta_ee1_1_2 = theta_in(2*ncoefs+1:3*ncoefs,1);  % 1 state THETA / ZLB
theta_pi_1_2  = theta_in(3*ncoefs+1:4*ncoefs,1);

theta_ee1_0_1 = theta_in(4*ncoefs+1:5*ncoefs,1);  % 0 state THETA / NON ZLB
theta_pi_0_1  = theta_in(5*ncoefs+1:6*ncoefs,1);
  
theta_ee1_0_2 = theta_in(6*ncoefs+1:7*ncoefs,1);  % 0 state THETA / ZLB
theta_pi_0_2  = theta_in(7*ncoefs+1:8*ncoefs,1);
%--------------------------------------------------------------------------
%   Preallocate vectors
%--------------------------------------------------------------------------
TT = T + Tdrop;                                   % Total # of observations

ys  = zeros(TT,1);
Rstars = zeros(TT,1);
cs  = zeros(TT,1);
hs  = zeros(TT,1);
ws  = zeros(TT,1);
pis = zeros(TT,1);
Rs  = zeros(TT,1);
zs  = zeros(TT,1);
gs  = zeros(TT,1);
ds  = zeros(TT,1);
ee1s= zeros(TT,1);
CCs = zeros(TT,1);
YYs = zeros(TT,1);
GGs = zeros(TT,1);
As  = zeros(TT,1);
delys = zeros(TT,1);
delcs = zeros(TT,1);

%--------------------------------------------------------------------------
% Map shocks
%--------------------------------------------------------------------------

ers = shocks_in.er;
egs = shocks_in.eg;
ezs = shocks_in.ez;
eds = shocks_in.ed;

%--------------------------------------------------------------------------
% Define Rbar for ZLB check
%--------------------------------------------------------------------------

if length(Rbar)==1
    Rbar_use = ones(TT,1)*Rbar;
elseif length(Rbar)==TT
    Rbar_use = Rbar;
else
    error('Not enouth observations in Rbar');
end

%--------------------------------------------------------------------------
%   Main Simulation Code
%--------------------------------------------------------------------------

for i = 1 : TT
%     if i == 2181
%         keyboard;
%     end
    
    if i == 1
        
        R_lag = init.Rlag;
        y_lag = init.ylag;
        c_lag = init.clag;
        d_lag = init.dlag;
        z_lag = init.zlag;
        g_lag = init.glag;
        A_lag = init.Alag;
        
    else
        
        R_lag = Rs(i-1);
        y_lag = ys(i-1);
        c_lag = cs(i-1);
        d_lag = ds(i-1);
        z_lag = zs(i-1);
        g_lag = gs(i-1);
        A_lag = As(i-1);
        
    end
    
    ds(i)   = rho_d*d_lag + eds(i);
    zs(i)   = rho_z*z_lag + ezs(i);
    gs(i)   = (1-rho_g)*log(gstar) + rho_g*g_lag + egs(i);
    As(i)   = gamma*A_lag*exp(zs(i));
    
    % Basis Function %
    try
        PSI_use = basis_temp(R_lag, y_lag, ds(i), ers(i), zs(i), gs(i));
    catch
        bad_sim_flag = 1;
        outsim = [];
        fprintf('\n Warning! Bad simulation found in period %i \n',i);
        keyboard
    end
    
    % Assuming ZLB is slack -- use "1" decision rules
    if SUN(i,1) == 1        % s=1 --> STAR
        ee1s(i) = PSI_use'*theta_ee1_1_1;
        pis(i)  = PSI_use'*theta_pi_1_1;
    else                    % s=0 --> TILDE
        ee1s(i) = PSI_use'*theta_ee1_0_1;
        pis(i)  = PSI_use'*theta_pi_0_1;
    end
            
    % Assume ZLB is slack
    temp    =   ((r*pi_ss*((pis(i)/pi_ss)^psi1)*((exp(zs(i))/y_lag)^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(ers(i));         
    ys(i)   = ( (beta*ee1s(i)*temp) / (((1/exp(gs(i))) - 0.5*phi*(pis(i) - pibar)^2)^(-tau)) )^(-1/(tau + psi2*(1-rho_R)));
    Rstars(i) = ((r*pi_ss*((pis(i)/pi_ss)^psi1)*(((ys(i)/y_lag)*exp(zs(i)))^psi2))^(1-rho_R))*((R_lag)^rho_R)*exp(ers(i));            
    Rs(i)   = Rstars(i);
    
    % Check ZLB %
    if Rs(i) >  Rbar_use(i);
        
        cs(i) = (beta*Rs(i)*ee1s(i))^(-1/tau);
        
    else    % Then use the "2" decision rules
        
        Rs(i) = 1;
        if SUN(i,1) == 1        % s=1 --> STAR
            ee1s(i) = PSI_use'*theta_ee1_1_2;
            pis(i)  = PSI_use'*theta_pi_1_2;
        else                    % s=0 --> TILDE
            ee1s(i) = PSI_use'*theta_ee1_0_2;
            pis(i)  = PSI_use'*theta_pi_0_2;
        end
        
        cs(i) = (beta*Rs(i)*ee1s(i))^(-1/tau);
        ys(i) = cs(i) / ((1/exp(gs(i))) - 0.5*phi*(pis(i) - pibar)^2);
        
    end
    
    delys(i) = 400 * log(gamma *exp(zs(i)) * ys(i) / y_lag);  
    delcs(i) = 400 * log(gamma *exp(zs(i)) * cs(i) / c_lag);
   
    % Construct level variables %
    if As(i) < 1E11;
        
        CCs(i) = cs(i)*As(i);
        YYs(i) = ys(i)*As(i);
        GGs(i) = (1 - (1/exp(gs(i)))) * YYs(i);
        
    else
        
        CCs(i)= NaN;
        YYs(i)= NaN;
        GGs(i)= NaN;
    end
    
    % Additional objects
    hs(i) = ys(i);
    ws(i) = chi_h*(ys(i)^(1/eta))*cs(i)^tau;
    
    % Check for errors %
    if cs(i)<0 || ys(i)<0;
        fprintf('\n ys(i) or cs(i) < 0 %5i \n',i);
        keyboard;
    end
    
    if isreal(pis(i))==0;
        fprintf('\n Inflation is imaginary in period %5i \n',i);
        keyboard;
        %        error('Error');
    end
    
end

%--------------------------------------------------------------------------
% Trim simulation and output results
%--------------------------------------------------------------------------

outsim.pi    = pis(Tdrop+1:T+Tdrop);
outsim.R     = Rs(Tdrop+1:T+Tdrop);
outsim.Rstar = Rstars(Tdrop+1:T+Tdrop);
outsim.y     = ys(Tdrop+1:T+Tdrop);
outsim.c   = cs(Tdrop+1:T+Tdrop);
outsim.h   = hs(Tdrop+1:T+Tdrop);
outsim.w   = ws(Tdrop+1:T+Tdrop);
outsim.ee1 = ee1s(Tdrop+1:T+Tdrop);
outsim.er  = ers(Tdrop+1:T+Tdrop);
outsim.eg  = egs(Tdrop+1:T+Tdrop);
outsim.ez  = ezs(Tdrop+1:T+Tdrop);
outsim.ed  = eds(Tdrop+1:T+Tdrop);
outsim.d   = ds(Tdrop+1:T+Tdrop);
outsim.z   = zs(Tdrop+1:T+Tdrop);
outsim.g   = gs(Tdrop+1:T+Tdrop);
outsim.BIGC= CCs(Tdrop+1:T+Tdrop);
outsim.BIGY= YYs(Tdrop+1:T+Tdrop);
outsim.BIGG= GGs(Tdrop+1:T+Tdrop);
outsim.A   = As(Tdrop+1:T+Tdrop);
outsim.SUN = SUN(Tdrop+1:T+Tdrop);
outsim.dely= delys(Tdrop+1:T+Tdrop);
outsim.delc= delcs(Tdrop+1:T+Tdrop);

% Get lagged simulations of endogenous states %

if Tdrop==0
    outsim.Rlag(1,1)= init.Rlag;
    outsim.ylag(1,1)= init.ylag;
    outsim.clag(1,1)= init.clag;
    outsim.Rlag(2:TT,1)=Rs(1:end-1);
    outsim.ylag(2:TT,1)=ys(1:end-1);
    outsim.clag(2:TT,1)=cs(1:end-1);
else
    outsim.Rlag= Rs(Tdrop:end-1);
    outsim.ylag= ys(Tdrop:end-1);
    outsim.clag= cs(Tdrop:end-1);
    outsim.SUNlag = SUN(Tdrop:end-1);
end




