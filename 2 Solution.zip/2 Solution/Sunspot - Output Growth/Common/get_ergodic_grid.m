% Function to create grid points from the ergodic set based on a long 
% simulation of the model
% 
% simuse  = Structure containing the simulated endongeous variables.
% Mpoints = Number of grid points to generate from the ergodic set. 
%
% Created: April 18, 2014
% updated: February 12, 2015
%==========================================================================
function [GRID0,GRID1] = get_ergodic_grid(simuse,Mpoints)
global O

% Adjust Simulation
SUN = simuse.SUN(2:end-1);       % s
simuse_new.Rlag = simuse.R(1:end-1);
simuse_new.ylag = simuse.y(1:end-1);
simuse_new.d    = simuse.d(2:end);
simuse_new.er   = simuse.er(2:end);
simuse_new.z    = simuse.z(2:end);
simuse_new.g    = simuse.g(2:end);
simuse_new.SUN  = simuse.SUN(2:end);
simuse_new.R    = simuse.R(2:end);

% s = 1
simtemp1(:,1) = simuse_new.Rlag(SUN==1,1);    % R_lag;
simtemp1(:,2) = simuse_new.ylag(SUN==1,1);    % y_lag;
simtemp1(:,3) = simuse_new.d(SUN==1,1);       % d
simtemp1(:,4) = simuse_new.er(SUN==1,1);      % er
simtemp1(:,5) = simuse_new.z(SUN==1,1);       % z
simtemp1(:,6) = simuse_new.g(SUN==1,1);       % g
simtemp1(:,7) = simuse_new.SUN(SUN==1,1);     % s
%simtemp1(:,8) = simuse.SUN(1:end-1,1);   % s_lag

% s = 0
simtemp0(:,1) = simuse_new.Rlag(SUN==0,1);    % R_lag;
simtemp0(:,2) = simuse_new.ylag(SUN==0,1);    % y_lag;
simtemp0(:,3) = simuse_new.d(SUN==0,1);       % d
simtemp0(:,4) = simuse_new.er(SUN==0,1);      % er
simtemp0(:,5) = simuse_new.z(SUN==0,1);       % z
simtemp0(:,6) = simuse_new.g(SUN==0,1);       % g
simtemp0(:,7) = simuse_new.SUN(SUN==0,1);     % s
%simtemp1(:,8) = simuse.SUN(1:end-1,1);   % s_lag

% simtemp1 = simtemp(simtemp(:,7) == 1,:);
% simtemp0 = simtemp(simtemp(:,7) == 0,:);

[~, GRID1,~] = tsga_grid(simtemp1, (Mpoints)/ 2);

[~, GRID0, ~] = tsga_grid(simtemp0, (Mpoints) / 2);

% if O.ind_params==3
% 
%     % R simulation with s=1
%     simtempR1 = simuse_new.R(SUN==1);
%     
%     % Find all simulations with R==1 for s=1
%     GRID_JP = simtemp1(simtempR1==1,:);
%     
%     [npoints,~] = size(GRID_JP); 
%     fprintf('ZLB grid points with s=1: %i \n',npoints)
% %     if npoints>10
% %     u = rand(npoints,1);
% %         
% %     GRID_JP = GRID_JP(u<0.5,:);
% %     end
%    
% %    GRID1 = [GRID1(1:end-length(GRID_JP),:); GRID_JP];
%     
% end
% 
