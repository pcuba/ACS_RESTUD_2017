% Function to plot up to 5 series
% Modified for Sunspot Code
% Update: October 8, 2012
%==========================================================================

function plot_simulation(SIM1,SIM2,SUNSPOT,lbl1,lbl2,ind_print)

global fname country
global start_plot Tsim_plot
global tag_name

% set the default figure position to be in the upper right
set(0,'defaultFigurePosition',[1353 661 560 420])
set(0,'DefaultAxesColorOrder',[0.1328 0.5430 0.1328;0 0 0.8008;0 0.4 0; 0 .2 1;0.8 0 1]);


%**** PREPARE SERIES ****
T     = Tsim_plot;
xt    = (1:1:T)';
start = start_plot;
end1  = start+T-1;

RR = SIM1.R(start:end1);
YY = SIM1.dely(start:end1);
PI = SIM1.pi(start:end1);
CC = SIM1.delc(start:end1);
GG = (SIM1.g(start:end1) - mean(SIM1.g)) / std(SIM1.g);
ZZ = (SIM1.z(start:end1) - mean(SIM1.z)) / std(SIM1.z);
ER = (SIM1.er(start:end1) - mean(SIM1.er)) / std(SIM1.er);

RR_DYN = SIM2.R(start:end1);
YY_DYN = SIM2.dely(start:end1);
PI_DYN = SIM2.pi(start:end1);
CC_DYN = SIM2.delc(start:end1);

S = SUNSPOT(start:end1);


CORRELATION=[corr(SIM1.R,SIM2.R),corr(SIM1.pi,SIM2.pi),corr(SIM1.dely,SIM2.dely),...
    corr(SIM1.delc,SIM2.delc)];

% CORRELATION_0 = [corr(400*log(SIM1.R(SIM1.SUN==0)),400*log(SIM2.R(SIM2.SUN==0)))...
%     corr(400*log(SIM1.pi(SIM1.SUN==0)),400*log(SIM2.pi(SIM2.SUN==0)))...
%     corr(SIM1.dely(SIM1.SUN==0),SIM2.dely(SIM2.SUN==0))...
%     corr(SIM1.delc(SIM1.SUN==0),SIM2.delc(SIM2.SUN==0))];
% 
% 
% CORRELATION_1 = [corr(400*log(SIM1.R(SIM1.SUN==1)),400*log(SIM2.R(SIM2.SUN==1)))...
%     corr(400*log(SIM1.pi(SIM1.SUN==1)),400*log(SIM2.pi(SIM2.SUN==1)))...
%     corr(SIM1.dely(SIM1.SUN==1),SIM2.dely(SIM2.SUN==1))...
%     corr(SIM1.delc(SIM1.SUN==1),SIM2.delc(SIM2.SUN==1))];
% 
% %%
% CORRELATION_11 = [corr((RR(SIM1.SUN(start:end1)==1)),(RR_DYN(SIM2.SUN(start:end1)==1)))...
%     corr((PI(SIM1.SUN(start:end1)==1)),(PI_DYN(SIM2.SUN(start:end1)==1)))...
%     corr(YY(SIM1.SUN(start:end1)==1),YY_DYN(SIM2.SUN(start:end1)==1))...
%     corr(CC(SIM1.SUN(start:end1)==1),CC_DYN(SIM2.SUN(start:end1)==1))];
%disp(CORRELATION_0');

% **** PLOT SERIES ****
end_bar = [];

if S(1) == 0
    start_bar = 1;
else
    start_bar = [];
end

for j=2:length(S)
    if S(j)==0 && S(j-1)==1
        start_bar = [start_bar,j];
    elseif S(j)==1 && S(j-1)==0
        end_bar = [end_bar,j];
    end
    
    if j == length(S) && S(j) == 0
        end_bar = [end_bar,length(S)];
    end
    
end

%%
clf;
figure(1);
set(figure(1),'PaperType','usletter','PaperOrientation','Landscape','PaperPosition',[0.1 0.1 11 8.5]);
subplot(2,2,1)
hold on
plot(xt,400*(RR-1),'g-','linewidth',2);
plot(xt,400*(RR_DYN-1),'b-','linewidth',2);
plot(xt,zeros(T,1),'k:');
axis tight; ylim([0 10.5]);
shade(start_bar,end_bar,[.8 .8 .8]);
text(80,9.5,['Corr = ' num2str(CORRELATION(1))]);
hold off
title('Nominal Interest Rate (annualized \%)','fontsize',14,'fontweight','bold','Interpreter','Latex')
xlabel('Time','fontsize',12,'Interpreter','Latex')
set(gca,'FontSize',14)
box on
%%
subplot(2,2,2)
hold on
plot(xt,400*(PI-1),'g-','linewidth',2);
plot(xt,400*(PI_DYN-1),'b-','linewidth',2);
plot(xt,zeros(T,1),'k:');
axis tight; ylim([-12 10]);
shade(start_bar,end_bar,[.8 .8 .8]);
text(80,8.5,['Corr = ' num2str(CORRELATION(2))]);
hold off
title('Inflation (annualized \%)','fontsize',14,'fontweight','bold','Interpreter','Latex')
xlabel('Time','fontsize',12,'Interpreter','Latex')
set(gca,'FontSize',14);
box on

subplot(2,2,3)
hold on
plot(xt,YY,'g-','linewidth',2);
plot(xt,YY_DYN,'b-','linewidth',2);
xlim([xt(1),xt(end)]); ylim([-10 10]);
shade(start_bar,end_bar,[.8 .8 .8]);
plot(xt,zeros(T,1),'k:');
text(80,9,['Corr = ' num2str(CORRELATION(3))]);
hold off
title('Output Growth (annualized \%)','fontsize',14,'fontweight','bold','Interpreter','Latex')
xlabel('Time','fontsize',12,'Interpreter','Latex')
set(gca,'FontSize',14)
box on

subplot(2,2,4)
hold on
plot(xt,CC,'g-','linewidth',2);
plot(xt,CC_DYN,'b-','linewidth',2);
xlim([xt(1),xt(end)]); ylim([-10 10]);
shade(start_bar,end_bar,[.8 .8 .8]);
plot(xt,zeros(T,1),'k:');
text(80,9,['Corr = ' num2str(CORRELATION(4))]);
hold off
title('Consumption Growth (annualized \%)','fontsize',14,'fontweight','bold','Interpreter','Latex')
xlabel('Time','fontsize',12,'Interpreter','Latex')
set(gca,'FontSize',14)
box on
suptitle([country ': Simulated Paths Sunspot Equilibrium (Output Growth Model)']);
l1=legend(lbl1,lbl2,'Orientation','Vertical','location','SW'); 
set(l1,'Interpreter','none');

%%
% PRINT FIGURES TO PDF
if ind_print== 1
    figname     = strcat('FIGURES/SIMULATION_',fname,tag_name,'.pdf');
    
    print(figure(1),'-dpdf','-r300',figname);
    
end