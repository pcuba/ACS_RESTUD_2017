% UNDO PARAMTER TRANSFORMATIONS
% Map unconstrained parameters to their respective domains
% param_in is defined over the real line
% =========================================================================
function params_out = setboundsinv(params_in)
params_out(1,1)  = exp(params_in(1));               %R => tau > 0                      
params_out(2,1)  = exp(params_in(2));               %R => kappa > 0
params_out(3,1)  = exp(params_in(3));               %R => psi1 > 0
params_out(4,1)  = exp(params_in(4));               %R => psi2 > 0
params_out(5,1)  = 1/(1+exp(-params_in(5)));        %R => rhor (0,1)
params_out(6,1)  = 1/(1+exp(-params_in(6)));        %R => rhog (0,1)
params_out(7,1)  = 1/(1+exp(-params_in(7)));        %R => rhoz (0,1)
params_out(8,1)  = 1/(1+exp(-params_in(8)));        %R => rhod (0,1)
params_out(9,1)  = exp(params_in(9));               %R => sigr >0      
params_out(10,1)  = exp(params_in(10));             %R => sigg >0      
params_out(11,1)  = exp(params_in(11));             %R => sigz >0      
params_out(12,1) = exp(params_in(12));              %R => sigd >0      

