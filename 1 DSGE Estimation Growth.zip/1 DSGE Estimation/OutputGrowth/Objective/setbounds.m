% MAP PARAMTERS FOR UNCOSTRAINED OPTIMIZATION
% All parameters are mapped from their Domain onto the Real line
% 
%==========================================================================
function beta_out = setbounds(params_in)
                
beta_out(1) = log(params_in(1));            %tau>0      
beta_out(2) = log(params_in(2));            %kappa > 0
beta_out(3) = log(params_in(3));            %psi1 > 0
beta_out(4) = log(params_in(4));            %psi2 > 0
beta_out(5) = -log(1/params_in(5)-1);       %rhor (0,1)
beta_out(6) = -log(1/params_in(6)-1);       %rhog (0,1)
beta_out(7) = -log(1/params_in(7)-1);       %rhoz (0,1)
beta_out(8) = -log(1/params_in(8)-1);       %rhod (0,1)
beta_out(9) = log(params_in(9));            %sigr >0      
beta_out(10) = log(params_in(10));          %sigg >0      
beta_out(11) = log(params_in(11));          %sigz >0      
beta_out(12)= log(params_in(12));           %sigd >0          


