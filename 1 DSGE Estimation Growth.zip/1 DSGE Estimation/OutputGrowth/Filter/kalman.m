function logL = kalman(A,B,H,R,Se,Phi,y,params_in,fixed_in)

% *** NEED TO CHANGE NOTATION ****

%==========================================================================
%                               Kalman Filter
%
%   This Function Implement the Kalman filter for the state space model:
%
%                        y = A + Bts +  u      u N(0,H)
%
%                        s = M + Phi*s(-1) + e   e N(0,Se)
%
%  In the above system, y is an (l*1) vector of observable variables and
%  s is an n*1 vector of latent variables.
%
%  The Input of this function are the state space matrices and a T*l vector
%  of observations for y.
%
%  The Output is:
%   - liki = is a T*1 vector containing p(yt|Yt-1). The first entry is based
%            on the prediction of the state vector at its unconditional
%            mean;
%
% Fixed parameters:
% R_star_an   % (1) Interest Rate Target
% pi_star_an  % (2) Inflation Target
% gamma_qu    % (3) Growth Rate of Output (quarterly)
% cy          % (4) C/Y ratio
% g_star      % (5) Steady state level of government expenditure
% nu          % (6) EOS intermediate goods (markup)
% eta;        % (7) Frisch elasticity
%==========================================================================

% Give name to parameters
tau = params_in(1);

% Compute Data Related Parameters
R_star_an  = fixed_in(1); 
pi_star_an = fixed_in(2); 
gamma_qu   = fixed_in(3); 
cy         = fixed_in(4);
g_star     = fixed_in(5);
nu         = fixed_in(6);
eta        = fixed_in(7);

% Get Steady State Objects
pi_star = 1+(pi_star_an/400);
gamma = 1+(gamma_qu/100);
r     = 1 + R_star_an/400;
bet   = 1/r;
Rss   = pi_star*gamma/bet;
yss   = ((1 - nu)*g_star^tau)^(1/(tau + 1/eta));
css   = yss / g_star;

% Logged ss=objects
yst   = log(yss);
lnA0  = 0;

% Initial level of output
lnY_1984Q1 = y(1,1);

% Remove 1984Q1 observation from data
y = y(2:end,1:4);

% Initialize the State Vector at the Stationary Distribution
[T,l] = size(y);
[~,ns] = size(Phi);
s = zeros(T+1,ns);
P = zeros(T+1,ns,ns);
s(1,:) = zeros(ns,1)';

% Initialize Filter Solving Lyapunov Equation (Only for stationary
% variables:
stvar = 1:ns-1;
a  = inv(eye((ns-1)*(ns-1)) - kron(Phi(stvar,stvar),Phi(stvar,stvar)))*reshape(R(stvar,:)*Se*R(stvar,:)',(ns-1)*(ns-1),1);
P(1,1:ns-1,1:ns-1) = reshape(a,ns-1,ns-1);

% Initilize lnA(0)
s(1,end) = lnY_1984Q1 - yst -lnA0;

% Kalman Filter Recursion
errorprediction    = ones(T,l);
Varerrorprediction = ones(T,l,l);
liki               = ones(T,1);

for i=1:T
    
    % Updating Step
    sprime = Phi*s(i,:)';
    Pprime = Phi*squeeze(P(i,:,:))*Phi' + R*Se*R';
    
    % Prediction Step
    
    yprediction = (A + B*sprime + [log(gamma); 0; 0; 0]*i);
    
    v = y(i,:)' - yprediction;
    
    F = B*Pprime*B' + H;
    
    %[r,p] = chol(F);
    
    %if p>0
    %    liki(i)=-100;
    %else
    
    kgain    = Pprime*B'*inv(F);
    s(i+1,:) = (sprime + kgain*v)';
    P(i+1,:,:) = Pprime - kgain*B*Pprime;
    errorprediction(i,:) = v';
    Varerrorprediction(i,:,:) = F;
    liki(i) = -0.5*l*log(2*pi) - 0.5*log(det(F)) - 0.5*v'*inv(F)*v;
end

logL = sum(liki);

end
