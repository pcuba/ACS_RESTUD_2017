function [A,B,H,M,Phi,R,Se]=sysstatespace(dr,params_in,fixed_in)

%*** INPUTS ***:
%  dr     = Dynare structure containing decision rules
%  params = Vector of structural parameters:
%
%   1)tau  2)kap  3)rhor 4)rhog 5)rhoz 6) rhod
%   7)sigr 8)sigg 9)sigz 10) sigd 
%
%*** OUTPUTS ***:
%
% The State Space System has the form:
%
%  S(t+1) = M + Phi*S(t) + R*eta(t+1)    eta~N(0,Se)
%  Y(t)   = A + B*S(t)   + eps(t)        eps~N(0,H)
%
% FIXED PARAMETERS
% R_star_an   % (1) Interest Rate Target
% pi_star_an  % (2) Inflation Target
% gamma_qu    % (3) Growth Rate of Output (quarterly)
% cy          % (4) C/Y ratio
% g_star      % (5) Steady state level of government expenditure
% nu          % (6) EOS intermediate goods (markup)
% eta;        % (7) Frisch elasticity
%--------------------------------------------------------------------------

% Give name to parameters
tau = params_in(1);

% Compute Data Related Parameters
R_star_an  = fixed_in(1); 
pi_star_an = fixed_in(2); 
gamma_qu   = fixed_in(3); 
cy         = fixed_in(4);
g_star     = fixed_in(5);
nu         = fixed_in(6);
eta        = fixed_in(7);

% Get Steady State Objects
pi_star = 1+(pi_star_an/400);
gamma = 1+(gamma_qu/100);
r     = 1 + R_star_an/400;
bet   = 1/r;
Rss   = pi_star*gamma/bet;
yss   = ((1 - nu)*g_star^tau)^(1/(tau + 1/eta));
css   = yss / g_star;

% Logged ss-objects
cst = log(css);
yst = log(yss);

% Scaling of lnA0
lnA0= 0;            


% Declare Size of Matrices
[nendo, nstates] = size(dr.ghx);

[~, nexo] = size(dr.ghu);

% Initialize Matrices
M   = zeros(nendo,1);
Phi = zeros(nendo,nendo);
R   = zeros(nendo,nexo);
%Se = zeros(nexo,nexo);

% Construction of State Equation Objects
Phi(:,1:nstates) = dr.ghx(dr.inv_order_var,:);
R(:,:) = dr.ghu(dr.inv_order_var,:);

% Covariance structural shocks
Se = eye(nexo);

%==========================================================================
% Augmentation of State Space to track the level of A
% X(t+1) = TT*X(t) + RR*eta(t+1)
%
% Where X(t) = [S(t) A(t)]' and S(t+1) = Phi*S(t) + R*eta(t+1)
%==========================================================================

% Allocate TT
TT = zeros(nendo+1,nendo+1);

% Assign stationary states
TT(1:nendo,1:nendo) = Phi;

% Augment with the transition equation for A(t) = A(t-1) + z(t) 
TT(nendo+1,nendo+1) = 1;    % This is for A(-1)
TT(nendo+1,3) = Phi(3,3);   % This is for z(-1) 

% Allocate RR
RR = zeros(nendo+1,nexo);
RR(1:nendo,:) = R;
RR(nendo+1,:) =  R(3,:);    % This is for ez

%==========================================================================
% Construct Measurement Equation Objects
%  y = A + B*s(t) +  u      u N(0,H)
%  The states are:      s(t) = [R	g	z	d	y	c	infl]'
%  The observables are: y(t) = [logY logCY infl_obs R_obs]'
%==========================================================================

B   = zeros(nexo,nendo+1);

A(1,1) = lnA0 + yst;
A(2,1) = 100*(cst - yst);
A(3,1) = 400*log(pi_star);
A(4,1) = 400*log(Rss);

B(1,:) = [0   0  0  0     1    0   0  1];
B(2,:) = [0   0  0  0  -100  100   0  0];
B(3,:) = [0   0  0  0     0    0 400  0];
B(4,:) = [400 0  0  0     0    0   0  0];

H = zeros(4,4);

%  Output matrices
Phi = TT;
R = RR;


end