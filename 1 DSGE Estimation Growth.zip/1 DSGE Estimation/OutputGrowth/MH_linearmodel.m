%==========================================================================
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
%     DSGE MODEL ESTIMATION: RWM Algorithm of An and Schorfheide (2007)
%
%               logcy2 is C = Y - G, with G coming
%               from National Accounts data. [08/02/2016]
%
%               Prior table is now read from Mhcandidate.mat to make sure
%               the priors are the same as the ones used to estimate the
%               posterior mode.[08/04/2016]
%==========================================================================

clear all; clc; close all;
delete *.~m; delete *.asv;

addpath 'Matfiles';
addpath 'Objective';
addpath 'Filter';

global error_flag PRIORTABLE

%=========================================================================
%                              USER OPTIONS
%=========================================================================

% Define Objects for MH Algorithm

Nsim = 100000;                 % Number of Posterior Draws

c1   = 0.5;                    % Scaling of variance-covariance matrix

Burnin = 50000;                % Draws for burn-in period

%--------------------------------------------------------------------------
%                    RUN DYNARE TO INITIALIZE OBJECTS
%--------------------------------------------------------------------------

% LOAD POSTERIOR MODE
load Mhcandidate.mat
params0 = mode;

% CALL DYNARE
dynare ACS_OutputGrowth_loglinear.mod noclearall

% CLEAR OBJECTS
clearvars -except oo_ M_ options_ error_flag Nsim c1 Burnin Sigma mode paramsfixed PRIORTABLE

% INITIALIZE ERROR FLAG CHECK
error_flag = 0;

% LOAD DATA
load data_us_estimation_restud_revision2.mat logy logcy2 infl_obs R_obs

data_in = [logy logcy2 infl_obs R_obs];

tic

%=========================================================================
%                     HOUSEKEEPING AND CANDIDATE DENSITY
%=========================================================================
npar = length(mode);

Thetasim        = zeros(npar,Nsim);    % Posterior Draws

logposterior    = zeros(Nsim,1);       % Log posterior density

accept          = 0;                   % Accepted draws of MH Algorithm

counter         = 1;                   % Counter


%=========================================================================
%                   METROPOLIS-HASTINGS ALGORITHM
%=========================================================================
% Set Seed for Random Number Generator
rng(72256)

% Initialize the MH Algorithm at posterior mode
Thetasim(:,1)   = mode;

obj = DSGE_linearized(mode,paramsfixed,data_in,0);

for i=2:Nsim

    % Sample a proposal
    Thetacand = mvnrnd(Thetasim(:,i-1),(c1^2)*Sigma);

    % Compute prior at proposal draw
    prioc   = prior(Thetacand');

    % Check prior
    if prioc==-Inf
        Thetasim(:,i) = Thetasim(:,i-1);
    else

        % Evaluate log posterior at proposed draw
        objcand  = DSGE_linearized(Thetacand',paramsfixed,data_in,0);

        % Evaluate MH acceptance probability
        alpha    = min(1,exp(objcand-obj));

        u = rand(1);

        if u<=alpha
            Thetasim(:,i)       = Thetacand';
            accept              = accept+1;
            obj                 = objcand;

        else

            Thetasim(:,i)       = Thetasim(:,i-1);

        end
    end

    logposterior(i)    = obj;
    acceptancerate     = accept/i;

    if floor(i/10000)==counter;
        disp('                                                                  ');
        disp(['                               DRAW NUMBER:', num2str(i)]         );
        disp('                                                                  ');
        disp('                                                                  ');
        disp(['                           ACCEPTANCE RATE:', num2str(acceptancerate)]);
        disp('                                                                  ');
        disp('                                                                  ');

        % Save intermediate results
%         save Matfiles/draws_linearmodel_growth.mat Thetasim ...
%         acceptancerate logposterior

        counter = counter + 1;
    end

end

elapsed_time = toc;


%=========================================================================
%                   DISPLAY AND SAVE RESULTS
%=========================================================================

fprintf('\n Priors from ACS (2017)  - REStud \n');
disp(PRIORTABLE);
disp(' ');


disp('                                                                  ');
disp('                   PARAMETER VALUES AT POSTERIOR  MEAN             ');
disp('                                                                  ');
disp('   TAU       KAPPA      PSI1      PSI2      RHOr       RHOg       RHOz      RHOd');
disp(num2str(mean(Thetasim(1:8,Burnin+1:end),2)'))
disp('                                                                  ');
disp('                                                                  ');
disp('   Sigr        Sigg        Sigz       Sigd');
disp(num2str(mean(Thetasim(9:12,Burnin+1:end),2)'))
disp('                                                                  ');

fprintf('\n Elapsed time (min) = %4.4f \n', elapsed_time/60);
fprintf('\n Kept observations %i to %i from Chain.', Burnin,Nsim);

disp(' DONE!!!')

%% FIXED PARAMETERS AND PARAMETER NAMES
fixed = M_.params(13:end);
pnames = M_.param_names;
pnamescell = cellstr(pnames)
%% STORE POSTERIOR STATISTICS OF ESTIMATED PARAMETERS AND FIXED PARAMS
pmean = mean(Thetasim(:,Burnin+1:end),2);
hpd5  = prctile(Thetasim(:,Burnin+1:end)',5)';
hpd95 = prctile(Thetasim(:,Burnin+1:end)',95)';

fprintf('==================================================== \n');
fprintf('             ESTIMATED PARAMETERS \n');
fprintf('==================================================== \n');
T1 = table(pmean, hpd5, hpd95,'RowNames',pnamescell(1:12));
disp(T1);

fprintf('==================================================== \n');
fprintf('             FIXED PARAMETERS \n');
fprintf('==================================================== \n');
T2 = table(fixed,'RowNames',pnamescell(13:end));
disp(T2)
% disp([pmean hpd5 hpd95]);
% disp(fixed);

%% SAVE TO MATFILE
% save Matfiles/draws_linearmodel_growth.mat Thetasim acceptancerate ...
%     logposterior c1 obj elapsed_time  pnames pmean hpd5 hpd95 fixed PRIORTABLE T1 T2

%% PRINT PARAMETERS FOR NON-LINEAR SOLUTION FILE
pnames=cellstr(pnames);

fprintf('==================================================== \n');
fprintf('        PARAMETERS FOR SOLUTION CODE \n');
fprintf('==================================================== \n');

for n=1:length(pmean)
fprintf('%s \t = %4.6f; \n',char(pnames(n)),pmean(n))
end
%% DELETE AUXILIARY FILES
movefile('ACS_OutputGrowth_loglinear*.m','ACS_OutputGrowth_loglinear');
movefile('ACS_OutputGrowth_loglinear*.mat','ACS_OutputGrowth_loglinear');
movefile('ACS_OutputGrowth_loglinear*.log','ACS_OutputGrowth_loglinear');
