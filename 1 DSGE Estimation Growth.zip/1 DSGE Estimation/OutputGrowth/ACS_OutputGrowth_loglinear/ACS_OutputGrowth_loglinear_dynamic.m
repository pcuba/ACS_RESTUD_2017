function [residual, g1, g2, g3] = ACS_OutputGrowth_loglinear_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           rows: equations in order of declaration
%                                                           columns: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(7, 1);
pi_star__ = 1+params(14)/400;
bet__ = 400/(400+params(13));
phi__ = params(1)*(1-params(18))/(params(18)*pi_star__^2*params(2));
pibar__ = pi_star__;
b__ = 1-1/(2*params(18));
yss__ = ((1-params(18))*params(17)^params(1))^(1/(params(1)+1/params(19)));
css__ = yss__/params(17);
cst__ = log(css__);
yst__ = log(yss__);
pst__ = log(pi_star__);
gst__ = log(params(17));
T62 = exp((-params(1))*(y(16)-y(11))+y(14)-y(9)-y(13)+y(6)-y(17));
T73 = exp(params(1)*(y(11)+cst__)+1/params(19)*(y(10)+yst__));
T100 = exp(pst__+y(17)+y(14)+(-params(1))*(y(16)-y(11))+y(15)-y(10)-y(9));
T105 = phi__*bet__*T100*(exp(y(17)+pst__)-pibar__);
T142 = exp(params(5)*y(1)+y(12)*(1-params(5))*params(3)+(1-params(5))*params(4)*(y(10)-y(5)+y(8))+params(9)*x(it_, 4));
lhs =1;
rhs =T62;
residual(1)= lhs-rhs;
lhs =1;
rhs =1/params(18)*(1-T73)+phi__*(exp(y(12)+pst__)-pibar__)*(exp(y(12)+pst__)*b__+pibar__*(1-b__))-T105;
residual(2)= lhs-rhs;
lhs =exp(y(11)+cst__-y(10)-yst__);
rhs =exp((-y(7))-gst__)-phi__/2*(exp(y(12)+pst__)-pibar__)^2;
residual(3)= lhs-rhs;
lhs =exp(y(6));
rhs =T142;
residual(4)= lhs-rhs;
lhs =y(7);
rhs =params(6)*y(2)+params(10)*x(it_, 2);
residual(5)= lhs-rhs;
lhs =y(8);
rhs =params(7)*y(3)+params(11)*x(it_, 1);
residual(6)= lhs-rhs;
lhs =y(9);
rhs =params(8)*y(4)+params(12)*x(it_, 3);
residual(7)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(7, 21);

  %
  % Jacobian matrix
  %

  g1(1,6)=(-T62);
  g1(1,13)=T62;
  g1(1,9)=T62;
  g1(1,14)=(-T62);
  g1(1,11)=(-(params(1)*T62));
  g1(1,16)=(-((-params(1))*T62));
  g1(1,17)=T62;
  g1(2,9)=phi__*bet__*(exp(y(17)+pst__)-pibar__)*(-T100);
  g1(2,14)=T105;
  g1(2,10)=(-(1/params(18)*(-(1/params(19)*T73))-phi__*bet__*(exp(y(17)+pst__)-pibar__)*(-T100)));
  g1(2,15)=T105;
  g1(2,11)=(-(1/params(18)*(-(params(1)*T73))-phi__*bet__*(exp(y(17)+pst__)-pibar__)*params(1)*T100));
  g1(2,16)=phi__*bet__*(exp(y(17)+pst__)-pibar__)*(-params(1))*T100;
  g1(2,12)=(-((exp(y(12)+pst__)*b__+pibar__*(1-b__))*phi__*exp(y(12)+pst__)+phi__*(exp(y(12)+pst__)-pibar__)*exp(y(12)+pst__)*b__));
  g1(2,17)=phi__*bet__*(T100*(exp(y(17)+pst__)-pibar__)+T100*exp(y(17)+pst__));
  g1(3,7)=exp((-y(7))-gst__);
  g1(3,10)=(-exp(y(11)+cst__-y(10)-yst__));
  g1(3,11)=exp(y(11)+cst__-y(10)-yst__);
  g1(3,12)=phi__/2*exp(y(12)+pst__)*2*(exp(y(12)+pst__)-pibar__);
  g1(4,1)=(-(params(5)*T142));
  g1(4,6)=exp(y(6));
  g1(4,8)=(-((1-params(5))*params(4)*T142));
  g1(4,5)=(-(T142*(-((1-params(5))*params(4)))));
  g1(4,10)=(-((1-params(5))*params(4)*T142));
  g1(4,12)=(-((1-params(5))*params(3)*T142));
  g1(4,21)=(-(params(9)*T142));
  g1(5,2)=(-params(6));
  g1(5,7)=1;
  g1(5,19)=(-params(10));
  g1(6,3)=(-params(7));
  g1(6,8)=1;
  g1(6,18)=(-params(11));
  g1(7,4)=(-params(8));
  g1(7,9)=1;
  g1(7,20)=(-params(12));
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],7,441);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],7,9261);
end
end
