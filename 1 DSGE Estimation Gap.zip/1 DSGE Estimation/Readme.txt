%==========================================================================
%                       REPLICATION INSTRUCTIONS
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% This folder contains sample code for the estimation of the DSGE model described
% in Section 3. See section 5 for data and estimation details.
%
% To run this codes you need to install DYNARE from http://www.dynare.org.
%
% This version: March 15, 2017
%==========================================================================


1. Select the subdirectory containing the desired policy rule specification:
OutputGrowth/
OutputTrendGap/

i)  Data for estimation is stored in Matfiles/.
ii) We use DYNARE to solve for the log-linearized approximation of the DSGE model.
The .mod file is run from Candidate.m and from MH_linearmodel.m (see below)

2. Specify the priors for estimation in the file prior_spec.txt depending on the
model and dataset specification. See Table A-2 and A-3 in the Online Appendix for
details.

3. Run Candidate.m

4. Run MH_linearmodel.m

5. Draws from the posterior are stored in Matfiles/
