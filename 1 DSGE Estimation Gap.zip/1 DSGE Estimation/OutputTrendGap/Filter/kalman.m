function logL = kalman(A,B,H,R,Se,Phi,y,params_in,fixed_in)

%==========================================================================
%                               Kalman Filter
%
%   This Function Implement the Kalman filter for the state space model:
%
%                        y = A + Bts +  u      u N(0,H)
%
%                        s = M + Phi*s(-1) + e   e N(0,Se)
%
%  In the above system, y is an (l*1) vector of observable variables and
%  s is an n*1 vector of latent variables.
%
%  The Input of this function are the state space matrices and a T*l vector
%  of observations for y.
%
%  The Output is:
%   - liki = is a T*1 vector containing p(yt|Yt-1). The first entry is based
%            on the prediction of the state vector at its unconditional
%            mean;
%
%
%==========================================================================


% Give name to parameters
tau = params_in(1);

% Compute Data Related Parameters
R_star_an  = fixed_in(1); 
pi_star_an = fixed_in(2); 
gamma_qu   = fixed_in(3); 
cy         = fixed_in(4);
g_star     = fixed_in(5);
nu         = fixed_in(6);
eta        = fixed_in(7);

% Get Steady State Objects
pi_star = 1+(pi_star_an/400);
gamma = 1+(gamma_qu/100);
r     = 1 + R_star_an/400;
bet   = 1/r;
Rss   = pi_star*gamma/bet;
yss   = ((1 - nu)*g_star^tau)^(1/(tau + 1/eta));
css   = yss / g_star;

% Logged ss-objects
cst = log(css);
yst = log(yss);

% Scaling of lnA0
lnA0= 0;            

% Initial level of output
lnY_1984Q1 = y(1,1);
lnT_1984Q1 = y(1,5);

% Remove 1984Q1 observation from data and keep only the needed observables
ytrend = y(2:end,5);
y = y(2:end,1:4);

% Initialize the State Vector at the Stationary Distribution
% The states are: 
% 1   2   3  4  5  6  7   8    9
% R trend g  z  d  y  c  infl  A

[T,l] = size(y);
[~,ns] = size(Phi);
s = zeros(T+1,ns);
P = zeros(T+1,ns,ns);
s(1,:) = zeros(ns,1)';

% Initialize Filter Solving Lyapunov Equation (Only for stationary
% variables:
stvar = 1:ns-1;
a  = inv(eye((ns-1)*(ns-1)) - kron(Phi(stvar,stvar),Phi(stvar,stvar)))*reshape(R(stvar,:)*Se*R(stvar,:)',(ns-1)*(ns-1),1);
P(1,1:ns-1,1:ns-1) = reshape(a,ns-1,ns-1);

% Initilize lnA(0)
s(1,end) = 0.5*(lnT_1984Q1 - yst -lnA0) + 0.5*(lnY_1984Q1 - yst -lnA0);

% Conditional on A0, compute y and ytrend and treat the y - ytrend
% deviation as as known.
%
% Then condition the distribution of the other states given y and ytrend

% Order y(6) and trend(2)  last; delete A (9)
MM = eye(ns);
MM = MM([1 3 4 5 7 8 6 2],:);

% Compute Mean and Covariance of blck 1 given blck 2 (y and ytrend)
Pt = squeeze(P(1,:,:));
PtMM = MM*Pt*MM';
PtMM11 = PtMM(1:6,1:6);
PtMM21 = PtMM(7:8,1:6);
PtMM12 = PtMM(1:6,7:8);
PtMM22 = PtMM(7:8,7:8);
PtMM1c2 = PtMM11 - PtMM12*inv(PtMM22)*PtMM21;

AtMM1c2 = PtMM12*inv(PtMM22)*([lnY_1984Q1; lnT_1984Q1] - yst - lnA0 - s(1,9));

% Reorder mean and covariance matrix

PtMM = zeros(ns,ns);
PtMM(1:6,1:6) = PtMM1c2;
AtMM = [AtMM1c2; (lnY_1984Q1 - yst - lnA0 - s(1,9)); (lnT_1984Q1 - yst - lnA0 - s(1,9)); s(1,9)];

MMinv = eye(ns);
MMinv = MMinv([1 8 2 3 4 7 5 6 9],:);


% Map the initialization
% The states are: 
% 1   2   3  4  5  6  7   8    9
% R trend g  z  d  y  c  infl  A

s(1,:) = MMinv*AtMM;
P(1,:,:) = MMinv*PtMM*MMinv';

% Kalman Filter Recursion

errorprediction    = ones(T,l);
Varerrorprediction = ones(T,l,l);
liki               = ones(T,1);

for i=1:T
    
    % Updating Step
    sprime = Phi*s(i,:)';
    Pprime = Phi*squeeze(P(i,:,:))*Phi' + R*Se*R';
    
    % Prediction Step
    
    yprediction = (A + B*sprime + [log(gamma); 0; 0 ;0]*i );
    
    v = y(i,:)' - yprediction;
    
    F = B*Pprime*B' + H;
    
    %[r,p] = chol(F);
    
    %if p>0
    %    liki(i)=-100;
    %else
    
    kgain    = Pprime*B'*inv(F);
    s(i+1,:) = (sprime + kgain*v)';
    P(i+1,:,:) = Pprime - kgain*B*Pprime;
    errorprediction(i,:) = v';
    Varerrorprediction(i,:,:) = F;
    liki(i) = -0.5*l*log(2*pi) - 0.5*log(det(F)) - 0.5*v'*inv(F)*v;
   
    
    
end

logL = sum(liki);


end
