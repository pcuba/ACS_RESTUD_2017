%
% Status : main Dynare file 
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

tic;
global M_ oo_ options_ ys0_ ex0_ estimation_info
options_ = [];
M_.fname = 'ACS_OutputTrendGap_loglinear';
%
% Some global variables initialization
%
global_initialization;
diary off;
diary('ACS_OutputTrendGap_loglinear.log');
M_.exo_names = 'e_z';
M_.exo_names_tex = 'e\_z';
M_.exo_names_long = 'e_z';
M_.exo_names = char(M_.exo_names, 'e_g');
M_.exo_names_tex = char(M_.exo_names_tex, 'e\_g');
M_.exo_names_long = char(M_.exo_names_long, 'e_g');
M_.exo_names = char(M_.exo_names, 'e_d');
M_.exo_names_tex = char(M_.exo_names_tex, 'e\_d');
M_.exo_names_long = char(M_.exo_names_long, 'e_d');
M_.exo_names = char(M_.exo_names, 'e_r');
M_.exo_names_tex = char(M_.exo_names_tex, 'e\_r');
M_.exo_names_long = char(M_.exo_names_long, 'e_r');
M_.endo_names = 'R';
M_.endo_names_tex = 'R';
M_.endo_names_long = 'R';
M_.endo_names = char(M_.endo_names, 'trend');
M_.endo_names_tex = char(M_.endo_names_tex, 'trend');
M_.endo_names_long = char(M_.endo_names_long, 'trend');
M_.endo_names = char(M_.endo_names, 'g');
M_.endo_names_tex = char(M_.endo_names_tex, 'g');
M_.endo_names_long = char(M_.endo_names_long, 'g');
M_.endo_names = char(M_.endo_names, 'z');
M_.endo_names_tex = char(M_.endo_names_tex, 'z');
M_.endo_names_long = char(M_.endo_names_long, 'z');
M_.endo_names = char(M_.endo_names, 'd');
M_.endo_names_tex = char(M_.endo_names_tex, 'd');
M_.endo_names_long = char(M_.endo_names_long, 'd');
M_.endo_names = char(M_.endo_names, 'y');
M_.endo_names_tex = char(M_.endo_names_tex, 'y');
M_.endo_names_long = char(M_.endo_names_long, 'y');
M_.endo_names = char(M_.endo_names, 'c');
M_.endo_names_tex = char(M_.endo_names_tex, 'c');
M_.endo_names_long = char(M_.endo_names_long, 'c');
M_.endo_names = char(M_.endo_names, 'infl');
M_.endo_names_tex = char(M_.endo_names_tex, 'infl');
M_.endo_names_long = char(M_.endo_names_long, 'infl');
M_.param_names = 'tau';
M_.param_names_tex = 'tau';
M_.param_names_long = 'tau';
M_.param_names = char(M_.param_names, 'kappa');
M_.param_names_tex = char(M_.param_names_tex, 'kappa');
M_.param_names_long = char(M_.param_names_long, 'kappa');
M_.param_names = char(M_.param_names, 'psi_1');
M_.param_names_tex = char(M_.param_names_tex, 'psi\_1');
M_.param_names_long = char(M_.param_names_long, 'psi_1');
M_.param_names = char(M_.param_names, 'psi_2');
M_.param_names_tex = char(M_.param_names_tex, 'psi\_2');
M_.param_names_long = char(M_.param_names_long, 'psi_2');
M_.param_names = char(M_.param_names, 'rho_r');
M_.param_names_tex = char(M_.param_names_tex, 'rho\_r');
M_.param_names_long = char(M_.param_names_long, 'rho_r');
M_.param_names = char(M_.param_names, 'rho_g');
M_.param_names_tex = char(M_.param_names_tex, 'rho\_g');
M_.param_names_long = char(M_.param_names_long, 'rho_g');
M_.param_names = char(M_.param_names, 'rho_z');
M_.param_names_tex = char(M_.param_names_tex, 'rho\_z');
M_.param_names_long = char(M_.param_names_long, 'rho_z');
M_.param_names = char(M_.param_names, 'rho_d');
M_.param_names_tex = char(M_.param_names_tex, 'rho\_d');
M_.param_names_long = char(M_.param_names_long, 'rho_d');
M_.param_names = char(M_.param_names, 'sigma_r');
M_.param_names_tex = char(M_.param_names_tex, 'sigma\_r');
M_.param_names_long = char(M_.param_names_long, 'sigma_r');
M_.param_names = char(M_.param_names, 'sigma_g');
M_.param_names_tex = char(M_.param_names_tex, 'sigma\_g');
M_.param_names_long = char(M_.param_names_long, 'sigma_g');
M_.param_names = char(M_.param_names, 'sigma_z');
M_.param_names_tex = char(M_.param_names_tex, 'sigma\_z');
M_.param_names_long = char(M_.param_names_long, 'sigma_z');
M_.param_names = char(M_.param_names, 'sigma_d');
M_.param_names_tex = char(M_.param_names_tex, 'sigma\_d');
M_.param_names_long = char(M_.param_names_long, 'sigma_d');
M_.param_names = char(M_.param_names, 'R_star_an');
M_.param_names_tex = char(M_.param_names_tex, 'R\_star\_an');
M_.param_names_long = char(M_.param_names_long, 'R_star_an');
M_.param_names = char(M_.param_names, 'pi_star_an');
M_.param_names_tex = char(M_.param_names_tex, 'pi\_star\_an');
M_.param_names_long = char(M_.param_names_long, 'pi_star_an');
M_.param_names = char(M_.param_names, 'gamma_qu');
M_.param_names_tex = char(M_.param_names_tex, 'gamma\_qu');
M_.param_names_long = char(M_.param_names_long, 'gamma_qu');
M_.param_names = char(M_.param_names, 'cy');
M_.param_names_tex = char(M_.param_names_tex, 'cy');
M_.param_names_long = char(M_.param_names_long, 'cy');
M_.param_names = char(M_.param_names, 'g_star');
M_.param_names_tex = char(M_.param_names_tex, 'g\_star');
M_.param_names_long = char(M_.param_names_long, 'g_star');
M_.param_names = char(M_.param_names, 'nu');
M_.param_names_tex = char(M_.param_names_tex, 'nu');
M_.param_names_long = char(M_.param_names_long, 'nu');
M_.param_names = char(M_.param_names, 'eta');
M_.param_names_tex = char(M_.param_names_tex, 'eta');
M_.param_names_long = char(M_.param_names_long, 'eta');
M_.param_names = char(M_.param_names, 'alp');
M_.param_names_tex = char(M_.param_names_tex, 'alp');
M_.param_names_long = char(M_.param_names_long, 'alp');
M_.exo_det_nbr = 0;
M_.exo_nbr = 4;
M_.endo_nbr = 8;
M_.param_nbr = 20;
M_.orig_endo_nbr = 8;
M_.aux_vars = [];
M_.Sigma_e = zeros(4, 4);
M_.Correlation_matrix = eye(4, 4);
M_.H = 0;
M_.Correlation_matrix_ME = 1;
M_.sigma_e_is_diagonal = 1;
options_.block=0;
options_.bytecode=0;
options_.use_dll=0;
erase_compiled_function('ACS_OutputTrendGap_loglinear_static');
erase_compiled_function('ACS_OutputTrendGap_loglinear_dynamic');
M_.lead_lag_incidence = [
 1 6 0;
 2 7 0;
 3 8 0;
 4 9 14;
 5 10 15;
 0 11 16;
 0 12 17;
 0 13 18;]';
M_.nstatic = 0;
M_.nfwrd   = 3;
M_.npred   = 3;
M_.nboth   = 2;
M_.nsfwrd   = 5;
M_.nspred   = 5;
M_.ndynamic   = 8;
M_.equations_tags = {
};
M_.static_and_dynamic_models_differ = 0;
M_.exo_names_orig_ord = [1:4];
M_.maximum_lag = 1;
M_.maximum_lead = 1;
M_.maximum_endo_lag = 1;
M_.maximum_endo_lead = 1;
oo_.steady_state = zeros(8, 1);
M_.maximum_exo_lag = 0;
M_.maximum_exo_lead = 0;
oo_.exo_steady_state = zeros(4, 1);
M_.params = NaN(20, 1);
M_.NNZDerivatives = zeros(3, 1);
M_.NNZDerivatives(1) = 38;
M_.NNZDerivatives(2) = -1;
M_.NNZDerivatives(3) = -1;
set_param_value('tau',params0(1))
set_param_value('kappa',params0(2))
set_param_value('psi_1',params0(3))
set_param_value('psi_2',params0(4))
set_param_value('rho_r',params0(5))
set_param_value('rho_g',params0(6))
set_param_value('rho_z',params0(7))
set_param_value('rho_d',params0(8))
set_param_value('sigma_r',params0(9))
set_param_value('sigma_g',params0(10))
set_param_value('sigma_z',params0(11))
set_param_value('sigma_d',params0(12))
set_param_value('R_star_an',paramsfixed(1))
set_param_value('pi_star_an',paramsfixed(2))
set_param_value('gamma_qu',paramsfixed(3))
set_param_value('cy',paramsfixed(4))
set_param_value('g_star',paramsfixed(5))
set_param_value('nu',paramsfixed(6))
set_param_value('eta',paramsfixed(7))
set_param_value('alp',paramsfixed(8))
%
% INITVAL instructions
%
options_.initval_file = 0;
oo_.steady_state( 7 ) = 0;
oo_.steady_state( 6 ) = 0;
oo_.steady_state( 8 ) = 0;
oo_.steady_state( 3 ) = 0;
oo_.steady_state( 4 ) = 0;
oo_.steady_state( 5 ) = 0;
oo_.steady_state( 1 ) = 0;
oo_.steady_state( 2 ) = 0;
if M_.exo_nbr > 0;
	oo_.exo_simul = [ones(M_.maximum_lag,1)*oo_.exo_steady_state'];
end;
if M_.exo_det_nbr > 0;
	oo_.exo_det_simul = [ones(M_.maximum_lag,1)*oo_.exo_det_steady_state'];
end;
%
% SHOCKS instructions
%
make_ex_;
M_.exo_det_length = 0;
M_.Sigma_e(1, 1) = (1)^2;
M_.Sigma_e(2, 2) = (1)^2;
M_.Sigma_e(3, 3) = (1)^2;
M_.Sigma_e(4, 4) = (1)^2;
steady;
oo_.dr.eigval = check(M_,options_,oo_);
set_dynare_seed(15315);
options_.drop = 0;
options_.irf = 0;
options_.nograph = 1;
options_.order = 1;
options_.periods = 100000;
var_list_=[];
info = stoch_simul(var_list_);
save('ACS_OutputTrendGap_loglinear_results.mat', 'oo_', 'M_', 'options_');
if exist('estim_params_', 'var') == 1
  save('ACS_OutputTrendGap_loglinear_results.mat', 'estim_params_', '-append');
end
if exist('bayestopt_', 'var') == 1
  save('ACS_OutputTrendGap_loglinear_results.mat', 'bayestopt_', '-append');
end
if exist('dataset_', 'var') == 1
  save('ACS_OutputTrendGap_loglinear_results.mat', 'dataset_', '-append');
end
if exist('estimation_info', 'var') == 1
  save('ACS_OutputTrendGap_loglinear_results.mat', 'estimation_info', '-append');
end


disp(['Total computing time : ' dynsec2hms(toc) ]);
if ~isempty(lastwarn)
  disp('Note: warning(s) encountered in MATLAB/Octave code')
end
diary off
