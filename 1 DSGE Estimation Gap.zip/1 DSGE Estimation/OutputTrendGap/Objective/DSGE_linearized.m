% This Function Evaluates the LogL of a DSGE model after approximating
% its decision rules using Dynare and mapping it into a state-space form
%
%
% Written by: Pablo Cuba-Borda. University of Maryland, College Park.
% Created: January 21, 2014.
% Last Edited: May 25, 2014.
%==========================================================================

function out = DSGE_linearized(params_in,fixed_in,data_in,transform)
global oo_ M_ options_ error_flag


%--------------------------------------------------------------------------
%  1. SOLVE MODEL GIVEN CURRENT GUESS OF STRUC PARAM BETA
%--------------------------------------------------------------------------
if transform==1
    params_in = setboundsinv(params_in);
end


% Map estimated parameters to Dynare Structure
M_.params(1:12) = params_in;

% Map fixed parameters to Dynare Structure
M_.params(13:20) = fixed_in;


% Solve Model Log-Linearized Model
try   
    [dr,info,~,~,~] = resol(0,M_,options_,oo_);
catch
    
    error_flag = 1;
    
    out = -99999999;
    
    return
end


if info ~= 0
    % Check solution
    
    error_flag = 1;
    
    out = -99999999;
    disp('*** Error when solving the model at the proposed parameters ***');
    
    return
    %    error('Error when solving the model at the proposed parameters')
    
end


%--------------------------------------------------------------------------
%  2. ARRANGE STATE-SPACE OBJECTS
%--------------------------------------------------------------------------
[A,B,H,~,Phi,R,Se] = sysstatespace(dr,params_in,fixed_in);

%--------------------------------------------------------------------------
%  3. COMPUTE LIKELIHOOD AT SOLUTION
%--------------------------------------------------------------------------

liki = kalman(A,B,H,R,Se,Phi,data_in,params_in,fixed_in);


%--------------------------------------------------------------------------
%  4. COMPUTE LOG PRIOR
%--------------------------------------------------------------------------
logPrior = prior(params_in);

out = liki + logPrior;

