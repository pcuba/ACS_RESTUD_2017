function [prior] = prior(Theta)

% This function evaluates the log prior of the structural parameters of the
% New Keynesian model in ACS(2017)
%
% Input:  1) Theta:   Vector of structural parameters of NK model
% Output: 1) prior:   Value of log prior at Theta
%--------------------------------------------------------------------------

global PRIORTABLE

% Priors from ACS (2014) -
% Parameter  Density    Param(1)    Param(2)
% tau         Gamma       2.0         0.25
% kappa       Gamma       0.5         0.2
% psi1        Gamma       1.5         0.30
% psi2        Gamma       0.5         0.25
% Rhor        Beta        0.5         0.2
% Rhog        Beta        0.8         0.1
% Rhoz        Beta        0.2         0.1
% Rhod        Beta        0.8         0.1
% 100Sigr     Inv Gamma   0.3         4.0
% 100Sigg     Inv Gamma   0.4         4.0
% 100Sigz     Inv Gamma   0.4         4.0
% 100Sigd     Inv Gamma   0.4         4.0

% Gamma priors: tau, kappa
P1 = gamprior(Theta(1),PRIORTABLE{'tau','Param1'},PRIORTABLE{'tau','Param2'});
P2 = gamprior(Theta(2),PRIORTABLE{'kappa','Param1'},PRIORTABLE{'kappa','Param2'});
P3 = gamprior(Theta(3),PRIORTABLE{'psi1','Param1'},PRIORTABLE{'psi1','Param2'});

if Theta(3)<1.0
    fprintf('Draw of psi1<1, ... discarding draw');
    P3=0;
end
P4 = gamprior(Theta(4),PRIORTABLE{'psi2','Param1'},PRIORTABLE{'psi2','Param2'});

% Beta priors: rhor, rhog, rhoz, rhod
P5 = betprior(Theta(5),PRIORTABLE{'rhor','Param1'},PRIORTABLE{'rhor','Param2'});
P6 = betprior(Theta(6),PRIORTABLE{'rhog','Param1'},PRIORTABLE{'rhog','Param2'});
P7 = betprior(Theta(7),PRIORTABLE{'rhoz','Param1'},PRIORTABLE{'rhoz','Param2'});
P8 = betprior(Theta(8),PRIORTABLE{'rhod','Param1'},PRIORTABLE{'rhod','Param2'});

% Prior from Inverse Gamma: sigr, sigg, sigz, sigd
P9 = exp(lnpdfig(Theta(9), PRIORTABLE{'100sigr','Param1'}/100,PRIORTABLE{'100sigr','Param2'}));
P10= exp(lnpdfig(Theta(10), PRIORTABLE{'100sigg','Param1'}/100,PRIORTABLE{'100sigg','Param2'}));
P11= exp(lnpdfig(Theta(11), PRIORTABLE{'100sigz','Param1'}/100,PRIORTABLE{'100sigz','Param2'}));
P12= exp(lnpdfig(Theta(12),PRIORTABLE{'100sigd','Param1'}/100,PRIORTABLE{'100sigd','Param2'}));

f = P1*P2*P3*P4*P5*P6*P7*P8*P9*P10*P11*P12;

prior = log(f);

end

function y = lnpdfig(x,a,b)
% LNPDFIG(X,A,B)
%	calculates log INVGAMMA(A,B) at X

% 03/03/2002
% Sungbae An
y = log(2) - gammaln(b/2) + (b/2)*log(b*a^2/2) - ( (b+1)/2 )*log(x^2) - b*a^2/(2*x^2);
end

function y = gamprior(x,para1,para2)
b = (para2.^2)./para1;
a = para1./b;
y = gampdf(x,a,b);
end

function y = betprior(x,para1,para2)
a = (1-para1).*para1.^2./para2.^2 - para1;
b = a.*(1./para1 - 1);
y = betapdf(x,a,b);
end
