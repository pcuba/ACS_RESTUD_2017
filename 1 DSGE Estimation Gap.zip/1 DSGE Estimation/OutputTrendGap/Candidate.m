%==========================================================================
%      Macroeconomic Dynamics Near the ZLB: A Tale of Two Countries
%                  (Aruoba, Cuba-Borda, Schorfheide)
%
% Script to Maximize the log Posterior of the New Keynesian DSGE Model
% in ACS(2017)
%
% This version for trend gap in monetary policy rule.
%
%=========================================================================
clear all; clc; close all;
delete *.~m; delete *.asv;

addpath 'Matfiles';
addpath 'Objective';
addpath 'Filter';

global error_flag PRIORTABLE

%=========================================================================
%                    SET INITIAL PARAMETERS
%=========================================================================
% SET INITIAL VECTOR OF PARAMETERS TO BE ESTIMATED
params0 = [
    1.5             % 1) tau
    0.5             % 2) kap
    1.50            % 3) psi1
    0.80            % 4) psi2
    0.6             % 4) rhor
    0.6             % 5) rhog
    0.5             % 6) rhoz
    0.6             % 7) rhod
    0.0020          % 8) sigr
    0.0080          % 9) sigg
    0.0100          % 10) sigz
    0.0050];        % 11) sigd

% SET FIXED PARAMETERS AND DATA RELATED PARAMETERS
paramsfixed = [
    0.8619          % 1) R_star_an
    2.3500          % 2) pi_star_an
    0.4964          % 3) gamma_qu
    0.7780          % 4) cy
    1.2853          % 5) g_star = 1/cy
    0.1000          % 6) nu
    0.7200          % 7) eta
    0.9000];        % 8) alp

% DATA RELATED PARAMETERS ARE CALCULATED AS:
% R_star_an   = mean(R_obs) - mean(infl_obs) - 4*mean(dy_obs);
% pi_star_an  = mean(infl_obs);
% gamma_qu    = mean(dy_obs);
% cy          = (exp(logCY/100));

%=========================================================================
%                    RUN DYNARE TO INITIALIZE OBJECTS
%=========================================================================
% CALL DYNARE
dynare ACS_OutputTrendGap_loglinear.mod noclearall

% CLEAR OBJECTS
clearvars -except oo_ M_ options_ error_flag params0 paramsfixed PRIORTABLE

% INITIALIZE ERROR FLAG CHECK
error_flag = 0;

% LOAD DATA
load data_us_estimation_restud_revision2.mat logy logcy2 infl_obs R_obs logt

data_in = [logy logcy2 infl_obs R_obs logt];

%=========================================================================
%                   SET INITIAL VALUES OF PARAMETERS
%=========================================================================

% Read Prior Information
PRIORTABLE = readtable('prior_spec.txt','ReadRowNames',1);

fprintf('\n Priors for ACS (2017) - REStud \n');
disp(PRIORTABLE);

% TRANSFORM PARAMETERS FOR UNCOSTRAINED OPTIMIZATION
Theta_0 = setbounds(params0);

disp('                                                                  ');
disp('                   INITIAL PARAMTER VALUES                        ');
disp('                                                                  ');
disp('   TAU       KAPPA     PSI1       PSI2       RHOr       RHOg       RHOz     RHOd');
disp(num2str(params0(1:8,:)'))
disp('                                                                  ');
disp('                                                                  ');
disp('   Sigr        Sigg        Sigz   Sigd');
disp(num2str(params0(9:12,:)'))
disp('                                                                  ');

%=========================================================================
%                           RECOVER POSTERIOR MODE
%=========================================================================

% Maximize Likelihood
disp('                                                                  ');
disp('         ******* MAXIMIZING LOG POSTERIOR....*********');
disp('                                                                  ');

% Optimization Options
options=optimset('Display','iter','LargeScale','off','MaxFunEvals',10000,...
                 'MaxIter',20000,'MaxFunEvals',2000000,'TolX',10^(-7),...
                 'TolFun',10^(-7));

% Define Objective Function
objective  = @(Theta_in) - (DSGE_linearized(Theta_in,paramsfixed,data_in,1));

% Find Poterior Mode
Theta_out = fminunc(objective,Theta_0,options);

% Undo parameter transformation
params_out = setboundsinv(Theta_out);

%=========================================================================
% COMPUTE OBJECTS AT THE POSTERIOR MODE
%=========================================================================

% % Obtain State Space Representation
[A,B,H,M,Phi,R,Se] = sysstatespace(oo_.dr,params_out,paramsfixed);

% Compute Likelihood at Initial Values
liki_mode = kalman(A,B,H,R,Se,Phi,data_in,params_out,paramsfixed);
logpost_mode = DSGE_linearized(Theta_out,paramsfixed,data_in,1);

fprintf('\n ****** LOG-LIKELIHOOD AND LOG POSTERIOR AT MODE ****** \n');
fprintf('\n logL = %4.4f, logPosterior = %4.4f \n ',liki_mode,logpost_mode);

disp('                                                                  ');
disp('                   PARAMTER VALUES AT POSTERIOR                   ');
disp('                                                                  ');
disp('   TAU       KAPPA        PSI1        PSI2        RHOr       RHOg       RHOz   RHOd');
disp(num2str(params_out(1:8,:)'))
disp('                                                                  ');
disp('                                                                  ');
disp(' Sigr        Sigg        Sigz     Sigd');
disp(num2str(params_out(9:12,:)'))
disp('                                                                  ');

%=========================================================================
%                   EVALUATE THE HESSIAN AT POSTERIOR MODE
%=========================================================================

% Set Posterior Mode
mode = setboundsinv(Theta_out);

% Set objective function = log posterior without parameter transformation
objective  = @(Theta_in) -(DSGE_linearized(Theta_in,paramsfixed,data_in,0));

% Compute Hessian numerically
hessian = nhess(objective,mode);
X       = hessian;

%=========================================================================
%                  MAKE SURE HESSIAN IS NEGATIVE DEFINITE
%                   (This piece is from Frank's code)
% Use SVD decomposition to compute inverse hessian. Numerically more robust
%=========================================================================

% singular value decomposition
[U,S,V] = svd(X,0);

s = diag(S);

% rank of Hessian (theoretical)
r1 = size(params_out,1);

% evaluate rank
tol = size(X,1)*max(s)*eps;
r2 = sum(s > tol);

r = r1;		% use theoretical rank

% inverse of negative Hessian
S(:) = 0;
if (r == 0)
	error('every singular value is zero.');
else
    S(1:r,1:r) = diag(ones(r,1)./s(1:r));
	sigmult    = U*sqrt(S);							% sigmult
	logdetS    = sum(log(diag(S(1:r,1:r))));
	penalt     = (r/2)*log(2*pi) + 0.5*logdetS;		% posterior mode penalty
end

Sigma = sigmult*sigmult';

%=========================================================================
%                            SAVE RESULTS
%=========================================================================
save Matfiles/Mhcandidate.mat Sigma mode paramsfixed PRIORTABLE

disp(['         ELAPSED TIME:   ', num2str(toc)]);


movefile('ACS_OutputTrendGap_loglinear*.m','ACS_OutputTrendGap_loglinear');
movefile('ACS_OutputTrendGap_loglinear*.mat','ACS_OutputTrendGap_loglinear');
movefile('ACS_OutputTrendGap_loglinear*.log','ACS_OutputTrendGap_loglinear');
